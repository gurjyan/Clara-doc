
*************
CLARA proxies
*************

CLARA application can be highly distributed spanning across multiple nodes (DPE's) over the network, accessing services and service compositions. The fact that services can come and go dynamically while the application is running makes network communications more difficult to handle. To access CLARA distributed service network framework introduces 3 proxies with defined TCP ports. All proxies function much like http proxies forwarding network packets between ports. These are simple proxies that demonstrated to introduce no or performance overhead.

.. figure:: /_static/pictures/Slide4.jpg
    :width: 600px
    :align: center
    :height: 400px
    :alt: alternate text
    :figclass: align-center
     
DPE contains a proxy and the registration and discovery service.


.. _external_proxy:

Proxy
=====

TCP *port = 7771* is used by CLARA application orchestrator/s well as exception and data monitors to send request and subscribe messages. Examples of CLARA platform requests are

 * service requests

 * service container start/stop requests

 * service deployment requests, etc.

Asynchronous nature of CLARA communications requires requester to listen a response messages with consequent execution of a callback action. Since CLARA communications are based on publish-subscribe communication paradigm the above described communication mechanism in a pub-sub language will be described as

 #. orchestrator/s and/or service/s publish/send request to the *port = 7771* and

 #. subscribe the future response messages at the *port = 7772*.

DPE proxy forwards requests from port *7771* to port *7772* where future service containers will subscribe orchestrator and/or monitor messages. Note that in this network pattern we can have  arbitrary number of containers and services.


By introducing the proxy in each DPE, CLARA avoids s star network configuration (single point of failure architecture). The prosy of a DPE forwards messages from TCP *port = 7771* to TCP *port = 7772*. The *7771* port is the port where services and/or orchestrator/s publish/send a data directly addressed to a service, deployed and running on a specific DPE. The *port 7772* is the port where services subscribe CLARA transient data envelopes. DPE proxy is the main hub to organize service based application data transfer.


It is important to mention that CLARA TCP port assignments suggest a possible network security mechanism where only ports 7771 and 7772 will be exposed to the outside of a possible firewall. Also in case only a few nodes are allowed to be outside of the firewall a special gateway service (not implemented for version pClara) is provided that is capable of accepting requests and forwarding them to a specific DPE running on host behind the firewall.
 
