*****************
User base classes
*****************

CLARA presents a base class for external applications to interact with the registration and
administrative services as well as for composing and running service based applications.


.. _orchestrator_base:

OrchestratorBase
================

By extending this class user gets an access to a set of methods described in the following table.
Note that *requester* parameter in method signatures is the generated unique name of the orchestrator.
Also sync methods are blocking methods, that will block the main thread until the result is ready or time_out
has been reached. OrchestratorBase class extends CBase class that will create a connection to the local
xMsgNode proxy by creating two sockets for publishing and subscribing/receiving messages.

=======================================================   ==============================================================
Method Signature                                          Description
=======================================================   ==============================================================
get_service_by_host(host)                                 Asks the Registrar service of a specified DPE
                                                          (host) to return the registration information of
                                                          service/services based on dpe_host

                                                          :host: DPE host
                                                          :return: set of the service registration data objects

get_service_by_container(container, host)                 Asks the Registrar service of a specified DPE
                                                          (host) to return the registration information of
                                                          service/services based on the name of the service
                                                          container

                                                          :container: The name of the service container
                                                          :host: DPE host
                                                          :return: set of the service registration data objects

get_service_by_engine(engine, host)                       Asks the Registrar service of a specified DPE
                                                          (host) to return the registration information of
                                                          service/services based on the name of the service
                                                          engine

                                                          :engine: The name of the service engine
                                                          :host: DPE host
                                                          :return: set of the service registration data objects

get_service_description(host, container, engine)          Asks the Registrar service of a specified DPE
                                                          (host) to return the description of a service
                                                          based on the name of the service container and
                                                          the name of the service engine

                                                          :container: The name of the service container
                                                          :engine: The name of the service engine
                                                          :host: DPE host
                                                          :return: textual description of the service functionality
=======================================================   ==============================================================


=======================================================   ==============================================================
Method Signature                                          Description
=======================================================   ==============================================================
receive_all_errors(callback_function, is_sync)            Subscribes all error messages generated from services
                                                          of entire Clara cloud. Only severity = 1 is supported
                                                          for subscription. Yet you can analyze severity after
                                                          getting xMsgData in the call back.

                                                          :callback_function: call back function
                                                          :is_sync: This call will block until
                                                                    callback receives the data. Default = True


receive_all_warnings(callback_function, is_sync)          Subscribes all warning messages generated from services
                                                          of entire Clara cloud. Only severity = 1 is supported
                                                          for subscription. Yet you can analyze severity after
                                                          getting xMsgData in the call back.

                                                          :callback_function: call back function
                                                          :is_sync: This call will block until
                                                                    callback receives the data. Default = True

receive_all_info(callback_function, is_sync)              Subscribes all info messages generated from services
                                                          of entire Clara cloud.

                                                          :callback_function: call back function
                                                          :is_sync: This call will block until
                                                                    callback receives the data. Default = True

receive_error(service_name,callback_function,is_sync)     Subscribes error messages generated from a specific
                                                          service. Only single severity is supported for
                                                          subscription. Yet you can analyze severity after
                                                          getting xMsgData in the call back. Note that service
                                                          name is constructed as dpe:container:engine.
                                                          So, one can require for example to subscribe messages
                                                          from services from a specific dpe (dpe:*:engine) or
                                                          services from a specific dpe and a specific container
                                                          (dpe\:container\:\*). The construct
                                                          service_name = \*\:container:engine is equivalent
                                                          to receive_all call. Also note that no other
                                                          combinations are supported.

                                                          :service_name: the name of the service of interest
                                                          :callback_function: call back function
                                                          :is_sync: This call will block until
                                                                    callback receives the data, Default = True

receive_warning(service_name,callback_function,is_sync)   Subscribes warning messages generated from a specific
                                                          service. Only severity = 1 is supported for subscription.
                                                          Yet you can analyze severity after getting xMsgData in
                                                          the call back. Note that service name is constructed as
                                                          dpe:container:engine. So, one can require for example
                                                          to subscribe messages from services from a specific
                                                          dpe (dpe:*:engine) or services from a specific dpe
                                                          and a specific container (dpe:container\:\*).
                                                          The construct service_name = *:container:engine is
                                                          equivalent to receive_all call. Also note that no
                                                          other combinations are supported.

                                                          :service_name: the name of the service of interest
                                                          :callback_function: call back function
                                                          :is_sync: This call will block until
                                                                    callback receives the data, Default = True

receive_info(service_name,callback_function,is_sync)      Subscribes info messages generated from a specific
                                                          service. Only severity = 1 is supported for subscription.
                                                          Yet you can analyze severity after getting xMsgData in
                                                          the call back. Note that service name is constructed as
                                                          dpe:container:engine. So, one can require for example to
                                                          subscribe messages from services from a specific dpe
                                                          (dpe/:/*/:engine) or services from a specific dpe and a
                                                          specific container (dpe:container\:\*).
                                                          The construct service_name = *:container:engine is
                                                          equivalent to receive_all call. Also note that no other
                                                          combinations  are supported.

                                                          :service_name: the name of the service of interest
                                                          :callback_function: call back function
                                                          :is_sync: This call will block until
                                                                    callback receives the data, Default = True
=======================================================   ==============================================================


=======================================================   ==============================================================
Method Signature                                          Description
=======================================================   ==============================================================
engine_to_composition_dpe(host,container,composition)     Parses the specified composition and replaces the engine
                                                          names with a proper service canonical names, using specified
                                                          host and container names.
                                                          Note: This method assumes that all engines specified in the
                                                          composition are deployed on a same host and the same
                                                          container

                                                          :host: the name of the host where the services are deployed
                                                          :container: container name of the services.
                                                          :composition: string of the CLARA application composition
                                                          :return: proper composition string with service
                                                                   canonical names.


engine_to_composition(composition)                        This is a utility method that assumes that composition
                                                          is created using engines name only. Also this method assumes
                                                          that we have only one service with the same engine and that
                                                          these services are running in a local DPE.
                                                          This method accepts composition that has engine names in it,
                                                          and asks platform Discovery service to see if composition
                                                          engines are deployed as services and returns composition
                                                          with service canonical names. If at least one service is not
                                                          deployed this method will return string = none.
                                                          Note: the same engine can be deployed multiple times in
                                                          CLARA cloud. This method will use the first deployed
                                                          service from the Discovery service.

                                                          :composition: string of the CLARA application composition
                                                          :return: proper composition string with service
                                                                   canonical names.
=======================================================   ==============================================================


.. _clara_base:

Common Base
===========

On the top of the CLARA hierarchical tree is CBase class, methods of which are mostly encapsulated
from the framework user, yet a few methods are worth describing in the table below that can be used
by the orchestrator developer.

=======================================================   ==============================================================
Method Signature                                          Description
=======================================================   ==============================================================
receive(topic, call_back, is_sync)                        This method simply calls xMsg subscribe method
                                                          passing the reference to user provided call_back method.

                                                          :topic: topic (string) that this
                                                                  method will subscribe or listen
                                                          :call_back: User provided call_back function.
                                                          :is_sync: This call will block until
                                                                    callback receives the data, Default = True

receive_new(connection,topic,call_back,is_sync)           This method calls xMsg subscribe method passing the
                                                          reference to user provided call_back method. The only
                                                          difference is that this method requires a
                                                          connection socket different than the default socket
                                                          connection to the local dpe proxy.

                                                          :connection: ZeroMQ socket
                                                          :topic: topic (string) that this
                                                                  method will subscribe or listen
                                                          :call_back: User provided call_back function.
                                                          :is_sync: This call will block until
                                                                    callback receives the data, Default = True

send(topic, data)                                         Sends xMsgData object to a topic

                                                          :topic: Clara service canonical name where
                                                                  the data will be sent as an input
                                                          :data: xMsgData object

send_new(connection,topic, data)                          Sends xMsgData object to a topic. This method requires a
                                                          connection socket different than the default socket
                                                          connection to the local dpe proxy.

                                                          :connection: ZeroMQ socket
                                                          :topic: Clara service canonical name where
                                                          :topic: Clara service canonical name where
                                                                  the data will be sent as an input
                                                          :data: xMsgData object
=======================================================   ==============================================================
