
**********************
CLARA SaaS In Nutshell
**********************

The CLARA service model assumes that the software, as well as the solution itself is provided as a complete service. This approach is referred to as Software as a Service (SaaS). A CLARA service may be concisely described as a software application (service engine) that is deployed on a CLARA DPE and can be accessed locally as well as globally over the Internet. With the exception of a user’s and other service interactions with a service engine, all the aspects of a service are abstracted away (including algorithmic solutions, composition, inheritance, technology, etc.). As was mentioned, CLARA SaaS supports multiple users and provides a shared data model through a single-instance, known as a multi-tenancy model (i.e. services that are shared between multiple data processing applications).  So, the use of the multi-tenancy model in the CLARA SaaS implementation dictates the only requirement to service engine: the service engine must be thread enabled or thread safe.


.. _Software-service:

Software as a CLARA service
===========================

In order to present software as a CLARA service we need 2 things:

*	Understanding of the CLARA transient data envelope

*	Implementing of the CLARA service interface (or inherit from the CLARA service abstract class)

The CLARA transient data envelope is described in the previous chapter. The CLARA framework uses Google’s protocol buffers to provide the transient data representing classes in Java, C++ and Python. Protocol buffers are language-neutral, platform-neutral, extensible mechanism for serializing structured data. CLARA transient data is described using protocol buffer syntax and a source code is generated that allows easily write and read serialized transient data to and from services and using a variety of languages – Java, C++, or Python. 
An object of this class is passed as a parameter to the CLARA service interface methods. The table below describes the CLARA service interface methods.

===========================================     ================================
Method Signature                                 Description
===========================================     ================================
public void  configure (TData   data);	        Service configuration
public TData execute (TData   data);	        Service engine execution
public TData execute_group (TData[] data);	    Service engine execution
public String[] get_states();	                Possible engine states
public String get_current_state();	            Service engine current state
public Enum get_accepted_data_type()	        Engine’s input data type
public Enum get_returned_data_type()	        Engine’s output data type
public String get_author()	                    Returns name of engine author
public String get_description();	            Functional description of engine
public String getVersion();	                    Returns version of engine
public void    dispose();                       Graceful withdrawal of engine
===========================================     ================================

CLARA service interface. TData is the class that represents transient data object.

.. _transient-data:

CLARA transient data
====================

The CLARA transient data is described using Google’s protocol buffer IDL (Interface Definition Language) and then pre-compiled into source code for the target languages (Python, Java and C++) of service engines. Below is the CLARA transient data protocol buffer description file.

.. code-block:: c
	
    // Google's protocol-buffer definition of the xMsg data class
    // author: gurjyan
    // date: 01.07.15

    option optimize_for = SPEED;

    // ... Data class ...
    message Data {

        // ... This section is defined by the message ...
        // ... data generator, such as service engine ...
        // Data version
        optional string dataVersion = 1;

        // Data textual description
        optional string dataDescription = 2;

        // Author of the data
        optional string dataAuthor = 3;

        // The state of the message sender
        optional string dataAuthorState = 4;

        // Overall status/severity of the data generation process
        optional DStatus dataGenerationStatus = 5 [default = INFO];

        optional fixed32 dataStatusSeverity = 6;

        // Data itself
        optional sint32 VLSINT32 = 7; // variable length signed int32
        optional sint64 VLSINT64 = 8; // variable length signed int64
        optional sfixed32 FLSINT32 = 9; // fixed length signed int32
        optional sfixed64 FLSINT64 = 10; // fixed length signed int64
        optional float FLOAT = 11;
        optional double DOUBLE = 12;
        optional string STRING = 13; // contains UTF-8 encoding or 7-bit ASCII text
        optional bytes BYTES = 14; // contains arbitrary sequence of bytes

        repeated sint32 VLSINT32A = 15; // array of variable length signed int32s
        repeated sint64 VLSINT64A = 16; // array of variable length signed int64s
        repeated sfixed32 FLSINT32A = 17; // array of fixed length signed int32s
        repeated sfixed64 FLSINT64A = 18; // array of fixed length signed int64s
        repeated float FLOATA = 19; // array of floats
        repeated double DOUBLEA = 20; // array of doubles
        repeated string STRINGA = 21; // array of UTF-8 encoded or 7-bit ASCII strings
        repeated bytes BYTESA = 22; // array of arbitrary sequence of bytes

        // Data type. If set to DataTpe.PAYLOAD access data using the "payload"
        // filed, otherwise "data: filed
        optional DType dataType = 23;

        // Byte ordering in case data type is BYTES/BYTESA
        optional string byteOrder = 24;


        // ... This section is defined by the message transporter, i.e. service ...
        // The name of the message transporter,
        // i.e. service that sends the transient data
        optional string sender = 25;

        // Communication id, used to genetically relate messages
        optional fixed32 id = 26;

        // ... Fields that are used to control message receiver ...
        // If set to true, for example Clara service container will
        // broadcast exceptions to
        // [ exception_<service_name>,
        //             requestId,
        //             exceptionType <Severity>,
        //             exceptionString <String> ]
        optional bool exceptionMonitor = 27;

        // If set to true, for example Clara service container will
        // broadcast "done" string
        // [ done_<service_name>,
        //             requestId]
        optional bool doneMonitor = 28;

        // If set to true, for example Clara service container will
        // broadcast resulting data to
        // [ data_<service_name>,
        //             requestId,
        //             transient_data ]
        optional bool dataMonitor = 29;

        // Reserved and used for Clara service based application
        // composition i.e. link schema (list of linked service names)
        // e.g. s1+s2;s1+s3,s4,s5+&s6
        optional string composition = 30;

        // Reserved and used to define which of the CLARA interface
        // methods must be called on a service engine.
        optional ControlAction action =31;

        // Reserved control field
        optional SubControlAction controlR = 32;


        // ... Enumerations ...
        // Data type enumeration
        enum DType {
            T_VLSINT32 = 1;   // variable length signed int32
            T_VLSINT64 = 2;   // variable length signed int64
            T_FLSINT32 = 3;   // fixed length signed int32
            T_FLSINT64 = 4;   // fixed length signed int64
            T_FLOAT = 5;
            T_DOUBLE = 6;
            T_STRING = 7;     // contains UTF-8 encoding or 7-bit ASCII text
            T_BYTES = 8;      // contains arbitrary sequence of bytes

            T_VLSINT32A = 9;  // array of variable length signed int32s
            T_VLSINT64A = 10; // array of variable length signed int64s
            T_FLSINT32A = 11; // array of fixed length signed int32s
            T_FLSINT64A = 12; // array of fixed length signed int64s
            T_FLOATA = 13;    // array of floats
            T_DOUBLEA = 14;   // array of doubles
            T_STRINGA = 15;   // array of UTF-8 encoded or 7-bit ASCII strings
            T_BYTESA = 16;    // array of arbitrary sequence of bytes

            T_PAYLOAD = 17;    // payload data type
        }

        // In the case data is passed as a byte[], i.e. DataType = T_BYTESA
        // following enum shows how to handle passed byte[]
        enum BAType {
            JOBJECT = 1;
            COBJECT = 2;
            POBJECT = 3;
            NETCDF = 4;
            HDF = 5;
        }

        // Control actions, used to define service control directive
        enum ControlAction {
            EXECUTE = 0;
            CONFIGURE = 1;
        }

        // Sub control action, used to micromanage service engine activity
        enum SubControlAction {
            SKIP = 0;
        }

        // Message severity
        enum DStatus {
            ERROR = 1;
            WARNING = 2;
            INFO = 3;
       }
    }

    //... Payload class ...
    message Payload {

        message Item {
            required string name =1; // payload name
            required Data data =2; // data
        }

        repeated Item item = 1;
    }

    