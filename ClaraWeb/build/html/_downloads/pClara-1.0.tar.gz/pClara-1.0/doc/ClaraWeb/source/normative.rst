******************
Normative Services
******************

By design CLARA implements so called auto-routing mechanism, where transient data envelope's *composition* field
notifies a service where from the request is coming and where the result of the service execution should be directed to.
This assumes that application designer, before launching a composition, must make sure that all services within a
composition are actually active and running. This critical process is accomplished by communication with the
normative Registrar services, running in every DPE, for a registration information of a service/services of interest.
CLARA introduced normative registration and discovery service that runs within every DPE plays stores registration information of
locally deployed services and service containers. In addition to local service registration databases, a global registration
database is running within the CLARA front-ed. Front-end is a centralized registration and discovery database that
users can use to discover services. DPE registration and discovery services will periodically report content of the local
registration database to the front-end. Thus front-end database will contain registration information of services from entire CLARA cloud.

.. figure:: /_static/pictures/Slide5.jpg
    :width: 600px
    :align: center
    :height: 400px
    :alt: alternate text
    :figclass: align-center


.. _registrar_service:


