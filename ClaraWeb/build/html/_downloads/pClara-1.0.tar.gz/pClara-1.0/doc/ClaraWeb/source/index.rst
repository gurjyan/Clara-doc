.. clara documentation master file, created by
   sphinx-quickstart on Mon Jul 21 12:54:31 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. |clara| image:: /_static/clara.png

.. role:: blue2
.. role:: red
    
Welcome to CLARA
================

.. sidebar::  :blue2:`Big Data Processing Framework`

    |clara|

    Develop :red:`CL`\oud computing :red:`A`\pplications for data :red:`R`\econstruction and :red:`A`\nalyses.

    :red:`CL`\as :red:`A`\pplication development framework for data :red:`R`\econstruction and :red:`A`\nalyses.

 	
.. toctree::
   :maxdepth: 2

   intro
   framework
   saas
   proxies
   normative
   engine
   base
   msg_structures
   threading
   examples
   handson



