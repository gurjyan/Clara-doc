***************************
Standard message constructs
***************************

CLARA transient data is packed into the ZeroMQ multi-part message. Table below explains CLARA communication
defined message structures.

.. _registrar_messages:

Registrar service messages
==========================

Registrar service runs within every DPE, so this means that CLARA service registration database is
distributed among multiple DPEs, making it more secure. Registrar service returned messages have a simple
structure and is consists of two parts:

1) the name of the requester

2) result as a string

Examples of Registrar service requests are requests for registration information of a specific service,
or the names of all services running on a specific service, etc.

.. _service_messages:

Application service messages
============================

Service data link messages also have a simple 2 part construct:

1) canonical name of a recipient service

2) serialized transient data object

Service container will create and broadcast engine exception, done, info, data, etc messages for all subscribers.
Theses messages have the following construct:

*Exception Message Construct*

1) **exception_** + service_canonical_name

2) transient data status set by the engine

3) request ID when this exception happens. Request ID is set by the orchestrator of the application.

4) serialized transient data itself

Here we have duplication of information, yet this is intentional that allows organize subscriptions to specific
exceptions by status, by request ID, etc.

*Done Message Construct*

1) **done_** + service_canonical_name

2) request ID

*Data Message Construct for Monitoring*

1) **data_** + service_canonical_name

2) request ID that the data is associated with

3) serialized transient data object

