
**********
Framework
**********

.. _programming_paradigm:

Programming paradigm
=====================

The CLARA framework uses a service-oriented architecture (SOA) to enhance the efficiency, agility, and productivity of data processing activities. Services are the primary means through which data processing logic is implemented. Data processing applications, developed using the CLARA framework, consist of services, running in a context that is agnostic to the global data processing application logic. Services are loosely coupled and can participate in multiple algorithmic compositions. Legacy processes or applications can be presented as services and integrated into a data processing application. Simple services can be linked together and presented as one, complex, composite service. This framework provides a federation of services, so that service-based data processing applications can be united while maintaining their individual autonomy and self-governance. It is important to mention that CLARA makes a clear separation between the service programmer and the data processing application designer. An application designer can be productive by designing and composing data processing applications using available, efficiently and professionally written software services without knowing service programming technical details. Services usually are long-lived and are maintained and operated by their owners on distributed CLARA service containers. This approach provides an application designer the ability to modify data processing applications by incorporating different services in order to find optimal operational conditions, thus demonstrating the overall agility of the CLARA framework.


.. _services-and-service-interactions:

Services and service interactions
=================================

Message passing is the most popular communication model for distributed computing. It is key for building SOA-based frameworks. This model is attractive due to the fact that messaging does not emulate the syntax of programming language function calls (like CORBA and RPC for example). Instead, structured data messages are passed between distributed components (i.e. services). In this distributed communication model success largely depends on the clever design of the message structure: a communication envelope that describes not only transferred data but also communication and service operational details. In order for a service communication to be truly useful, every party has to share/use the same vocabulary for expressing the communication details (i.e. common message-interface).
The CLARA framework provides developers with the means for interacting with services based on the publish-subscribe message exchanges. But such explicit interactions, where a service invokes operations exported by the predefined interface of a well-known target service, are only one piece of the messaging puzzle. To make this clear, consider a persistency service that converts CLARA transient data into a ROOT tree. Using CLARA tools one can link for example a charge particle tracking service to a ROOT persistency service for storing reconstruction results in a ROOT format. In this particular scenario, the persistency service (i.e. invocation target) is known in advance and the responsibilities between the requestor service and the provider service are defined in a service contract. But that same messaging strategy is far less suitable for indicating event occurrences, for example a input-out exception detected by the persistency service.  In such situations, the developer of the persistency service either doesn’t know who is interested in the event, or doesn’t want to hardcode the event handling logic in the service. Indeed, doing so would increase its complexity and reduce its reusability and maintainability. What CLARA provides for such cases is a way to deliver event notification to services that register their interest in one or more events. This is possible due to the CLARA message envelope design (service communication message structure) that contains event notification. 
CLARA services are loosely coupled, since there are no dependencies between services because event-producing services typically invoke generic operations such as execute/notify (rather than target service specific algorithmic methods). Even more, a service developer is unable to predict future customers (i.e. services that will be linked to it). Only a final physics data processing application (service composition) designer knows the event/data flow outline. Rather than contacting services directly, the implicit invocation mechanism only signals that output-data is ready (an event has occurred) and it does not say what needs to be done to that data (how to react to that event).  This clearly improves its maintainability, and it simplifies data processing application-reengineering processes. CLARA services can be considered as event handlers for one another. Since event handlers are external to other services, the workflow modification of a handler does not require modification of any event producing services.  


.. _design-architecture:

Design architecture
===================

This framework was designed based on a specific set of principles. The fundamental unit of CLARA based data processing application logic is the service. Services exist as independent software programs with a common interface defined by the framework. User classes, encapsulating specific algorithms and compliant to the required interface, can be presented as CLARA services (the CLARA Software-as-a-Service: SaaS implementation). Each service has its own set of data processing functionalities. These functionalities or capabilities, suitable for invocation by other services, can be discovered via registration information available from the CLARA platform registry services. One of the service design recommendations is to keep a small and simple service code base, which will help future programmers to easily extend, modify, maintain and port services. Services must be agnostic to any eternal data processing logic. Services must be discoverable and able to take part in complex service compositions. By standardizing communication between services, adapting a data processing application to changes in one of its components becomes easier and simplifies data transfer security (for example by deploying a specialized access control service). The CLARA architecture consists of tree layers. 

.. figure:: /_static/architecture.jpg
    :width: 500px
    :align: center
    :height: 200px
    :alt: alternate text
    :figclass: align-center

CLARA architecture

The first layer is a service bus that provides an abstraction of the 0MQ publish-subscribe messaging system. Every service or component from the orchestration layer communicates via this bus, which acts as a messaging tunnel between services. Such an approach has the advantage of reducing the number of point-to-point connections between services required to allow services to communicate in the distributed CLARA cloud. 0MQ is a messaging system that scales perfectly to tens of thousands of processes, running over many boxes with many cores as wanted. This simple API based on BSD sockets implements real messaging patterns like topic pub-sub, workload distribution, and request-response. It is design as a library that is linked with CLARA framework. 0MQ is licensed as LGPL code and can be used with no licensing issues in closed-source as well as free and open source applications. The service layer houses the inventory of simple/entity and complex/composite services (linked service chains presented as a single service) used to build data processing applications. An administrative registration service stores information about every registered service in the service layer, including address, description and operational details. The orchestration of data analyses applications is accomplished by the help of an application controller, resident in the orchestration layer of the CLARA architecture. 

.. _service-categories:

Service categories
==================

CLARA specifies four types of services: entity, utility, task and orchestrated task. 

*	Entity services are highly reusable and generic. They are atomic enough to take part in different service compositions. 

*	Users find many self-contained and legacy software systems very useful. These systems can be presented as utility services. The difference between entity and utility service is size and complexity. We hope in the future that the utility service definition will be deprecated. Currently the legacy software applications temporarily are labeled as utility services before they will be categorized (after proper segmentation and modularization) as entity services. 

*	Task and orchestrated task services are both composite services, with the only difference being that task-services are self-governed, while orchestrated services are aggregated services controlled by the software components from the orchestration layer of the framework.

.. _service-compositions:

Service compositions
====================

A service composition is comprised of services that have been assembled to provide the functionality required to accomplish a specific data processing task. CLARA distinguishes between two types of service compositions: primitive and complex. Primitive compositions use message exchange across two or more services. Complex compositions, however, require an orchestrator. Because the frameworks requirement for services is to be agnostic to any physics data processing logic, one service may be invoked by multiple data processing applications, each of which can involve that same service in a different composition. A collection of entity services can form the basis of a CLARA service repository that can be independently administered within its own physical deployment environment. So, the CLARA framework helps to build services, service compositions, and service inventories. The service-oriented approach of CLARA changes the overall complexion of a data processing application. Because the majority of services delivered are reusable resources agnostic to analysis, they do not belong to any one application. By dissolving boundaries between applications, the data processing is increasingly represented by a growing body of services that exist within a continuously expanding service inventory.  

.. figure:: /_static/dpe.jpg
    :width: 500px
    :align: center
    :height: 300px
    :alt: alternate text
    :figclass: align-center

CLARA Data Processing Environment

.. _service-engine:

Service engine
==============

CLARA implements SOA SaaS as a way of delivering on-demand, ready-made data processing solutions (“service engines” in CLARA terminology) as CLARA services. The CLARA data processing application user uses a service, but does not control the operating system, hardware or network infrastructure on which they are running. The quality of the data-processing application (including syntactic, semantic qualities and performance) depends highly on the quality of constituent services. It is, therefore, absolutely critical to test and validate an engine before deploying it as a CLARA service. Physics data-processing engines must be validated with respect to workflow, thread-safety, integrity, reliability, scalability, availability, accuracy, testability and portability. 

.. _dpe-container-saas:

Service container and SaaS
==========================

The highly distributed nature of CLARA is largely due to traits of the CLARA service container. A service container is the physical manifestation of an abstract service representation and provides the implementation of the CLARA service interface. Service container is a way of logically grouping services. A service container runs within the CLARA Data Processing Environment (DPE) that provides a complete run-time environment for service execution and operation.  DPE presents a shared memory that used by service containers to communicate transient data between services within the same DPE. This prevents unnecessary copying of the data during service communications. Services in a DPE are group in multiple service containers. The CLARA service container allows the selective deployment of services exactly when and where you need them. In its simplest state, a service container is an operating system process that can be managed by the CLARA framework. A service container is capable of managing multiple instances of user service engines. Several service containers can coexist within the same DPE providing the logical grouping of services. Service containers may also be distributed across multiple machines for the purposes of scaling up to handle increased data volume. CLARA administrative services start service containers in a specified DPE.  They also monitor and track functionality of service containers by subscribing to specific events from a service container, reporting the number of requests to a specific container, as well as notifying when a successful execution of a particular service (or its failure) has occurred. 

.. figure:: /_static/shared_m.jpg
    :width: 400px
    :align: center
    :height: 250px
    :alt: alternate text
    :figclass: align-center

CLARA data processing environment houses multiple service containers. Service containers use DPE shared memory for transferring data between services within the local (DPE) environment. 

.. _service-registration:

Service registration and discovery
==================================

The core of the CLARA registration and discovery mechanism is the normative registry service that the CLARA services and service containers are registering with. The normative service, which is started within the DPE, functions as a naming and directory service for entire CLARA cloud infrastructure. Services and service-containers in the CLARA registry are described using unique names, types and descriptions. The CLARA naming convention defines the service container name as:

*DPE_host_IP_address:service_container_name*

where the service_container_name is an arbitrary string specified by the user. Likewise, the service name is constructed as:

*DPE_host_IP_address:service_container_name:service_engine_name* 

The engine name is the class that implements CLARA interface. Querying the name and a service description defines the service discovery process. The service is advertised by its service description in the registry. By retrieving this service information, the user can discover services. Note that at the moment the service and/or service container discovery process is modest, and is not taking into account service functional information. 

.. _service-granularity:

Service granularity
===================

Service granularity describes the amount of data processing performed by a single request to a service. There is no single suggested size for all CLARA services. To define the size of a service one should take into account the following (application specific) design requirements:

*	Service invocation/request frequencies

*	Service network distribution

*	The data amount passed during the service interaction

In addition to the distribution and data transfer, it is important that the granularity of a service match the functional modularity of a data processing application. One should also consider designing services with finer granularity in case there is a functionality that is going to be cloned and/or changed over time.

.. _service-accessibility:

Service accessibility
=====================

Service accessibility describes the intended class of users of a service. CLARA implements two types of service visibility, described as either public or private. Public visibility means that all users within the CLARA cloud infrastructure are able to discover and use the service. Private means that service can be discovered, but will respond to specific clients (orchestrators and/or services) only.

.. _service-invocation:

Service invocation
==================

CLARA services are invoked using SOA most common Request/Reply communication mechanism. Two separate implementations of this mechanism are supported: synchronous and asynchronous. The basic mechanism of the synchronous service communication is when the requestor service sends a request to a service and waits. When the service has processed the request, it sends a reply. The requestor receives the reply and resumes it’s internal processing. (Note: synchronous mode is not implemented for version 0.1) 
The asynchronous communication mechanism is based on an event-based approach, most commonly known as publish/subscribe communication. This type of communication is native to CLARA, which is using 0MQ publish/subscribe middleware for message passing between services. In this mode, a requester defines an event or subject of interest and subscribes to this event. Next requester sends its request to the receiver service along with the subject to which the response must be returned. Whenever the service is ready it publishes the response to the requested subject.   

.. _transient-data-envelope:

Transient data
==============
Transient data is packaged inside of the CLARA transient envelope, that is constructed using 0MQ puyb-sub multipart message construct. The envelope consists of 4 parts (see figure below).

.. figure:: /_static/pictures/Slide9.jpg
    :width: 600px
    :align: center
    :height: 350px
    :alt: alternate text
    :figclass: align-center


The first field of the envelope is the pub/sub subject that defines the communication routing between subscriber and the publisher. The sender is the author of the envelope, i.e. the publisher of the message. The *data_type* filed defines the type of the data passed within the envelope. The following types are currently supported:

       * String

       * List of strings

       * CLARA transient data

CLARA transient data type is used to describe the CLARA transient data object that is serialized/de-serialized using google's protocol buffers.

Think of a CLARA service as a combination of its interface (the public view of the service), and its algorithmic implementation (the private view of the service). A CLARA service interface provides the following functionalities:

*	Hides the details of the implementation

*	Expresses the service’s functions

*	Provides parameters for the service operations

A CLARA service is a software component that offers functionality on a semantic level by specifying its interface in a standardized way. A semantic level refers to a service that is self-descriptive in a way that it can be consumed dynamically and loosely coupled by other CLARA services with a consistent understanding of communicating data.  The major backbone of the CLARA system is data. Data fed to services, generate a data processing action.  All data sent between services are required to be self-descriptive. 
A transient data structure that contains service data is the main object passed between CLARA services. The mutual understanding and acceptance of this object couples services. When we say CLARA services are loosely coupled we mean that this transient data object is the one and only physical coupling between CLARA services.
In the CLARA framework a special class that has implementations both in Java, C++(not supported in version 0.1) and Python represent the transient data. This class contains fields and methods to pack and retrieve transient data as well as describe data, service communication and service operational details. Fields of the CLARA transient data are show in the Figure below.

.. figure:: /_static/pictures/Slide1.jpg
    :width: 600px
    :align: center
    :height: 350px
    :alt: alternate text
    :figclass: align-center


The meta-data segment of the transient data structure defines the data type, version, and the author of the transient data object. The communication segment of the data structure is designed to inform the receiving service of the engine execution status of the source service. Even though we consider only event level parallelization for CLARA based data processing applications, we do not discard the possibility of having multi-tier services (services that are shared by multiple service based applications) in service compositions for building certain data processing applications. The *requestID* is designed to synchronize request/response pairs.
The control segment of the transient data informs the receiver if there is a external listener for exception and/or data produced by a service.
Any exception thrown during the execution of the service engine will be passed on following the predefined data pass of the data processing application (dynamic or static routing), yet the control fields will inform service to broadcast exception and or data messages to a predefined exception and data topics. The done broadcast message is designed not to have the data object in it. Contrary to the fact that service can broadcast done, exception and data to be broadcasted, errors and warnings are passed through a *status* field of the transient data by the service container in case service engine or service container detect a specific alarm condition.   It is important to mention that the name of the service (canonical name) defines the physical location of the service.  The location information is important to design data processing applications with the location-optimized communications within the CLARA network distributed cloud. The location information is also useful when querying sets of data generated in an area of interest (for example any orchestrator that subscribes data from a specific service). Data versioning is a relatively new requirement within data processing, yet very useful for reporting purposes. It is a common means to track services that processed data. This is useful within the system because of how service data processing algorithms and solutions are hidden from direct access.  The *controlRR* of the control segment of the transient data is reserved to control/configure (for example to alter the configuration of the service specified for communication) service engine at the run time (not implemented for version 0.1).


.. _service-communication-monitoring:

Service communication monitoring
================================

Auditing and logging play an important role within the distributed CLARA cloud. The anticipated complexity of data processing applications, scaled over multiple CLARA data processing (DPE) environments and multiple service containers, requires tracking and constant monitoring of service communications and in some cases data flows between services.  Reliable service communications ensure that the data gets to its intended destination, thus assuring overall CLARA application quality. As part of the framework’s administrative and management capabilities, CLARA provides auditing and logging services. These services are deployed within the CLARA DPE and can have multiple means for tracking service communications and data. System-level information about the health of the service itself and the flow of messages can be tracked and monitored. Application-level auditing, logging, and fault handling are accomplished through the transient data metadata fields, namely the service execution *status* and *data*, *done* and *exception* monitors. The framework uses service data endpoints to deliver system-level errors, such as service engine thrown exceptions, as well as application-level errors.

.. _exception-propagation-reporting:

Exception propagation and reporting
===================================

There is an underlying philosophy behind the way that the communication tracking, system errors, and application faults are handled. In addition to the normal handling of the outgoing flow of transient data, additional destinations are available to the service for auditing the message and for reporting errors. The service container implementation uses special message subjects for reporting/tracking, system errors and application fault events (see paragraph titled “Transient data”). Anyone interested in these events can subscribe to the specific message subject and receive notification on the occurrence of specific events. From the service implementation's point of view, in the case of an exception it simply creates a CLARA transient data object with proper description of the event and publishes it to a specific, predefined message subject (topic). The CLARA framework takes care of managing processes, such as auditing, logging, and error reporting to all interested (subscribing) services and/or service orchestrators. This approach provides a separation between the implementation of the service and the details surrounding fault handling. The implementer of a service need only be concerned that the service has a place to put such information, whether it is information concerning the successful processing of a good data, or the reporting of errors and bad data.
Exception events can be handled at both the individual service level and the service orchestrator level. A data processing application may make use of different implementations of individual services over time. The tracking of a fault occurrence or the auditing of an individual message can be tied to the context of a data processing application’s independent orchestrator that overlooks the entire cloud deployment exception status. For this purpose the CLARA framework provides a normative service that subscribes to specific exception events and logs them in the CLARA database.

.. _cloud-formation:

Cloud formation
================

Conceptually a CLARA data processing application designer and/or user acquires data processing services from a CLARA network distributed environment (i.e. cloud) and then designs and runs an application based on selected services. Therefore, CLARA cloud offers users services to access algorithms and applications, persistent and/or transient data resources. Figure below shows the relationship between services and the data transfer modes between services in a CLARA cloud environment.   A CLARA cloud consists of multiple data processing environments (see paragraph “Data processing environment, service container, and SaaS implementation”) each providing a complete run time environment for service deployment and operation. Each of the DPEs of the CLARA cloud host at least one service container with at least one service.

.. figure:: /_static/cloud_formation.jpg
    :width: 600px
    :align: center
    :height: 400px
    :alt: alternate text
    :figclass: align-center

CLARA Cloud formation 

Scalability and flexibility are the most important features driving the emergence of Cloud computing. CLARA services and DPEs can be scaled across geographical locations, software configurations and performances. For data transfer efficiency reasons, transient data communication between the same language service containers, within a DPE, is established through shared memory. The data that is sent across language barriers or across the network is transferred through pub-sub middleware.  

.. _application_composition:

Application composition
=======================

The Clara-p(j).zmq.0.1 introduces dynamic routing of the transient data envelopes.
The static routing or application design before application execution (application composition stage) is the main design choice of the previous version of the CLARA. The new version prefers dynamic transient data routing that makes CLARA service based application very flexible. Data routing information is stored within the transient data. The *composition* field of the transient data caries the information about the application service based design, telling the receiving service where from the input data is coming and where the result of the engine execution will be directed to. As a result CLARA application design can be altered during the application execution time.
The following CLARA application design operators are used to compose a service based application:


**+** : data link operator defining the data route. For example S1 **+** S2 indicates that the output data of the S1 service is linked to S2 as an input data.  

**,** : data multiplexing or *logical OR* operator. For example 


Example 1: S1 **+** S2 **,** S3 indicates that the output data of S1 service is send to both S2 and S3 services. 


Example 2: S1 **,** S2 **+** S3 indicates that output from S1 or S2 services will trigger S3 service engine.
 
.. figure:: /_static/pictures/Slide2.jpg
    :width: 600px
    :align: center
    :height: 400px
    :alt: alternate text
    :figclass: align-center
    
    
**&** : logical AND operator. For example S1 **,** S2 **+** **&** S3 indicates that S3 service engine will be executed only when both: S1 and S2 services complete their execution. In another words S3 service need S1 and S2 output data to complete its service.

**;** : data branching operator indicating the end of a composition and start of the new parallel composition. For example S1 **+** S2 **+** S3 **+** S4 **;** S3 **+** S5 **+** S6

.. figure:: /_static/pictures/Slide3.jpg
    :width: 600px
    :align: center
    :height: 400px
    :alt: alternate text
    :figclass: align-center
    



 
    
    



 


