
***********
User engine 
***********

User provided service engines must extend CLARA abstract class ACEngine. This class presents CLARA interface and some methods for exception reporting. The Python implementation of this class is shown below.

.. code-block:: c
	
	from abc import ABCMeta, abstractmethod
		
	
	class ACEngine(object):
    	"""
    	Clara service engine abstract class
    	"""
    	__metaclass__ = ABCMeta
	
    	exception_string = "undefined"
    	exception_severity = "undefined"
	
    	@abstractmethod
    	def execute(self, x):
        	pass
	
    	@abstractmethod
    	def execute_group(self, *argv):
        	pass
	
    	@abstractmethod
    	def configure(self, x):
        	pass
	
    	@abstractmethod
    	def get_states(self, x):
        	pass
	
    	@abstractmethod
    	def get_current_state(self, x):
        	pass
	
    	@abstractmethod
    	def get_accepted_data_type(self, x):
        	pass
	
    	@abstractmethod
    	def get_returned_data_type(self, x):
        	pass
	
    	@abstractmethod
    	def get_description(self):
        	pass
	
    	@abstractmethod
    	def get_version(self):
        	pass
	
    	@abstractmethod
    	def get_author(self):
        	pass
	
    	@abstractmethod
    	def dispose(self):
        	pass
	
    	def get_exception_string(self):
        	return self.exception_string
	
    	def get_exception_severity(self):
        	return self.exception_severity
	
    	def set_exception(self, exception_string, severity):
        	self.exception_string = exception_string
        	self.exception_severity = severity
	
    	def reset(self):
        	self.exception_string = "undefined"
        	self.exception_severity = "undefined"
	
.. _engine_class_example:

Engine class example
===========================

Engine class example below are for illustration purposes only and do not have any practical use, even though it can be used to generate data volume.

.. code-block:: c

	class Engine1(ACEngine):
    	def __init__(self):
        	pass
	
    	def execute(self, x):
        	print "INPUT SERVICE .....> "+x.sender
        	print "INPUT DATA    .....> "+x.data
        	x.data = 'a' * 10
	        return x
	
    	def execute_group(self, x):
	        print "MULTI-INPUT DATA .....> "
    	    for k in x:
         	print "INPUT SERVICE    .....> "+k.sender
       	    print k.data
        	x[0].data = 'm' * 10
        	return x[0]
	
    	def get_description(self):
        	return "service engine1 description"
	
    	def get_author(self):
        	return "gurjyan"
	
    	def get_version(self):
        	pass
	
    	def get_returned_data_type(self, x):
        	pass
	
    	def get_current_state(self, x):
        	pass
	
    	def get_states(self, x):
        	pass
	
    	def get_accepted_data_type(self, x):
        	pass
	
    	def configure(self, x):
        	pass
	
    	def dispose(self):
        	pass


