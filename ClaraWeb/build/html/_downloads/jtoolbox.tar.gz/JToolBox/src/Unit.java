import java.io.Serializable;

/**
 * <font size = 1 >JSA: Thomas Jefferson National Accelerator Facility<br>
 * This software was developed under a United States Government license,<br>
 * described in the NOTICE file included as part of this distribution.<br>
 * Copyright (c), 4/20/12 <br></font>
 * </p>
 *
 * @author Vardan Gyurjyan
 * @version 1.0
 */

public enum Unit implements Serializable {

    AMPER        ("ampere",       "A",      "--",       "A",                              "electric current"),
    CANDELA      ("candela",      "cd",     "--",       "cd",                             "luminous intensity"),
    COULOMB      ("coulomb",      "C",      "As",       "As",                             "charge"),
    FARAD        ("farad",        "F",      "As/V",     "kg-1 m-2 s4 A2",                 "capacitance"),
    GRAY         ("gray",         "Gy",     "J/kg",     "m2 s-2",                         "absorbed dose"),
    HENRY        ("henry",        "H",      "Vs/A",     "kg m2 s-2 A-2",                  "inductance"),
    HERTZ        ("hertz",        "Hz",     "1/s",      "s-1",                            "frequency"),
    JOUL         ("joule",        "J",      "Nm",       "kg m2 s-2",                      "energy"),
    KELVIN       ("kelvin",       "K",      "--",       "K",                              "temperature"),
    KILOGRAM     ("kilogram",     "kg",     "--",       "kg",                             "mass"),
    LUMEN        ("lumen",        "lm",     "cd sr",    "cd sr",                          "luminous flux"),
    LUX          ("lux",          "lx",     "lm/m2",    "cd sr m-2",                      "illumination"),
    METRE        ("metre",        "m",      "--",       "m",                              "length"),
    MOLE         ("mole",         "mol",    "--",       "mol",                            "amount of substance"),
    NEWTON       ("newton",       "N",      "kg m/s2",  "kg m s-2",                       "force"),
    OHM          ("ohm",          "O" ,     "V/A",      "kg m2 s-3 A-2",                  "resistance"),
    PASCAL       ("pascal",       "Pa",     "N/m2",     "kg m-1 s-2",                     "pressure"),
    RADIAN       ("radian",       "rad",    "--",       "rad",                            "plane angle"),
    SIEMENS      ("siemens",      "S",      "1/O",      "kg-1 m-2 s3 A2",                 "electric conductance"),
    SIEVERT      ("sievert",      "Sv",     "J/kg",     "m2 s-2",                         "dose equivalent"),
    STERADIAN    ("steradian",    "sr",     "--",       "sr",                             "solid angle"),
    TESLA        ("tesla",        "T",      "Wb/m2",    "kg s-2 A-1",                     "magnetic flux density"),
    VOLT         ("volt",         "V",      "W/A",      "kg m2 s-3 A-1",                  "voltage"),
    WATT         ("watt",         "W",      "J/s",      "kg m2 s-3",                      "power"),
    WEBER        ("weber",        "Wb",     "V s",      "kg m2 s-2 A-1",                  "magnetic flux"),
    SECOND       ("second",       "s",      "--",       "s",                              "time"),
    MINUTE       ("minute",       "min",    "--",       "60 s",                           "time"),
    HOURE        ("hour",         "h",      "--",       "60 min = 3600 s",                "time"),
    DAY          ("day",          "d",      "--",       "24 h = 86 400 s",                "time"),
    ARCMINUTE    ("arcminute",    "arcmin", "--",       "(1/60) deg = (pi/10 800) rad",   ""),
    ARCSECOND    ("arcsecond", 	  "arcsec", "--",       "(1/60)' = (pi/648 000) rad",     ""),
    DEGREE       ("degree",       "deg",    "--",       "(pi/180) rad",                   "angle"),
    LITRE        ("litre",        "L",      "--",       "1 dm3 = 10-3 m3",                ""),
    TONNE        ("tonne",        "t",      "--",       "1000 kg",                        ""),
    ELECTRONVOLT ("electronvolt", "eV",     "--",       "(1.60217733+-0.00000049)x10-19J","");

    private String uName,symbol,derivation,baseUnits, quantity;

    private Unit(String uName, String symbol, String derivation, String baseUnits, String quantity){
        this.uName      = uName;
        this.symbol     = symbol;
        this.derivation = derivation;
        this.baseUnits  = baseUnits;
        this.quantity   = quantity;
    }

    public String uName(){
        return uName;
    }

    public String symbol(){
        return symbol;
    }

    public String derivation(){
        return derivation;
    }

    public String baseUnits(){
        return baseUnits;
    }

    public String quantity(){
        return quantity;
    }

    public static Unit getUnitByuName(String uName){
        for(Unit u: Unit.values()){
            if (u.uName().equals(uName)) return u;
        }
        return null;
    }

    public static Unit getUnitBySymbol(String symbol){
        for(Unit u: Unit.values()){
            if (u.symbol().equals(symbol)) return u;
        }
        return null;
    }

}
