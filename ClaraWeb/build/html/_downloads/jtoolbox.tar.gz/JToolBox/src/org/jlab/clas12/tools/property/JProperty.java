package org.jlab.clas12.tools.property;


import org.jlab.clas12.tools.MimeType;

/**
 * <font size = 1 >JSA: Thomas Jefferson National Accelerator Facility<br>
 * This software was developed under a United States Government license,<br>
 * described in the NOTICE file included as part of this distribution.<br>
 * Copyright (c), 4/18/12 <br></font>
 * </p>
 *
 * @author Vardan Gyurjyan
 * @version 1.0
 */

public class JProperty implements Comparable<JProperty> {
    private String name;
    private String value;

    public JProperty(){
        name  = MimeType.UNDEFINED.type();
        value = MimeType.UNDEFINED.type();
    }

    public JProperty(String name, String value){
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public String getRoot() {
        String[] tokens = this.name.split("\\.");
	if(tokens.length<1) return null;
        return tokens[0];
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    @Override
    public boolean equals(Object o) {
        if(o instanceof JProperty){
            JProperty p = (JProperty)o;
            if(p.getName().equals(name) && p.getValue().equals(value)) return true;
        }
        return false;
    }

    @Override
    public int compareTo(JProperty p) {
        if(p.getName().equals(name) && p.getValue().equals(value)) return 0;
        return 1;
    }

    @Override
    public String toString()
    {
        return "JProperty [name=" + name + ", value=" + value + "]";
    }
}

