package org.jlab.clas12.tools.data.evio;


import java.nio.DoubleBuffer;
import java.nio.IntBuffer;
import java.util.Map;
import java.util.TreeMap;

import org.jlab.coda.jevio.DataType;
import org.jlab.coda.jevio.EvioCompactStructureHandler;
import org.jlab.coda.jevio.EvioNode;

/**
 * Wrapper to read CLAS12 bank data saved in EVIO-4.1 format.
 * <p>
 * The event format for CLAS12 is EVIO.
 * EVIO is organized in banks, similar to bosbanks.
 * There are some important differences though,
 * worth to mention for illustrative purposes:
 * <ul>
 *  <li>EVIO bank can contain not only variables but other banks as well.
 *  <li>bosbanks are identified by four characters
 *      (including space, like <code>EVNT</code>, <code>PART</code>,
 *      <code>EC</code>), while EVIO banks are identified by two integers:
 *      <strong>tag</strong> and <strong>num</strong>.
 *  <li>One CLAS event can contain different entry of the same BOS bank,
 *      and each BOS bank contains multiple variables.
 *      For example, there is one EVNT bank for every particles reconstructed,
 *      each containing the variables momentum, energy, etc.
 *      CLAS12 EVIO banks on the other hand contain only one type of variable,
 *      indexed by the hit. And there is one bank per variable.
 *      For example, there will be a  "momentum" bank, and a "energy" bank,
 *      the first entry of both corresponding to the first particle,
 *      the second entry to the second particle and so on.
 * </ul>
 * <p>
 * In CLAS12, each EVIO bank is identified by one integer number: its <em>tag</em>.
 * Each EVIO bank contains two "daughter" banks,
 * with the same <em>tag</em> as the mother but with:
 * <ul>
 *  <li>num = 100, used to store digitized information (ID, ADC, TDC)
 *      in arrays of integers.
 *  <li>num = 200, used to store "raw" information (energy deposited, position
 *      of the hit, etc) in arrays of doubles.
 *  <li>the "mother" bank has num = 0.
 * </ul>
 * The banks containing the variables always have the same <em>tag</em>
 * as the mothers, what identifies each variable is the <em>num</em>.
 * <p>
 * <font size = 1>JSA: Thomas Jefferson National Accelerator Facility<br>
 * This software was developed under a United States Government license,<br>
 * described in the NOTICE file included as part of this distribution.<br>
 * Copyright (c), Jan 22, 2013</font>
 *
 * @author      smancill
 */
public class Clas12BankReader
{
    /** The <em>num</em> of the daughter bank containing banks of integers */
    private static final int INT_BANK_NUM = 100;
    /** The <em>num</em> of the daughter bank containing banks of doubles */
    private static final int DOUBLE_BANK_NUM = 200;

    private final int tag;

    private Map<Integer, IntBuffer>    integerBanks = new TreeMap<Integer, IntBuffer>();
    private Map<Integer, DoubleBuffer> doubleBanks  = new TreeMap<Integer, DoubleBuffer>();


    /**
     * Creates an object to hold the data of a CLAS12 bank. This object
     * contains no data. It should be read from an existing EVIO event.
     *
     * @param tag the bank <em>tag</em>
     */
    public Clas12BankReader(int tag)
    {
        this.tag = tag;
    }


    /**
     * Gets the bank tag number.
     *
     * @return the bank <em>tag</em>
     */
    public int getTag()
    {
        return tag;
    }


    /**
     * Reads the bank data from an existing EVIO event.
     *
     * @param event the event with the bank data
     */
    public void initFromEvio(EvioCompactStructureHandler handler)
    {
        integerBanks.clear();
        doubleBanks.clear();

        EvioCompactStructureHandler integerBank = EvioDataHelper.getStructure(handler, tag, INT_BANK_NUM);
        if (integerBank != null) {
            for (EvioNode bank : integerBank.getChildNodes()) {
                int num = bank.getNum();
                IntBuffer data = EvioDataHelper.getIntData(integerBank, bank).asReadOnlyBuffer();
                if (data != null) {
                    integerBanks.put(num, data);
                } else {
                    System.err.println("[EVIO HOLDER]---> ERROR: tag = " + tag + "  num = " + num + " wrong entry");
                }
            }
        }

        EvioCompactStructureHandler doubleBank = EvioDataHelper.getStructure(handler, tag, DOUBLE_BANK_NUM);
        if (doubleBank != null) {
            for (EvioNode bank : doubleBank.getChildNodes()) {
                int num = bank.getNum();
                DoubleBuffer data = EvioDataHelper.getDoubleData(doubleBank, bank).asReadOnlyBuffer();
                if (data != null) {
                    doubleBanks.put(num, data);
                } else {
                    System.err.println("[EVIO HOLDER]---> ERROR: tag = " + tag + "  num = " + num + " wrong entry");
                }
            }
        }
    }


    /**
     * Checks if the bank has data.
     *
     * @return true if the bank contains banks of integers or doubles
     */
    public boolean isEmpty()
    {
        return integerBanks.size() == 0 && doubleBanks.size() == 0;
    }


    /**
     * Gets the full data of a bank of integers.
     *
     * @param num the bank <em>num</em>
     * @return the buffer with all the entries of the bank
     */
    public IntBuffer getIntegerData(int num)
    {
        return integerBanks.get(num);
    }


    /**
     * Gets the value of an entry in a bank of integers.
     * The indexes start from zero.
     *
     * @param num   the bank <em>num</em>
     * @param index the index of the item
     * @return the value of the item
     */
    public int getIntegerValue(int num, int index)
    {
        IntBuffer data = integerBanks.get(num);
        if (data != null && (index >= 0 && index < data.limit()))
            return data.get(index);
        return -1;
    }


    /**
     * Gets the full data of a bank of doubles.
     *
     * @param num the bank <em>num</em>
     * @return the buffer with all the entries of the bank
     */
    public DoubleBuffer getDoubleData(int num)
    {
        return doubleBanks.get(num);
    }


    /**
     * Gets the value of an entry in a bank of doubles.
     * The indexes start from zero.
     *
     * @param num   the bank <em>num</em>
     * @param index the index of the item
     * @return the value of the entry
     */
    public double getDoubleValue(int num, int index)
    {
        DoubleBuffer data = doubleBanks.get(num);
        if (data != null && (index >= 0 && index < data.limit()))
            return data.get(index);
        return -1;
    }


    /**
     * Gets the number of entries in a given data bank. The Clas12 bank format ensures that all
     * the data banks have the same number of entries.
     *
     * @param num the bank <em>num</em>
     * @return the number of entries or 0 if there is no bank with the given num
     */
    public int getBankSize(int num)
    {
        if (integerBanks.containsKey(num)) {
            return integerBanks.get(num).limit();
        } else if (doubleBanks.containsKey(num)) {
            return doubleBanks.get(num).limit();
        }
        return 0;
    }


    /**
     * Get the type of a data bank
     * @param num the num of the data bank
     * @return the type of the data in the bank, or unknown if there is no bank with the given num
     */
    DataType getDataType(int num)
    {
        if (integerBanks.containsKey(num)) {
            return DataType.INT32;
        } else if (doubleBanks.containsKey(num)) {
            return DataType.DOUBLE64;
        }
        return DataType.UNKNOWN32;
    }
}
