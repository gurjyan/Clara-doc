package org.jlab.clas12.tools.data.evio;

import java.nio.ByteOrder;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import org.jlab.coda.jevio.BaseStructure;
import org.jlab.coda.jevio.DataType;
import org.jlab.coda.jevio.EventBuilder;
import org.jlab.coda.jevio.EvioBank;
import org.jlab.coda.jevio.EvioEvent;
import org.jlab.coda.jevio.EvioException;

/**
 * Wrapper to access CLAS12 bank data saved in EVIO-4 format.
 * <p>
 * The event format for CLAS12 is EVIO.
 * EVIO is organized in banks, similar to bosbanks.
 * There are some important differences though,
 * worth to mention for illustrative purposes:
 * <ul>
 *  <li>EVIO bank can contain not only variables but other banks as well.
 *  <li>bosbanks are identified by four characters
 *      (including space, like <code>EVNT</code>, <code>PART</code>,
 *      <code>EC</code>), while EVIO banks are identified by two integers:
 *      <strong>tag</strong> and <strong>num</strong>.
 *  <li>One CLAS event can contain different entry of the same BOS bank,
 *      and each BOS bank contains multiple variables.
 *      For example, there is one EVNT bank for every particles reconstructed,
 *      each containing the variables momentum, energy, etc.
 *      CLAS12 EVIO banks on the other hand contain only one type of variable,
 *      indexed by the hit. And there is one bank per variable.
 *      For example, there will be a  "momentum" bank, and a "energy" bank,
 *      the first entry of both corresponding to the first particle,
 *      the second entry to the second particle and so on.
 * </ul>
 * <p>
 * In CLAS12, each EVIO bank is identified by one integer number: its <em>tag</em>.
 * Each EVIO bank contains two "daughter" banks,
 * with the same <em>tag</em> as the mother but with:
 * <ul>
 *  <li>num = 100, used to store digitized information (ID, ADC, TDC)
 *      in arrays of integers.
 *  <li>num = 200, used to store "raw" information (energy deposited, position
 *      of the hit, etc) in arrays of doubles.
 *  <li>the "mother" bank has num = 0.
 * </ul>
 * The banks containing the variables always have the same <em>tag</em>
 * as the mothers, what identifies each variable is the <em>num</em>.
 * <p>
 * <font size = 1>JSA: Thomas Jefferson National Accelerator Facility<br>
 * This software was developed under a United States Government license,<br>
 * described in the NOTICE file included as part of this distribution.<br>
 * Copyright (c), Mar 19, 2012</font>
 *
 * @author      smancill
 */
@Deprecated
public class EvioBankHolder
{
    /** The <em>num</em> of the mother bank */
    public static final int BANK_NUM = 0;
    /** The <em>num</em> of the daughter bank containing banks of integers */
    public static final int INT_BANK_NUM = 100;
    /** The <em>num</em> of the daughter bank containing banks of doubles */
    public static final int DOUBLE_BANK_NUM = 200;

    private final int tag;

    private Map<Integer, int[]>    integerBanks = new TreeMap<Integer, int[]>();
    private Map<Integer, double[]> doubleBanks  = new TreeMap<Integer, double[]>();


    /**
     * Create an object to hold the data of a CLAS12 bank. This object
     * contains no data. It should be read from an existing EVIO event, or the
     * banks of integers and doubles should be created and filled.
     *
     * @param tag the bank <em>tag</em>
     */
    public EvioBankHolder(int tag)
    {
        this.tag = tag;
    }


    /**
     * Get the bank tag number.
     *
     * @return the bank <em>tag</em>
     */
    public int getTag()
    {
        return tag;
    }


    /**
     * Check if the bank has data.
     *
     * @return true if the bank contains banks of integers or doubles
     */
    public boolean isEmpty()
    {
        return integerBanks.size() == 0 && doubleBanks.size() == 0;
    }


    /**
     * Read the bank data from an existing EVIO event.
     *
     * @param event the event with the bank data
     */
    public void initFromEvio(EvioEvent event)
    {
        BaseStructure baseBank = EvioDataHelper.findChild(event, tag, BANK_NUM);
        if (baseBank == null) {
            return;
        }

        BaseStructure integerBank = EvioDataHelper.findChild(baseBank, tag, INT_BANK_NUM);
        if (integerBank != null) {
            // If no children, getChildren() method should return an empty Vector, not null
            List<BaseStructure> children = integerBank.getChildren();
            if (children != null) {
                for (BaseStructure bank : integerBank.getChildren()) {
                    int num = bank.getHeader().getNumber();
                    int[] data = bank.getIntData();
                    if (data != null) {
                        integerBanks.put(num, data);
                    } else {
                        System.err.println("[EVIO HOLDER]---> ERROR: tag = " + tag + "  num = " + num + " wrong entry");
                    }
                }
            }
        }

        BaseStructure doubleBank = EvioDataHelper.findChild(baseBank, tag, DOUBLE_BANK_NUM);
        if (doubleBank != null) {
            // If no children, getChildren() method should return an empty Vector, not null
            List<BaseStructure> children = doubleBank.getChildren();
            if (children != null) {
                for (BaseStructure bank : doubleBank.getChildren()) {
                    int num = bank.getHeader().getNumber();
                    double[] data = bank.getDoubleData();
                    if (data != null) {
                        doubleBanks.put(num, data);
                    } else {
                        System.err.println("[EVIO HOLDER]---> ERROR: tag = " + tag + "  num = " + num + " wrong entry");
                    }
                }
            }
        }
    }


    /**
     * Save the bank data into an EVIO event.
     *
     * @param event the event where the bank will be saved
     */
    public void fillEvioTree(EvioEvent event)
    {
        EventBuilder builder = new EventBuilder(event);
        ByteOrder byteOrder = event.getByteOrder();

        EvioBank baseBank   = new EvioBank(tag, DataType.BANK, BANK_NUM);
        EvioBank intBank    = new EvioBank(tag, DataType.BANK, INT_BANK_NUM);
        EvioBank doubleBank = new EvioBank(tag, DataType.BANK, DOUBLE_BANK_NUM);

        baseBank.setByteOrder(byteOrder);
        intBank.setByteOrder(byteOrder);
        doubleBank.setByteOrder(byteOrder);

        try {
            for (Entry<Integer, int[]> bank : integerBanks.entrySet()) {
                EvioBank dataBank = new EvioBank(tag, DataType.INT32, bank.getKey());
                dataBank.setByteOrder(byteOrder);
                dataBank.appendIntData(bank.getValue());
                builder.addChild(intBank, dataBank);
            }

            for (Entry<Integer, double[]> bank : doubleBanks.entrySet()) {
                EvioBank dataBank = new EvioBank(tag, DataType.DOUBLE64, bank.getKey());
                dataBank.setByteOrder(byteOrder);
                dataBank.appendDoubleData(bank.getValue());
                builder.addChild(doubleBank, dataBank);
            }

            builder.addChild(baseBank, intBank);
            builder.addChild(baseBank, doubleBank);
            builder.addChild(event, baseBank);
        } catch (EvioException e) {
            e.printStackTrace();
        }
    }


    /**
     * Create a new empty bank of integers.
     *
     * @param num    the bank <em>num</em>
     * @param length the number of items in the bank
     * @see #setIntegerValue(int, int, int)
     */
    public void createIntegerBank(int num, int length)
    {
        if (length > 0)
            integerBanks.put(num, new int[length]);
    }


    /**
     * Create and fill a new bank of integers.
     *
     * @param num the bank <em>num</em>
     * @param data an array holding the data of the bank
     */
    public void createIntegerBank(int num, int[] data)
    {
        if (data != null && data.length > 0)
            integerBanks.put(num, data);
    }


    /**
     * Set the value of an item in a bank of integers.
     * The indexes start from zero.
     *
     * @param num   the bank <em>num</em>
     * @param index the index of the item
     * @param value the value of the item
     */
    public void setIntegerValue(int num, int index, int value)
    {
        int[] data = integerBanks.get(num);
        if (data != null && (index >= 0 && index < data.length))
            data[index] = value;
    }


    /**
     * Get the value of an item in a bank of integers.
     * The indexes start from zero.
     *
     * @param num   the bank <em>num</em>
     * @param index the index of the item
     * @return the value of the item
     */
    public int getIntegerValue(int num, int index)
    {
        int[] data = integerBanks.get(num);
        if (data != null && (index >= 0 && index < data.length))
            return data[index];
        return -1;
    }


    /**
     * Create a new empty bank of doubles.
     *
     * @param num    the bank <em>num</em>
     * @param length the number of items in the bank
     * @see #setDoubleValue(int, int, double)
     */
    public void createDoubleBank(int num, int length)
    {
        if (length > 0)
            doubleBanks.put(num, new double[length]);
    }


    /**
     * Create and fill a new bank of doubles.
     *
     * @param num the bank <em>num</em>
     * @param data an array holding the data of the bank
     */
    public void createDoubleBank(int num, double[] data)
    {
        if (data != null && data.length > 0)
            doubleBanks.put(num, data);
    }


    /**
     * Set the value of an item in a bank of doubles.
     * The indexes start from zero.
     *
     * @param num   the bank <em>num</em>
     * @param index the index of the item
     * @param value the value of the item
     */
    public void setDoubleValue(int num, int index, double value)
    {
        double[] data = doubleBanks.get(num);
        if (data != null && (index >= 0 && index < data.length))
            data[index] = value;
    }


    /**
     * Get the value of an item in a bank of doubles.
     * The indexes start from zero.
     *
     * @param num   the bank <em>num</em>
     * @param index the index of the item
     * @return the value of the item
     */
    public double getDoubleValue(int num, int index)
    {
        double[] data = doubleBanks.get(num);
        if (data != null && (index >= 0 && index < data.length))
            return data[index];
        return -1;
    }


    /**
     * Get the number of items in a bank.
     *
     * @param num the bank <em>num</em>
     * @return the number of items
     */
    public int getBankSize(int num)
    {
        if (integerBanks.containsKey(num)) {
            return integerBanks.get(num).length;
        } else if (doubleBanks.containsKey(num)) {
            return doubleBanks.get(num).length;
        }
        return 0;
    }
}
