package org.jlab.clas12.tools.data.evio;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import org.jlab.coda.jevio.DataType;
import org.jlab.coda.jevio.EventBuilder;
import org.jlab.coda.jevio.EvioBank;
import org.jlab.coda.jevio.EvioCompactStructureHandler;
import org.jlab.coda.jevio.EvioEvent;
import org.jlab.coda.jevio.EvioException;

/**
 * Wrapper to write CLAS12 bank data in EVIO-4.1 format.
 * <p>
 * The event format for CLAS12 is EVIO.
 * EVIO is organized in banks, similar to bosbanks.
 * There are some important differences though,
 * worth to mention for illustrative purposes:
 * <ul>
 *  <li>EVIO bank can contain not only variables but other banks as well.
 *  <li>bosbanks are identified by four characters
 *      (including space, like <code>EVNT</code>, <code>PART</code>,
 *      <code>EC</code>), while EVIO banks are identified by two integers:
 *      <strong>tag</strong> and <strong>num</strong>.
 *  <li>One CLAS event can contain different entry of the same BOS bank,
 *      and each BOS bank contains multiple variables.
 *      For example, there is one EVNT bank for every particles reconstructed,
 *      each containing the variables momentum, energy, etc.
 *      CLAS12 EVIO banks on the other hand contain only one type of variable,
 *      indexed by the hit. And there is one bank per variable.
 *      For example, there will be a  "momentum" bank, and a "energy" bank,
 *      the first entry of both corresponding to the first particle,
 *      the second entry to the second particle and so on.
 * </ul>
 * <p>
 * In CLAS12, each EVIO bank is identified by one integer number: its <em>tag</em>.
 * Each EVIO bank contains two "daughter" banks,
 * with the same <em>tag</em> as the mother but with:
 * <ul>
 *  <li>num = 100, used to store digitized information (ID, ADC, TDC)
 *      in arrays of integers.
 *  <li>num = 200, used to store "raw" information (energy deposited, position
 *      of the hit, etc) in arrays of doubles.
 *  <li>the "mother" bank has num = 0.
 * </ul>
 * The banks containing the variables always have the same <em>tag</em>
 * as the mothers, what identifies each variable is the <em>num</em>.
 * <p>
 * <font size = 1>JSA: Thomas Jefferson National Accelerator Facility<br>
 * This software was developed under a United States Government license,<br>
 * described in the NOTICE file included as part of this distribution.<br>
 * Copyright (c), Jan 22, 2012</font>
 *
 * @author      smancill
 */
public class Clas12BankWriter
{
    /** The <em>num</em> of the mother bank */
    private static final int BANK_NUM = 0;
    /** The <em>num</em> of the daughter bank containing banks of integers */
    private static final int INT_BANK_NUM = 100;
    /** The <em>num</em> of the daughter bank containing banks of doubles */
    private static final int DOUBLE_BANK_NUM = 200;

    private final int tag;

    private Map<Integer, int[]>    integerBanks = new TreeMap<Integer, int[]>();
    private Map<Integer, double[]> doubleBanks  = new TreeMap<Integer, double[]>();


    /**
     * Creates an object to hold the data of a CLAS12 bank. This object
     * contains no data. The banks of integers and doubles should be created and
     * filled. Then it can be written to an EVIO event.
     *
     * @param tag the bank <em>tag</em>
     */
    public Clas12BankWriter(int tag)
    {
        this.tag = tag;
    }


    /**
     * Gets the bank tag number.
     *
     * @return the bank <em>tag</em>
     */
    public int getTag()
    {
        return tag;
    }


    /**
     * Checks if the bank has data.
     *
     * @return true if the bank contains banks of integers or doubles
     */
    public boolean isEmpty()
    {
        return integerBanks.size() == 0 && doubleBanks.size() == 0;
    }


    /**
     * Saves the bank data into an EVIO event.
     *
     * @param handler the structure handler of the event where the bank will be saved
     */
    public void fillEvioTree(EvioCompactStructureHandler handler)
    {
        EvioEvent baseBank = new EvioEvent(tag, DataType.BANK, BANK_NUM);
        EvioBank intBank = new EvioBank(tag, DataType.BANK, INT_BANK_NUM);
        EvioBank doubleBank = new EvioBank(tag, DataType.BANK, DOUBLE_BANK_NUM);

        EventBuilder builder = new EventBuilder(baseBank);
        ByteOrder byteOrder = handler.getByteBuffer().order();

        baseBank.setByteOrder(byteOrder);
        intBank.setByteOrder(byteOrder);
        doubleBank.setByteOrder(byteOrder);

        try {
            for (Entry<Integer, int[]> bank : integerBanks.entrySet()) {
                EvioBank dataBank = new EvioBank(tag, DataType.INT32, bank.getKey());
                dataBank.setByteOrder(byteOrder);
                dataBank.appendIntData(bank.getValue());
                builder.addChild(intBank, dataBank);
            }

            for (Entry<Integer, double[]> bank : doubleBanks.entrySet()) {
                EvioBank dataBank = new EvioBank(tag, DataType.DOUBLE64, bank.getKey());
                dataBank.setByteOrder(byteOrder);
                dataBank.appendDoubleData(bank.getValue());
                builder.addChild(doubleBank, dataBank);
            }

            builder.addChild(baseBank, intBank);
            builder.addChild(baseBank, doubleBank);

            int byteSize = baseBank.getTotalBytes();
            ByteBuffer bb = ByteBuffer.allocate(byteSize);
            bb.order(byteOrder);
            baseBank.write(bb);
            bb.flip();

            handler.addStructure(bb);
        } catch (EvioException e) {
            e.printStackTrace();
        }
    }


    /**
     * Creates a new empty bank of integers.
     *
     * @param num    the bank <em>num</em>
     * @param length the number of entries in the bank
     * @see #setIntegerValue(int, int, int)
     */
    public void createIntegerBank(int num, int length)
    {
        if (length > 0)
            integerBanks.put(num, new int[length]);
    }


    /**
     * Creates and fill a new bank of integers.
     *
     * @param num the bank <em>num</em>
     * @param data an array holding the data of the bank
     */
    public void createIntegerBank(int num, int[] data)
    {
        if (data != null && data.length > 0)
            integerBanks.put(num, data);
    }


    /**
     * Sets the value of an entry in a bank of integers.
     * The indexes start from zero.
     *
     * @param num   the bank <em>num</em>
     * @param index the index of the entry
     * @param value the value of the entry
     */
    public void setIntegerValue(int num, int index, int value)
    {
        int[] data = integerBanks.get(num);
        if (data != null && (index >= 0 && index < data.length))
            data[index] = value;
    }


    /**
     * Creates a new empty bank of doubles.
     *
     * @param num    the bank <em>num</em>
     * @param length the number of entries in the bank
     * @see #setDoubleValue(int, int, double)
     */
    public void createDoubleBank(int num, int length)
    {
        if (length > 0)
            doubleBanks.put(num, new double[length]);
    }


    /**
     * Creates and fill a new bank of doubles.
     *
     * @param num the bank <em>num</em>
     * @param data an array holding the data of the bank
     */
    public void createDoubleBank(int num, double[] data)
    {
        if (data != null && data.length > 0)
            doubleBanks.put(num, data);
    }


    /**
     * Sets the value of an entry in a bank of doubles.
     * The indexes start from zero.
     *
     * @param num   the bank <em>num</em>
     * @param index the index of the entry
     * @param value the value of the entry
     */
    public void setDoubleValue(int num, int index, double value)
    {
        double[] data = doubleBanks.get(num);
        if (data != null && (index >= 0 && index < data.length))
            data[index] = value;
    }


    /**
     * Gets the number of entries in a bank.
     *
     * @param num the bank <em>num</em>
     * @return the number of entries
     */
    public int getBankSize(int num)
    {
        if (integerBanks.containsKey(num)) {
            return integerBanks.get(num).length;
        } else if (doubleBanks.containsKey(num)) {
            return doubleBanks.get(num).length;
        }
        return 0;
    }
}
