package org.jlab.clas12.tools.data.evio;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.DoubleBuffer;
import java.nio.IntBuffer;
import java.util.List;

import org.jlab.coda.jevio.BaseStructure;
import org.jlab.coda.jevio.BaseStructureHeader;
import org.jlab.coda.jevio.DataType;
import org.jlab.coda.jevio.EventWriter;
import org.jlab.coda.jevio.EvioCompactStructureHandler;
import org.jlab.coda.jevio.EvioEvent;
import org.jlab.coda.jevio.EvioException;
import org.jlab.coda.jevio.EvioNode;
import org.jlab.coda.jevio.EvioReader;


/**
 * Auxiliary class to work with CLAS12 EVIO-4.1 events.
 * <p>
 * <font size = 1>JSA: Thomas Jefferson National Accelerator Facility<br>
 * This software was developed under a United States Government license,<br>
 * described in the NOTICE file included as part of this distribution.<br>
 * Copyright (c), Apr 18, 2012</font>
 *
 * @author      smancill
 */
public class EvioDataHelper
{
    /**
     * Converts a byte array into an EvioEvent.
     *
     * @param serializedEvent  the byte array representing the event
     * @return the event object or null if the byte array could not be parsed to an event.
     */
    @Deprecated
    public static final Object bytesToEvio(byte[] serializedEvent)
    {
        EvioEvent event = null;
        try {
            EvioReader reader;
            reader = new EvioReader(ByteBuffer.wrap(serializedEvent));
            event = reader.parseNextEvent();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (EvioException e) {
            e.printStackTrace();
        }
        return event;
    }


    /**
     * Converts an EvioEvent into a byte array.
     *
     * @param event the event been serialized
     * @return the byte array representing the event or null if the type
     *         of the event is not EvioEvent
     */
    @Deprecated
    public static final byte[] evioToBytes(Object event)
    {
        byte[] serializedEvent = null;

        if (event == null || !(event instanceof EvioEvent)) {
            System.err.println("EVIO to bytes error: object been serialized is not an EVIO event");
        } else {
            EvioEvent inputEvent = (EvioEvent) event;

            final int maxBanksPerBlock    = 100;
            final int maxBlockSizeInBytes = 1000000;

            ByteBuffer bufferedEvent = ByteBuffer.allocate(inputEvent.getTotalBytes() + 128);

            try {
                EventWriter writer = new EventWriter(bufferedEvent, maxBlockSizeInBytes, maxBanksPerBlock, null, null);
                writer.writeEvent(inputEvent);
                writer.close();
                bufferedEvent.flip();
                serializedEvent = bufferedEvent.array();
            } catch (EvioException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return serializedEvent;
    }


    /**
     * Gets the ID of the event.
     *
     * @return the ID
     */
    @Deprecated
    public static int getEventID(EvioEvent event)
    {
        int id = -1;
        BaseStructure idBank = findChild(event, 1, 1);
        if (idBank != null) {
            id = idBank.getIntData()[0];
        }
        return id;
    }


    /**
     * Gets the ID of the event.
     *
     * @return the ID
     */
    public static int getEventID(EvioCompactStructureHandler event)
    {
        int id = -1;
        try {
            List<EvioNode> idBanks = event.searchStructure(1, 1);
            if (!idBanks.isEmpty()) {
                id = event.getData(idBanks.get(0)).asIntBuffer().get(0);
            }
        } catch (EvioException e) {
            e.printStackTrace();
        }
        return id;
    }


    /**
     * Finds an specific child in the list of children of the given structure.
     * The search is not recursive.
     *
     * @param parent the parent structure
     * @param tag    the <em>tag</em> of the structure been searched
     * @param num    the <em>num</em> of the structure been searched
     *
     * @return the child bank been searched or null if not found
     */
    public static final BaseStructure findChild(BaseStructure parent, int tag, int num)
    {
        if (parent == null)
            throw new NullPointerException();

        // If no children, getChildren() method should return an empty Vector, not null
        List<BaseStructure> children = parent.getChildren();
        if(children == null)
            return null;

        for (BaseStructure child : children) {
            BaseStructureHeader header = child.getHeader();
            if (header.getTag() == tag && header.getNumber() == num)
                return child;
        }

        return null;
    }


    /**
     * Extracts a bank of banks from a given event.
     *
     * @param handler the event containing the desired bank of banks
     * @param tag the <em>tag</em> to identify the banks of banks
     * @param num the <em>num</em> to identify the banks of banks
     *
     * @return the bank of banks or null if not found
     */
    public static final EvioCompactStructureHandler getStructure(EvioCompactStructureHandler handler, int tag, int num)
    {
        EvioCompactStructureHandler structure = null;
        try {
            List<EvioNode> structures = handler.searchStructure(tag, num);
            if (!structures.isEmpty()) {
                ByteBuffer buffer = handler.getStructureBuffer(structures.get(0));
                structure = new EvioCompactStructureHandler(buffer, DataType.BANK);
            }
        } catch (EvioException e) {
            // Nothing
        }
        return structure;
    }


    /**
     * Gets the data of a leaf bank as an IntBuffer.
     *
     * @param parent the parent bank
     * @param leaf the leaf bank
     * @return the full data of the leaf bank or null if the type of the node is not integer
     */
    public static final IntBuffer getIntData(EvioCompactStructureHandler parent, EvioNode leaf)
    {
        switch (leaf.getDataTypeObj()) {
            case INT32:
            case UINT32:
                return parent.getData(leaf).asIntBuffer();
            default:
                return null;
        }
    }


    /**
     * Gets the data of a leaf bank as a DoubleBuffer.
     *
     * @param parent the parent bank
     * @param leaf the leaf bank
     * @return the full data of the leaf bank or null if the type of the node is not double
     */
    public static final DoubleBuffer getDoubleData(EvioCompactStructureHandler parent, EvioNode leaf)
    {
        switch (leaf.getDataTypeObj()) {
            case DOUBLE64:
                return parent.getData(leaf).asDoubleBuffer();
            default:
                return null;
        }
    }
}
