package org.jlab.clas12.tools;

import java.io.Serializable;

/**
 * <font size = 1 >JSA: Thomas Jefferson National Accelerator Facility<br>
 * This software was developed under a United States Government license,<br>
 * described in the NOTICE file included as part of this distribution.<br>
 * Copyright (c), 4/18/12 <br></font>
 * </p>
 *
 * @author Vardan Gyurjyan
 * @version 1.0
 */

public enum MimeType implements Serializable {
    UNDEFINED        (0,  "undefined"),
    IG5              (197,"binary/data-ig5"),
    EVIO             (198,"binary/data-evio"),
    OBJECT           (200,"binary/data-object"),
    JOBJECT          (201,"binary/object-java"),
    COBJECT          (202,"binary/object-cpp"),
    BYTE             (203,"binary/byte"),
    SHORT            (204,"binary/short"),
    INT              (205,"binary/int"),
    FLOAT            (206,"binary/float"),
    DOUBLE           (207,"binary/double"),
    STRING           (208,"text/string"),
    BYTE_ARRAY       (209,"binary/array-byte"),
    SHORT_ARRAY      (210,"binary/array-short"),
    INT_ARRAY        (211,"binary/array-int"),
    FLOAT_ARRAY      (212,"binary/array-float"),
    DOUBLE_ARRAY     (213,"binary/array-double"),
    STRING_ARRAY     (214,"binary/array-string"),
    OBJECT_ARRAY     (215,"binary/array-object"),
    PROPERTY_LIST    (216,"text/property-list"),
    CHAR_BYTEARRAY   (217,"binary/char-bytearray"),
    SHORT_BYTEARRAY  (218,"binary/short-bytearray"),
    INT_BYTEARRAY    (219,"binary/int-bytearray"),
    FLOAT_BYTEARRAY  (220,"binary/float-bytearray"),
    DOUBLE_BYTEARRAY (221,"binary/double-bytearray");

    private final int    typeId;
    private final String type;

    private MimeType(int typeId, String type){
        this.typeId = typeId;
        this.type   = type;
    }

    public int id(){
        return typeId;
    }

    public String type(){
        return type;
    }

    @Deprecated
    public static MimeType getEnum(int id){
        for(MimeType dt: MimeType.values()){
            if (dt.id()==id) return dt;
        }
        return UNDEFINED;
    }

    @Deprecated
    public static MimeType getEnum(String type){
        for(MimeType dt: MimeType.values()){
            if (dt.type().equals(type.trim())) return dt;
        }
        return UNDEFINED;
    }

    public static MimeType getMimeType(int id){
        for(MimeType dt: MimeType.values()){
            if (dt.id()==id) return dt;
        }
        return UNDEFINED;
    }

    public static MimeType getMimeType(String type){
        for(MimeType dt: MimeType.values()){
            if (dt.type().equals(type.trim())) return dt;
        }
        return UNDEFINED;
    }
}

