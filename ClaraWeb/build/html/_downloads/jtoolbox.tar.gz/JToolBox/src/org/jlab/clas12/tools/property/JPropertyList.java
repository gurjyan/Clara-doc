package org.jlab.clas12.tools.property;

import org.jlab.clas12.tools.MimeType;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

/**
 * <font size = 1 >JSA: Thomas Jefferson National Accelerator Facility<br>
 * This software was developed under a United States Government license,<br>
 * described in the NOTICE file included as part of this distribution.<br>
 * Copyright (c), 4/18/12 <br></font>
 * </p>
 *
 * @author Vardan Gyurjyan
 * @version 1.0
 */

public class JPropertyList {
    private String pListString;
    private List<JProperty> pContainer  = new LinkedList<JProperty>();

    public JPropertyList(){
        // nothing
    }

    public JPropertyList(JProperty[] props){
        Collections.addAll(pContainer, props);
        pListString = packProperties(pContainer);
    }

    public JPropertyList(String pls){
        unpackPropertyList(pls);
        pListString = packProperties(pContainer);
    }

    private int getIndexOfProperty(String pName){
        ListIterator<JProperty> iter = pContainer.listIterator();
        while(iter.hasNext()){
            JProperty p = iter.next();
            if(p.getName().equals(pName)){
                return iter.previousIndex();
            }
        }
        return -1;
    }

    private void unpackPropertyList (String pList) {
        int marker=0, beginning=0, end=0, length=0;
        String pName, pValue;
        pList  = pList.trim();

        do {
            pName   = MimeType.UNDEFINED.type();
            pValue  = MimeType.UNDEFINED.type();

            end = pList.substring(beginning).indexOf(":");
            if (end>0){
                end = beginning+end;
                try {
                    length = Integer.parseInt(pList.substring(beginning,end));
                } catch (NumberFormatException e) {
                    System.out.println(e.getMessage());
                }
                marker = end+1;
                pName  = (pList.substring(marker,marker+length));
                beginning = marker+length;
            } else {
                return;
            }

            end = pList.substring(beginning).indexOf(":");
            if (end>0){
                end = beginning+end;
                try {
                    length = Integer.parseInt(pList.substring(beginning,end));
                } catch (NumberFormatException e) {
                    System.out.println(e.getMessage());
                }
                marker = end+1;
                pValue = (pList.substring(marker,marker+length));
                beginning = marker+length;
            } else {
                System.out.println("Error: inComplete property construct.");
            }

            if(!pName.equals(MimeType.UNDEFINED.type()) &&
                    !pName.equals(MimeType.UNDEFINED.type())){
                pContainer.add(new JProperty(pName,pValue));
            } else {
                System.out.println("Error: inComplete property construct.");
            }

        } while (end>0);
    }


    private String partialPropertyList(String pName, boolean isChildRequest){
        int ind = getIndexOfProperty(pName);
        if(ind>=0){
            List<JProperty> tmp = new ArrayList<JProperty>();
            if(isChildRequest) {
                for(int i=ind+1;i<pContainer.size();++i)
                    tmp.add(pContainer.get(i));
            } else {
                for(int i=0;i<ind;i++)
                    tmp.add(pContainer.get(i));
            }
            if(!tmp.isEmpty()){
                return packProperties(tmp);
            }
        }
        return MimeType.UNDEFINED.type();
    }

    private String packProperties(List<JProperty> pl){
        StringBuilder sb = new StringBuilder();
        for(JProperty p:pl){
            sb.append(p.getName().length()).append(":").append(p.getName()).
                    append(p.getValue().length()).append(":").append(p.getValue());
        }
        return sb.toString();
    }
    
    public void addHeadProperty(JProperty p){
        if(!pContainer.contains(p)){
            pContainer.add(0, p);
        }
    }

    public void addTailProperty(JProperty p){
        if(!pContainer.contains(p))pContainer.add(p);
    }

    public void addHeadProperty(String name, String value){
        JProperty p= new JProperty(name,value);
        if(!pContainer.contains(p)){
            pContainer.add(0, p);
        }
    }

    public void addTailProperty(String name, String value){
        JProperty p= new JProperty(name,value);
        if(!pContainer.contains(p))pContainer.add(p);
    }

    public void insertPropertyBefore(String target, String name, String value){
        int index = getIndexOfProperty(target);
        if(index>=0){
            pContainer.add(index,new JProperty(name,value));
        }
    }

    public void insertPropertyAfter(String target, String name, String value){
        int index = getIndexOfProperty(target);
        if(index>=0){
            pContainer.add(index+1,new JProperty(name,value));
        }
    }

    public JProperty getProperty(String pName){
        int i = getIndexOfProperty(pName);
        if(i>=0){
            return pContainer.get(i);
        } else {
            return null;
        }
    }

    public String getPropertyValue(String name){
        int i = getIndexOfProperty(name);
        if(i>=0){
            return pContainer.get(i).getValue();
        } else {
            return MimeType.UNDEFINED.type();
        }
    }

    public void removeProperty(String name){
        int i = getIndexOfProperty(name);
        if(i>=0){
            pContainer.remove(i);
        }
    }

    public boolean containsProperty(String name){
        int i = getIndexOfProperty(name);
        return i >= 0;
    }

    public String getStringRepresentation(boolean refresh){
        if(refresh){
            pListString = packProperties(pContainer);
        }
        return pListString;
    }

    public String getPropertyList(boolean refresh){
        if(refresh){
            pListString = packProperties(pContainer);
        }
        return pListString;
    }

    public String getStringRepresentation(){
        return getStringRepresentation(false);
    }

    public void createPropertyList(){
        pListString = packProperties(pContainer);
    }

    public void clearPropertyList(){
        pContainer.clear();
    }

    public JProperty getNextProperty(String pName){
        ListIterator<JProperty> iter = pContainer.listIterator();
        while(iter.hasNext()){
            JProperty p = iter.next();
            if(p.getName().equals(pName) && iter.hasNext()){
                return iter.next();
            }
        }
        return null;
    }

    public JProperty getPreviousProperty(String pName){
        ListIterator<JProperty> iter = pContainer.listIterator(pContainer.size());
        while(iter.hasPrevious()){
            JProperty p = iter.previous();
            if(p.getName().equals(pName) && iter.hasPrevious()){
                return iter.previous();
            }
        }
        return null;
    }

    public String getChildPropertyList(String pName){
        return partialPropertyList(pName,true);
    }

    public String getParentPropertyList(String pName){
        return partialPropertyList(pName,false);
    }

    public List<JProperty> getPContainer() {
        return pContainer;
    }

    @Override
    public String toString() {
        return pListString;
    }

    public static void main(String[] args){
        if (args.length > 0) {
            JPropertyList pl = new JPropertyList(args[0]);
            System.out.println(pl.getStringRepresentation(false));
            return;
        }

        JProperty[] pa = { new JProperty("time", "89"),
                           new JProperty("speed", "34"),
                           new JProperty("mass", "180"),
                           new JProperty("energy", "29.9") };

        JPropertyList pl = new JPropertyList(pa);

        System.out.println("\nTEST INSERT BEFORE: (time, mass, energy)");
        // Trying to insert after existing property
        pl.insertPropertyBefore("time", "before1", "dummy1");
        pl.insertPropertyBefore("mass", "before2", "dummy2");
        pl.insertPropertyBefore("energy", "before3", "dummy3");
        // Trying to insert after non existing property
        pl.insertPropertyBefore("aaaaaaa", "before_error", "error");
        // print
        for (JProperty p : pl.getPContainer())
            System.out.println(p);

        System.out.println("\nTEST INSERT HEAD/TAIL: (name, type)");
        // add to beginning
        pl.addHeadProperty("name", "particle");
        // add to end
        pl.addTailProperty("type", "11");
        // print
        for (JProperty p : pl.getPContainer())
            System.out.println(p);

        System.out.println("\nTEST INSERT AFTER: (name, speed, type)");
        // trying to insert after existing property
        pl.insertPropertyAfter("name", "after1", "AA");
        pl.insertPropertyAfter("speed", "after2", "BB");
        pl.insertPropertyAfter("type", "after3", "CC");
        // trying to insert after non existing property
        pl.insertPropertyAfter("aaaaaaa", "after_error", "error");
        // print
        for (JProperty p : pl.getPContainer())
            System.out.println(p);

        System.out.println("\nTEST CONTAINS:");
        System.out.println("before2 -> " + pl.containsProperty("before2"));
        System.out.println("aaaaaaa -> " + pl.containsProperty("aaaaaaa"));

        System.out.println("\nTEST REMOVING: (beforeN)");
        // remove "before" properties
        pl.removeProperty("before1");
        pl.removeProperty("before2");
        pl.removeProperty("before3");
        pl.removeProperty("aaaaaaa");
        // print
        for (JProperty p : pl.getPContainer())
            System.out.println(p);

        System.out.println("\nTEST GET PROPERTY:");
        System.out.println("name    -> " + pl.getProperty("name"));
        System.out.println("time    -> " + pl.getProperty("time"));
        System.out.println("after3  -> " + pl.getProperty("after3"));
        System.out.println("before2 -> " + pl.getProperty("before2"));

        System.out.println("\nTEST GET VALUE:");
        System.out.println("name    -> " + pl.getPropertyValue("name"));
        System.out.println("time    -> " + pl.getPropertyValue("time"));
        System.out.println("after3  -> " + pl.getPropertyValue("after3"));
        System.out.println("before2 -> " + pl.getPropertyValue("before2"));

        System.out.println("\nTEST GET NEXT:");
        System.out.println("name    -> " + pl.getNextProperty("name"));
        System.out.println("time    -> " + pl.getNextProperty("time"));
        System.out.println("type    -> " + pl.getNextProperty("type"));
        System.out.println("after3  -> " + pl.getNextProperty("after3"));
        System.out.println("before2 -> " + pl.getNextProperty("before2"));

        System.out.println("\nTEST GET PREVIOUS:");
        System.out.println("name    -> " + pl.getPreviousProperty("name"));
        System.out.println("after1  -> " + pl.getPreviousProperty("after1"));
        System.out.println("time    -> " + pl.getPreviousProperty("time"));
        System.out.println("after3  -> " + pl.getPreviousProperty("after3"));
        System.out.println("before2 -> " + pl.getPreviousProperty("before2"));

        System.out.println("\nTEST PACKING:");
        System.out.println(pl.getStringRepresentation(true));

        System.out.println("\nTEST UNPACKING:");
        JPropertyList pl2 = new JPropertyList(pl.getStringRepresentation());
        for (JProperty p : pl2.getPContainer())
            System.out.println(p);
    }
}
