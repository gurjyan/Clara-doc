## Platform subscriptions

### Registration messages

*callback:* `CPlatform.ServiceRegistrationCB`\
*server:* platform\
*subject:* platform name\
*type:* **platform/registration/request/\***

-   **sc/add:** add a container to the registration.

    Input (from a Java container):
    -   *byteArray*: Serialized `CSContainerRegistration`

    Input (from a C++ container):
    -   *payload:*
        -   **service\_container\_name** - `string`
        -   **service\_container\_host** - `string`
        -   **service\_container\_type** - `string`
        -   **service\_container\_startTime** - `string`
        -   **service\_container\_load** - `string`
        -   **service\_names** - `string[]`
        -   **service\_descriptions** - `string[]`
        -   **service\_authors** - `string[]`
        -   **service\_versions** - `string[]`
        -   **service\_languages** - `string[]`
        -   **service\_names** - `string[]`

-   **sc/updateLoad:** update load/status of a container register.

    Input:
    -   *text:* container canonical name
    -   *payload:*
        -   **service\_container\_load** - `double`
        -   **service\_container\_status** - `int`

-   **sc/remove:** remove a container from the registration.

    Input:
    -   *text:* container canonical name

-   **dpe/add:** add a DPE to the registration.

    Input:
    -   *payload:*
        -   **clara\_dpe\_name** - `string`
        -   **clara\_dpe\_expid** - `string`
        -   **clara\_dpe\_host** - `string`
        -   **clara\_dpe\_description** - `string`
        -   **clara\_dpe\_startTime** - `string`

-   **dpe/update:** update information of a DPE register.

    Input: same as **dpe/add**

-   **dpe/remove:** remove a DPE from the registration.

    Input:
    -   *text:* DPE name


### Platform information messages

*callback:* `CPlatform.PlatformInfoRequest`\
*server:* platform\
*subject:* platform name\
*type:* **platform/info/request/\***

-   **name**

    Broadcast:
    -   *server:* platform
    -   *subject*: *requester*
    -   *type*: **.../response/name**
    -   *text*: platform name

-   **host**

    Broadcast:
    -   *server:* platform
    -   *subject*: *requester*
    -   *type*: **.../response/host**
    -   *text*: platform host

-   **port**

    Broadcast:
    -   *server:* platform
    -   *subject*: *requester*
    -   *type*: **.../response/port**
    -   *text*: platform port

-   **myStartTime**

    Broadcast:
    -   *server:* platform
    -   *subject*: *requester*
    -   *type*: **.../response/port**
    -   *text*: platform startup time

-   **isRegistered**

    Input:
    -   *text*: DPE name

    Response:
    -   *server:* platform
    -   *subject*: **undefined**
    -   *type*: **undefined**
    -   *text*: **yes** or **no**

-   **registeredDPEs**

    Response:
    -   *server:* platform
    -   *subject*: **undefined**
    -   *type*: **undefined**
    -   *payload*:
        -   **dpes** - `string[]`

-   **registeredServices**

    Response:
    -   *server:* platform
    -   *subject*: **undefined**
    -   *type*: **undefined**
    -   *payload*:
        -   **services** - `string[]`

-   **serviceInfo**

    Input:
    -   *payload*:
        -   **containerName** - `string`
        -   **serviceName** - `string`\

    Response:
    -   *server:* platform
    -   *subject*: **undefined**
    -   *payload*:
        -   **description** - `string`
        -   **status** - `string`

### DPE information messages

*callback:* `CPlatform.DPEStateCB`\
*server:* platform\
*subject:* platform name\
*type:* **dpe/info/response/\***

-   **status**

    Input:
    -   *byteArray:* Serialized `CDPEnvironmentData`



## DPE subscriptions

### Control messages

*callback:* `CDPEnvironment.DPEControlRequestCB`\
*server:* local\
*subject:* DPE name\
*type:* **dpe/control/request/\***

-   **startClaraServiceContainer:** start a new service container.

    Input:
    -   *text:* container name
    -   *payload:*
        -   **service\_container\_type** - `string`
        -   **service\_container\_pool\_size** - `int`

    Response:
    -   *server:* platform
    -   *subject*: **undefined**
    -   *type*: **undefined**
    -   *text:* **rejected** or **done**

-   **stopClaraServiceContainer:** stop a service container.

    Input:
    -   *text:* container name

-   **exit:** stop the DPE.

-   **setUser:** set a unique user for the DPE.

    Input:
    -   *text:* user name

-   **removeUser:** clear the user of the DPE.


### Information messages

*callback:* `CDPEnvironment.DPEInfoRequestCB`\
*server:* local\
*subject:* DPE name\
*type:* **dpe/info/request/\***

-   **state**

    Response:
    -   *server:* local
    -   *subject*: **undefined**
    -   *type*: **undefined**
    -   *text:* **I am alive**

-   **serviceContainer**

    Response:
    -   *server:* local
    -   *subject*: **undefined**
    -   *type*: **undefined**
    -   *byteArray:* serialized map with all the containers of the DPE


### Registration messages

*callback:* `CDPEnvironment.ContainerInfoCB`\
*server:* platform\
*subject:* platform name\
*type:* **platform/info/request/serviceContainers**\
*byteArray:* Serialized registration



## Container subscriptions

### Control messages

*callback:* `CServiceContainer.ServiceControlCB`\
*server:* local\
*subject:* container name\
*type:* **service/control/request/\***

-   **startService**

    Input:
    -   *text:* local service name
    -   *payload:*
        -   **service\_name** - `string`
        -   **service\_request\_id** - `string`
    -   Data in payload

    Output:
    -   Service result

-   **startServiceFromSharedMemory**

    Input:
    -   *text:* local service name
    -   *payload:*
        -   **service\_name** - `string`
        -   **service\_request\_id** - `string`
    -   Data in shared memory

    Output:
    -   Service result

-   **addInput**

    Input:
    -   *payload:*
        -   **local\_service** - `string`
        -   **remote\_container** - `string`
        -   **remote\_service** - `string`

-   **removeInput**

    Input:
    -   *payload:*
        -   **local\_service** - `string`
        -   **remote\_container** - `string`
        -   **remote\_service** - `string`

-   **link**

    Input:
    -   *payload:*
        -   **local\_service** - `string`
        -   **remote\_container** - `string`
        -   **remote\_service** - `string`

-   **unlink**

    Input:
    -   *payload:*
        -   **local\_service** - `string`
        -   **remote\_container** - `string`
        -   **remote\_service** - `string`

-   **serviceLinks**

    Input:
    -   *text:* local service name

    Response:
    -   *server:* local
    -   *payload*:
        -   **service-links** - `string[]`

-   **addService**

    Input:
    -   *payload:*
        -   **service\_engine\_classpath** - `string`

    Response:
    -   *server:* local
    -   *subject*: **undefined**
    -   *type*: **undefined**
    -   *text*: service engine name

-   **configure**

    Input:
    -   *text:* local service name
    -   Data in payload

-   **subscribe**

    Input:
    -   *text:* local service name
    -   *payload:*
        -   **service\_requester\_name** - `string`
        -   **service\_requester\_subject** - `string`
        -   **service\_requester\_type** - `string`

-   **un\_subscribe**

    Input:
    -   *text:* local service name
    -   *payload:*
        -   **service\_requester\_name** - `string`
        -   **service\_requester\_subject** - `string`
        -   **service\_requester\_type** - `string`

-   **removeService**

    Input:
    -   *text:* local service name

-   **stop**

-   **version**

    Input:
    -   *text:* local service name

    Response:
    -   *server:* local
    -   *subject*: **undefined**
    -   *type*: **undefined**
    -   *text*: service version

-   **broadcast**

-   **setLoadStatInterval**

    Input:
    -   *text:* load reporting interval - `int`
