/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */


package org.jlab.clara.examples.service;

import org.jlab.clara.constants.CConstants;
import org.jlab.clara.data.JioSerial;
import org.jlab.clara.frontend.JService;
import org.jlab.clas12.tools.MimeType;
import org.jlab.clara.util.CUtil;

/**
 *
 * Hello world service
 *
 * @author gurjyan
 * @version 3.x
 */

public class HelloWorldService extends JService {

    // defines a language using which we say hello
    private int language = 0;

    protected HelloWorldService(String name) {
        super(name);
    }

    @Override
    public void configure(JioSerial data) {

        // check the input data mime-type
        if(data.getMimeType().type().equals(MimeType.STRING.type())){

            // get data object
            String cd = data.getStringObject();
            if(cd.equalsIgnoreCase("Armenian")){
                language = 1;
            } else if (cd.equalsIgnoreCase("Italian")){
                language = 2;
            } else if (cd.equalsIgnoreCase("Russian")){
                language = 3;
            } else if (cd.equalsIgnoreCase("French")){
                language = 4;
            } else if (cd.equalsIgnoreCase("German")){
                language = 5;
            } else if (cd.equalsIgnoreCase("Greek")){
                language = 6;
            } else if (cd.equalsIgnoreCase("Hebrew")){
                language = 7;
            } else if (cd.equalsIgnoreCase("Japanese")){
                language = 8;
            } else if (cd.equalsIgnoreCase("Thai")){
                language = 9;
            }
        }
    }

    @Override
    public JioSerial execute(JioSerial data) {


        // output transient data object
        JioSerial out = new JioSerial();
        out.setLanguage(CConstants.LANG_JAVA);


        // check the input data mime-type
        if(data.getMimeType() == MimeType.STRING){

            // get the data content
             String inputDataObject = data.getStringObject();

            // generate the output data
            switch(language){
                case 0:
                    enableVerbose();
                    System.out.println("HELLO.....");
                    System.out.println("SIMON.....");
                    out.setData(CUtil.getCurrentTime()+": Hello");
                    break;
                case 1:
                    out.setData(CUtil.getCurrentTime()+": Barev");
                    break;
                case 2:
                    out.setData(CUtil.getCurrentTime()+": Salve");
                    break;
                case 3:
                    out.setData(CUtil.getCurrentTime()+": Zdrastvui");
                    break;
                case 4:
                    out.setData(CUtil.getCurrentTime()+": Bonjour");
                    break;
                case 5:
                    out.setData(CUtil.getCurrentTime()+": Guten Tag");
                    break;
                case 6:
                    out.setData(CUtil.getCurrentTime()+": Gia'sou");
                    break;
                case 7:
                    out.setData(CUtil.getCurrentTime()+": Shalom");
                    break;
                case 8:
                    out.setData(CUtil.getCurrentTime()+":  Kon-nichiwa");
                    break;
                case 9:
                    out.setData(CUtil.getCurrentTime()+": Sa-wat-dee");
                    break;
            }
            out.setDataDescription("response to " + inputDataObject);
            out.setStatus(CConstants.warning);
        } else {

            // Reject with an execution status = error
            out.setData(CConstants.REJECT);
            out.setDataDescription("I can accept only strings");
            out.setStatus(CConstants.error);
        }
        return out;
    }

    @Override
    public String getName() {
        return "Hello";
    }

    @Override
    public String getAuthor() {
        return "Gyurjyan";
    }

    @Override
    public String getDescription() {
        return "Hello World service";
    }

    @Override
    public String getVersion() {
        return  "1.0";
    }

    @Override
    public String getLanguage() {
        return CConstants.LANG_JAVA;
    }

    @Override
    public JioSerial execute(JioSerial[] data) {
        return null;
    }

    @Override
    public void destruct() {
    }

}
