/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */


package org.jlab.clara.examples.orchestrator.check;


import org.jlab.clara.frontend.JOrchestrator;
import org.jlab.clara.system.CException;

import java.util.List;

/**
 *
 * Finds a list of service with a specific engine name.
 * Note: service engine name is a user specified name, given at the
 * interface <code>ICService</coda> implementation.
 *
 * @author gurjyan
 * @version 3.x
 */

public class ServicesByEngineName extends JOrchestrator {

    /**
     * Constructor
     * Connects to the Clara platform
     *
     */
    public ServicesByEngineName() throws CException {
        super();
    }

    public static void main(String[] args) {
        String engineName  = args[0];

        // an instance of this class
        ServicesByEngineName rso;
        try {
            rso = new ServicesByEngineName();

            // get registration information form the platform normative services
            rso.requestRegistrationData(1000);

            // get all registered service canonical names that has a required engine name.
            List<String> serviceNames = rso.getServiceNamesByEngineName(engineName);
            if(serviceNames!=null && !serviceNames.isEmpty()){

                for(String sn:serviceNames){
                    // list service information
                    System.out.println(rso.getServiceInformation(sn));
                }
            } else {
                System.out.println("No service with the specified " +
                        "engine name = "+engineName+" was found.");
            }
            rso.exit();
        } catch (CException e) {
            System.out.println(e.getMessage());
        }
    }
}
