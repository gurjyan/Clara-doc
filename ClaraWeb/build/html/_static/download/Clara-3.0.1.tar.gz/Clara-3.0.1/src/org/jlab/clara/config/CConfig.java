package org.jlab.clara.config;

import org.jlab.coda.cMsg.cMsgNetworkConstants;
import org.jlab.clara.constants.CConstants;
import org.jlab.clara.constants.CSISConstants;
import org.jlab.clara.util.CLogger;
import org.jlab.clara.util.CUtil;

import java.io.File;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Enumeration;
import java.util.HashSet;

/**
 * Platform as well as local DPE pub-sub server settings.
 * This reads configuration file for platform server settings.
 *
 * @author gurjyan
 * @version 3.x
 */
public class CConfig {
    //singleton object
    private static CConfig ourInstance = new CConfig();

    // $CLARA_SERVICES directory
    private String claraServices             = CConstants.udf;

    private String platformName              = CConstants.udf;
    private String platformHost              = CConstants.udf;
    private String platformHostCanonicalName = CConstants.udf;
    private String platformDescription       = CConstants.udf;
    private int    platformTcpPort;
    private int    platformTcpDomainPort;
    private int    platformUdpPort;
    private String platformUdl               = CConstants.udf;
    private String platformMCastUdl          = CConstants.udf;

    // in case non-distributed system with a single platform
    // localDpeUdl = platformUdl, localDpeHost = platformHost
    private String localDpeUdl               = CConstants.udf;
    private String localDpeName              = CConstants.udf;
    private String localDpeHost              = CConstants.udf;

    // set of addresses in case of multiple network cards
    private HashSet<String> addrSet = new HashSet<String>();

    // local instance of the logger object
    private CLogger lg = CLogger.getInstance();

    /**
     * This method returns a reference to the single
     * instance of this singleton class
     *
     * @return instance of this class
     */
    public static CConfig getInstance() {
        return ourInstance;
    }

    /**
     * Private constructor.
     */
    private CConfig() {

        // get $CLARA_SERVICES env variable
        claraServices = System.getenv("CLARA_SERVICES");
        if (claraServices == null) {
            System.err.println("$CLARA_SERVICES is not defined. exiting...");
            System.exit(1);
        }

        String localHost = CConstants.udf;
        try {
            // Keep a set with all the IPs of all network cards of  this node
            Enumeration<NetworkInterface> all = java.net.NetworkInterface.getNetworkInterfaces();
            while (all.hasMoreElements()) {
                NetworkInterface ifc = all.nextElement();
                if (ifc.isUp()) {
                    Enumeration<InetAddress> addrs = ifc.getInetAddresses();
                    while (addrs.hasMoreElements()) {
                        InetAddress addr = addrs.nextElement();
                        addrSet.add(addr.getHostAddress());
                    }
                }
            }

            // get the IP of the local host. Host will always be in the form of IP address
            localHost = InetAddress.getLocalHost().getHostAddress();
        } catch (SocketException e) {
            lg.logger.severe(CUtil.stack2str(e));
        } catch (UnknownHostException e) {
            lg.logger.severe(CUtil.stack2str(e));
        }

        // default values, considering standalone platform
        platformHost = localHost;
        localDpeHost = localHost;

        // default ports
        platformTcpPort       = cMsgNetworkConstants.nameServerTcpPort;
        platformTcpDomainPort = cMsgNetworkConstants.domainServerPort;
        platformUdpPort       = cMsgNetworkConstants.nameServerUdpPort;

        // parse setup.xml to get user defined platform settings (host, ports...)
        parsePlatformConfig();

        // now based on parsing results and defaults define platform
        // and local DPE parameters (udl, name, etc.)
        setPlatformInfo();
        setDpeInfo();
    }

    /**
     * defines platform name, udls and description
     */
    private void setPlatformInfo() {
        platformName = platformHost + CSISConstants.PLATFORM_NAME_SUFFIX;
        platformDescription = "Physics data production Clara-3 platform " + platformName;

        platformUdl = "cMsg://" + platformHost + ":" + platformTcpPort + "/cMsg/";
        platformMCastUdl = "cMsg://multicast:" + platformUdpPort + "/cMsg/";
    }

    /**
     * defines local DPE name and udl
     */
    private void setDpeInfo()
    {
        localDpeName = localDpeHost + CSISConstants.DPE_NAME_SUFFIX_JAVA;
        localDpeUdl = "cMsg://" + localDpeHost + ":" + platformTcpPort + "/cMsg/";
    }

    /**
     * Clara config file, i.e. setup.xml parser.
     * Note. Clara config file is optional.
     */
    private void parsePlatformConfig() {

        if (new File(claraServices+File.separator+"setup.xml").exists()) {

            CConfigParser myConfigParser = new CConfigParser(claraServices+File.separator+"setup.xml");

            // get platform description
            if (!myConfigParser.getPlatformDescription().equals(CConstants.udf)) {
                platformDescription = myConfigParser.getPlatformDescription();
            }

            // get platform host if platform host is set other than localhost
            if (!myConfigParser.getPlatformHost().equals(CConstants.udf) &&
                    !myConfigParser.getPlatformHost().equalsIgnoreCase("localhost")) {

                try {
                    String configPlatformHost = myConfigParser.getPlatformHost();
                    InetAddress address = InetAddress.getByName(configPlatformHost);

                    String tmpPlatformHost = address.getHostAddress();
                    String tmpPlatformHostCanonicalName = address.getCanonicalHostName();
                    String tmpDpeHost = localDpeHost;

                    // If the platformHost address is part of the local set of IPs,
                    // make sure that the localDpeHost uses the same address
                    // to avoid problem with multiple cards resolution.
                    if (addrSet.contains(tmpPlatformHost)) {
                        tmpDpeHost = tmpPlatformHost;
                    }

                    // if platform host is on the infini-band network
                    // DPE must also run on the infini-band.
                    // Attention: JLAB specific naming convention
                    if (tmpPlatformHostCanonicalName.contains("-ib")) {

                        // define the local DPE host name (without ib) and add -ib to it.
                        InetAddress ad = InetAddress.getByName(tmpDpeHost);
                        String d = ad.getHostName();
                        String dpeIbHostName = d.substring(0, d.indexOf(".")) + "-ib";

                        // get DPE's new (with -ib) IP address
                        InetAddress fad = InetAddress.getByName(dpeIbHostName);
                        tmpDpeHost = fad.getHostAddress();
                    }

                    platformHost = tmpPlatformHost;
                    platformHostCanonicalName = tmpPlatformHostCanonicalName;
                    localDpeHost = tmpDpeHost;
                } catch (UnknownHostException e) {
                    lg.logger.severe(CUtil.stack2str(e));
                }
            }

            // get platform tcp port
            if (myConfigParser.getPlatformTcpPort() > 0) {
                platformTcpPort = myConfigParser.getPlatformTcpPort();
                platformTcpDomainPort = platformTcpPort + 1;
            }

            // get platform udp port
            if (myConfigParser.getPlatformUdpPort() > 0) {
                platformUdpPort = myConfigParser.getPlatformUdpPort();
            }
        }
    }

    /**
     * define platform host, udl, name, etc. based on users request
     * @param pHost user specified host name
     */
    public void configPlatformConnection(String pHost) {
        try {
            InetAddress address = InetAddress.getByName(pHost);
            platformHost = address.getHostAddress();
            setPlatformInfo();
        } catch (UnknownHostException e) {
            lg.logger.severe(CUtil.stack2str(e));
        }
    }

    /**
     * @return  resolved $CLARA_SERVICES env
     */
    public String getClaraServices() {
        return claraServices;
    }

    /**
     * @return platform name
     */
    public String getPlatformName() {
        return platformName;
    }

    /**
     * @return platform host
     */
    public String getPlatformHost() {
        return platformHost;
    }

    /**
     * @return platform description
     */
    public String getPlatformDescription() {
        return platformDescription;
    }

    /**
     * @return platform TCP port
     */
    public int getPlatformTcpPort() {
        return platformTcpPort;
    }

    /**
     * @return  platform TCP domain port
     */
    public int getPlatformTcpDomainPort() {
        return platformTcpDomainPort;
    }

    /**
     * @return platform UDP port
     */
    public int getPlatformUdpPort() {
        return platformUdpPort;
    }

    /**
     * @return platform UDL
     */
    public String getPlatformUdl() {
        return platformUdl;
    }

    /**
     * @return local DPE UDL
     */
    public String getLocalDpeUdl() {
        return localDpeUdl;
    }

    /**
     * @return platform multicast UDP
     */
    public String getPlatformMCastUdl() {
        return platformMCastUdl;
    }

    /**
     * @return local DPE name
     */
    public String getLocalDpeName() {
        return localDpeName;
    }

    /**
     * @return local DPE host name
     */
    public String getLocalDpeHost() {
        return localDpeHost;
    }

    /**
     * @return platform host canonical name
     */
    public String getPlatformHostCanonicalName() {
        return platformHostCanonicalName;
    }

}