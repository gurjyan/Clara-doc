/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */


package org.jlab.clara.util;

/**
 * date  7/13/12
 *
 * Periodically reads cpu specific information from /proc/loadavg and /proc/meminfo files
 * and sets the volatile variables. UNIX only.
 *
 * @author gurjyan
 * @version 1.0
 */

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;


public class CpuMonitoringThread extends Thread {


    // system-environment specific variables
    public static AtomicLong    cpuLoad            = new AtomicLong(0);
    public static AtomicInteger cpuTotalMemory     = new AtomicInteger(0);
    public static AtomicInteger cpuFreeMemory      = new AtomicInteger(0);
    public static AtomicInteger cpuBuffers         = new AtomicInteger(0);
    public static AtomicInteger cpuActiveProcesses = new AtomicInteger(0);
    public static AtomicInteger cpuTotalProcesses  = new AtomicInteger(0);

        private boolean isRunning = true;
        private BufferedReader br;

    // local instance of the logger object
    private static CLogger lg = CLogger.getInstance();


    public void run() {
            String line,s;
            Scanner sc;
            super.run();
            while(isRunning){
                try {
                    br = new BufferedReader(new FileReader("/proc/loadavg"));
                    line = br.readLine();
                    sc = new Scanner(line);
                    cpuLoad.set(Double.doubleToLongBits(sc.nextDouble()));
                    sc.next();
                    sc.next();
                    s = sc.next();
                    cpuActiveProcesses.set(Integer.parseInt(s.substring(0,s.indexOf("/"))));
                    cpuTotalProcesses.set(Integer.parseInt(s.substring(s.indexOf("/")+1)));
                    br.close();
                    br = new BufferedReader(new FileReader("/proc/meminfo"));
                    line = br.readLine();
                    sc = new Scanner(line);
                    if(sc.next().equals("MemTotal:")){
                        cpuTotalMemory.set(sc.nextInt());
                    }
                    line = br.readLine();
                    sc = new Scanner(line);
                    if(sc.next().equals("MemFree:")){
                        cpuFreeMemory.set(sc.nextInt());
                    }
                    line = br.readLine();
                    sc = new Scanner(line);
                    if(sc.next().equals("Buffers:")){
                        cpuBuffers.set(sc.nextInt());
                    }
                    br.close();
                } catch (FileNotFoundException e) {
                    lg.logger.severe(CUtil.stack2str(e));
                } catch (IOException e) {
                    lg.logger.severe(CUtil.stack2str(e));
                } catch (NumberFormatException e) {
                    lg.logger.severe(CUtil.stack2str(e));
                }
                try {
                    Thread.sleep(10000);
                } catch (InterruptedException e) {
                    lg.logger.severe(CUtil.stack2str(e));
                }
            }
        }

    public BufferedReader getBr() {
        return br;
    }

    public static AtomicInteger getCpuActiveProcesses() {
        return cpuActiveProcesses;
    }

    public static AtomicInteger getCpuBuffers() {
        return cpuBuffers;
    }

    public static AtomicInteger getCpuFreeMemory() {
        return cpuFreeMemory;
    }

    public static AtomicLong getCpuLoad() {
        return cpuLoad;
    }

    public static AtomicInteger getCpuTotalMemory() {
        return cpuTotalMemory;
    }

    public static AtomicInteger getCpuTotalProcesses() {
        return cpuTotalProcesses;
    }

    public boolean isRunning() {
        return isRunning;
    }
}
