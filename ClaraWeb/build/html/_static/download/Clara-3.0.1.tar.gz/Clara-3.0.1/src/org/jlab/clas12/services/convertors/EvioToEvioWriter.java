/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */
package org.jlab.clas12.services.convertors;

import org.jlab.clara.constants.CConstants;
import org.jlab.clara.data.JioSerial;
import org.jlab.clas12.tools.MimeType;
import org.jlab.clas12.tools.property.JPropertyList;
import org.jlab.coda.jevio.EvioCompactEventWriter;
import org.jlab.coda.jevio.EvioException;
import org.jlab.clara.system.ICService;
import org.jlab.clara.util.CUtil;

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * Converter service that converts EvIO transient data to EvIO persistent data
 * (i.e. writes EvIO events to an output file).
 * Supports evio-4.1 version.
 */
public class EvioToEvioWriter implements ICService
{
    private final String NAME = "EvioToEvioWriter";

    private static final String CONF_ACTION = "action";
    private static final String CONF_FILENAME = "file";
    private static final String CONF_ORDER = "order";
    private static final String CONF_OVERWRITE = "overwrite";

    private static final String CONF_ACTION_OPEN = "open";
    private static final String CONF_ACTION_CLOSE = "close";
    private static final String CONF_ACTION_SKIP = "skip";

    private static final String OUTPUT_NEXT = "next-rec";
    private static final String EVENT_SKIP = "skip";

    private static final String NO_FILE = "No open file";

    private String fileName = CConstants.udf;
    private ByteOrder fileByteOrder = ByteOrder.nativeOrder();

    private boolean skipEvents = false;

    private String openError = NO_FILE;
    private int eventCounter;

    private EvioCompactEventWriter writer;
    private final Object writerLock = new Object();


    @Override
    public void configure(JioSerial data)
    {
        if (data.getMimeType() == MimeType.PROPERTY_LIST) {
            JPropertyList pl = data.getPropertyList();
            if (pl.containsProperty(CONF_ACTION)) {
                String action = pl.getPropertyValue(CONF_ACTION);
                if (action.equals(CONF_ACTION_OPEN)) {
                    if (pl.containsProperty(CONF_FILENAME)) {
                        openFile(pl);
                    } else {
                        String errMsg = "%s config: Missing '%s' property. PL: %s%n";
                        System.err.printf(errMsg, NAME, CONF_FILENAME, pl);
                    }
                } else if (action.equals(CONF_ACTION_CLOSE)) {
                    if (pl.containsProperty(CONF_FILENAME)) {
                        closeFile(pl);
                    } else {
                        String errMsg = "%s config: Missing '%s' property. PL: %s%n";
                        System.err.printf(errMsg, NAME, CONF_FILENAME, pl);
                    }
                } else if (action.equals(CONF_ACTION_SKIP)) {
                    skipAll();
                } else {
                    String errMsg = "%s config: Wrong value of '%s' property = '%s'%n";
                    System.err.printf(errMsg, NAME, CONF_ACTION, action);
                }
            } else {
                String errMsg = "%s config: Missing '%s' property. PL: %s%n";
                System.err.printf(errMsg, NAME, CONF_ACTION, pl);
            }
        } else {
            String errMsg = "%s config: Wrong mimetype '%s'%n";
            System.err.printf(errMsg, NAME, data.getMimeType().type());
        }
    }


    private void openFile(JPropertyList pl)
    {
        synchronized (writerLock) {
            if (writer != null) {
                writeAndClose();
            }

            fileName = CUtil.getFileName(pl.getPropertyValue(CONF_FILENAME));
            if (pl.containsProperty(CONF_ORDER)) {
                String byteOrder = pl.getPropertyValue(CONF_ORDER);
                if (byteOrder.equals(ByteOrder.BIG_ENDIAN.toString())) {
                    fileByteOrder = ByteOrder.BIG_ENDIAN;
                } else {
                    fileByteOrder = ByteOrder.LITTLE_ENDIAN;
                }
            }

            boolean overWriteOK = false;
            if (pl.containsProperty(CONF_OVERWRITE) &&
                pl.getPropertyValue(CONF_OVERWRITE).equals("true")) overWriteOK = true;

            System.out.printf("%s service: Request to open file %s%n", NAME, fileName);
            try {
                File file = new File(fileName);
                if (!overWriteOK) {
                    writer = new EvioCompactEventWriter(file.getName(),
                                                        file.getParent(),
                                                        0,
                                                        0,
                                                        20000000,
                                                        fileByteOrder,
                                                        null);
                } else {
                    writer = new EvioCompactEventWriter(file.getName(),
                                                        file.getParent(),
                                                        0,
                                                        0,
                                                        1000000,
                                                        10000,
                                                        20000000,
                                                        fileByteOrder,
                                                        null,
                                                        true);
                }
                eventCounter = 0;
                System.out.printf("%s service: Opened file %s%n", NAME, fileName);
            } catch (EvioException e) {
                openError = String.format("Error opening the file %s%n%s",
                                          fileName, CUtil.reportException(e));
                System.err.printf("%s service: %s%n", NAME, openError);
                fileName = CConstants.udf;
                eventCounter = 0;
            }

            skipEvents = false;
        }

    }


    private void closeFile(JPropertyList pl)
    {
        synchronized (writerLock) {
            fileName = CUtil.getFileName(pl.getPropertyValue(CONF_FILENAME));
            System.out.printf("%s service: Request to close file %s%n", NAME, fileName);
            if (writer != null) {
                writeAndClose();
            } else {
                System.err.printf("%s service: File %s not open%n", NAME, fileName);
            }
            openError = NO_FILE;
            fileName = CConstants.udf;
            eventCounter = 0;
        }
    }


    private void writeAndClose()
    {
        if (eventCounter > 0) {
            writer.close();
        }
        System.out.printf("%s service: Closed file %s%n", NAME, fileName);
        writer = null;
    }


    private void skipAll()
    {
        System.out.printf("%s service: Request to skip events%n", NAME);
        synchronized (writerLock) {
            if (writer == null) {
                skipEvents = true;
                System.out.printf("%s service: Skipping all events%n", NAME);
            } else {
                System.err.printf("%s service: A file %s is already open%n", NAME, fileName);
            }
        }
    }


    @Override
    public JioSerial execute(JioSerial data)
    {
        JioSerial out = new JioSerial();

        String dataSource = data.getDataSource();
        if (!dataSource.equalsIgnoreCase(CConstants.udf)) {
            out.setDataDestination(CUtil.parse4DpeHostName(data.getDataSource())+"/*/*");
        }

        MimeType mt = data.getMimeType();
        if (mt != MimeType.EVIO) {
            setError(String.format("Wrong input type '%s'", mt), out);
            return out;
        }

        if (skipEvents || data.getStatus().equals(EVENT_SKIP)) {
            out.setData(OUTPUT_NEXT);
            out.setStatus(CConstants.info);
            out.setDataDescription("event skipped");
            return out;
        }

        synchronized (writerLock) {
            if (writer == null) {
                setError(openError, out);
            } else {
                try {
                    ByteBuffer event = data.getDataAsByteBuffer();
                    writer.writeEvent(event);
                    eventCounter++;
                    out.setData(OUTPUT_NEXT);
                    out.setStatus(CConstants.info);
                    out.setDataDescription("event saved");

                } catch (EvioException e) {
                    String msg = String.format("Error saving event to file %s%n%n%s",
                            fileName, CUtil.reportException(e));
                    setError(msg, out);
                } catch (IOException e) {
                    String msg = String.format("Error saving event to file %s%n%n%s",
                            fileName, CUtil.reportException(e));
                    setError(msg, out);
                }
            }
        }

        return out;
    }


    private void setError(String msg, JioSerial out)
    {
        out.setDataDescription(msg);
        out.setStatus(CConstants.error);
    }


    @Override
    public JioSerial execute(JioSerial[] data)
    {
        return null;
    }


    @Override
    public void destruct()
    {
        if (writer != null) {
            writeAndClose();
        }
    }


    @Override
    public String getName()
    {
        return NAME;
    }


    @Override
    public String getAuthor()
    {
        return "Sebastian Mancilla <code>&lt;smancill@jlab.org&gt;</code>";
    }


    @Override
    public String getDescription()
    {
        return
           "Writes EVIO events to a file. " +
           "Saves the received event to disk or report an error if there was some problem.<br><br>" +
           "<strong>Configuration:</strong>" +
           "<ul>" +
           "  <li><font \"color=navy\">type:</font> <code>text/property-list</code>" +
           "  <li><font \"color=navy\">value:</font> the following properties are accepted:" +
           "    <ul>" +
           "        <li><code>\"" + CONF_ACTION + "\"</code>:" +
           "        <code>\""+ CONF_ACTION_OPEN  + "\"</code> to open the output file, or"  +
           "        <code>\""+ CONF_ACTION_CLOSE + "\"</code> to close it."  +
           "      <li><code>\"" + CONF_FILENAME + "\"</code>:" +
           "        <code>\"&lt;filepath&gt;\"</code>, the output file."  +
           "      <li><code>\"" + CONF_ORDER + "\"</code>: <code>\"&lt;byte_order&gt;\"</code>,"+
           "        (optional) when opening the output file, set its byte order."  +
           "    </ul>" +
           "</ul>" +
           "<strong>Requests:</strong>" +
           "<ul>" +
           "  <li><font \"color=navy\">input type:</font> <code>binary/data-evio</code>" +
           "  <li><font \"color=navy\">input value:</font> " +
           "     the EVIO 4.1 event that should be saved in the output file." +
           "  <li><font \"color=navy\">request action:</font> " +
           "    write the received event to the output file." +
           "    If the status of the data is <code>\"" + EVENT_SKIP + "\"</code>" +
           "    then the received event will not be written to the file." +
           "  <li><font \"color=navy\">output type:</font> <code>text/string</code>" +
           "  <li><font \"color=navy\">output value:</font> <code>\"" + OUTPUT_NEXT + "\"</code>, " +
           "    indicating that the event was successfully written or skipped." +
           "    It can be used as the input of the reader service to request a new event." +
           "</ul>" +
           "<strong>Errors:</strong>" +
           "<ul>" +
           "  <li>If the service has not been configured to open an output file."  +
           "  <li>If the service could not open the output file."  +
           "  <li>If the mime-type of the input data was wrong."  +
           "  <li>If the service could not write the event to the output file."  +
           "</ul>" +
           "";
    }


    @Override
    public String getVersion()
    {
        return "1.4";
    }


    @Override
    public String getLanguage()
    {
        return CConstants.LANG_JAVA;
    }
}
