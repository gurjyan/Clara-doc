/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */
package org.jlab.clas12.orchestrators;

/**
 * Stores properties of a DPE.
 * <p>
 * Currently, these properties are:
 * <ul>
 * <li>name (IP address)
 * <li>number of cores
 * <li>value of {@code $CLARA_SERVICES}
 * </ul>
 */
class DpeInfo {

    final String name;
    final int cores;
    final String servicesDir;

    final static String defaultClaraServices = System.getenv("CLARA_SERVICES");


    public DpeInfo(String name, int cores, String servicesDir) {
        this.name = name;
        this.cores = cores;
        this.servicesDir = servicesDir;
    }


    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + cores;
        result = prime * result + ((name == null) ? 0 : name.hashCode());
        result = prime * result + ((servicesDir == null) ? 0 : servicesDir.hashCode());
        return result;
    }


    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof DpeInfo)) {
            return false;
        }
        DpeInfo other = (DpeInfo) obj;
        if (cores != other.cores) {
            return false;
        }
        if (name == null) {
            if (other.name != null) {
                return false;
            }
        } else if (!name.equals(other.name)) {
            return false;
        }
        if (servicesDir == null) {
            if (other.servicesDir != null) {
                return false;
            }
        } else if (!servicesDir.equals(other.servicesDir)) {
            return false;
        }
        return true;
    }
}
