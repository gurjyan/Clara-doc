/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */


package org.jlab.clara.examples.orchestrator;

import org.jlab.clara.constants.CConstants;
import org.jlab.clara.frontend.JOrchestrator;
import org.jlab.clara.system.CException;
import org.jlab.clara.util.CUtil;

/**
 *
 * This class is an example that describes how
 * to deploy a service on the Clara platform
 *
 * @author gurjyan
 * @version 3.x
 */

public class DeployService extends JOrchestrator {
    /**
     * Constructor
     * Connects to the Clara platform
     *
     */
    public DeployService() throws CException {
        super();
    }

    public static void main(String[] args){

        String host        = args[0];
        String container   = args[1];
        String engineClass = args[2];

        String type = CConstants.LANG_JAVA;
        if (args.length == 4)
            type = args[3];

        try {
        // an instance of this class
        DeployService dso = new DeployService();

        // print orchestrator info
        System.out.println(dso);

            dso.deploy(host,container,engineClass,type,false);
            String containerCanonicalName = CUtil.getConCanName(host, container);

        for(String s:dso.getServiceNames(containerCanonicalName)) {
        System.out.println(s);
        }
            dso.exit();
        } catch (CException e) {
            System.out.println(e.getMessage());
        }
    }
}
