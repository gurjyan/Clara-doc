/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */

package org.jlab.clara.examples.orchestrator;

import org.jlab.clara.constants.CConstants;
import org.jlab.clara.frontend.JOrchestrator;
import org.jlab.clara.system.CException;

/**
 *
 * @author gurjyan
 * @version 3.x
 */
public class CreateContainerGW extends JOrchestrator {

    public CreateContainerGW() throws CException {
        super();
    }

    public static void main(String[] args) {
        String dpeHost = args[0];
        String contName = args[1];

        CreateContainerGW orc;
        try {
            orc = new CreateContainerGW();
            orc.createContainerGW(dpeHost,contName, CConstants.LANG_JAVA);
        } catch (CException e) {
            System.out.println(e.getMessage());
        }
    }

}
