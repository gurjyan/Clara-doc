/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */


package org.jlab.clara.examples.orchestrator.request;

import org.jlab.clara.data.JioSerial;
import org.jlab.clara.frontend.JOrchestrator;
import org.jlab.clas12.tools.MimeType;
import org.jlab.clara.pubsub.CCallBack;
import org.jlab.clara.system.CException;
import org.jlab.clara.util.CUtil;

/**
 *
 * This is an example on an orchestrator that
 * requests a service asynchronously.
 *
 * @author gurjyan
 * @version 3.x
 *
 */

public class ServiceAsync extends JOrchestrator {

    private String oName;
    private JioSerial dataRequest;
    private String serviceName;
    private long startTime;
    private int loop = 0;
    private int totalLoops = 1;
    private CCallBack cb;

    /**
     * Constructor
     * Connects to the Clara platform
     *
     * @param name of this orchestrator
     */
    public ServiceAsync(String name) throws CException {
        super(name);

        cb = new CCallBack(serviceName, oName, oName) {
            @Override
            public void monitorCallBack(JioSerial data) {
                loop++;
                try {
                    if (loop < totalLoops) {
                        runService(serviceName, dataRequest, 1);

                    } else {
                        long t = CUtil.getCurrentTimeInNs() - startTime;
                        System.out.println("Service response time = " + t / 1000000 + " micro sec.  => " + loop);

                        // remove the monitor
                        serviceMonitorOff(serviceName, oName, oName);
                        warningAllMonitorOff();
                        exit();
                    }
                } catch (CException e) {
                    System.out.println(e.getMessage());
                }

            }
        };
    }

    public static void main(String[] args) {


        String name = CUtil.generateName();
        // instance of this class
        ServiceAsync rs;
        try {
            rs = new ServiceAsync(name);
            rs.oName = name;
            rs.serviceName = args[0];

            String data;
            if (args.length >= 2)
                data = args[1];
            else
                data = "none";

            if (args.length == 3) {
                int tloops = CUtil.isNumber(args[2]);
                if (tloops > 0) rs.totalLoops = tloops;
            }

            // get registration information form the platform registration and discovery service
            rs.requestRegistrationData(1000);

            // check the platform registration if the service in question is registered
            if (rs.isServiceDeployed(rs.serviceName)) {
                // monitor this service
                rs.serviceMonitorOn(rs.serviceName, name, name, rs.cb);

                // Now that we have callback in a place, request the service
                // create a request transient data
                rs.dataRequest = new JioSerial();
                rs.dataRequest.setData(data, MimeType.STRING);

                rs.startTime = CUtil.getCurrentTimeInNs();
                // async send the request
                rs.runService(rs.serviceName, rs.dataRequest, 1);
            } else {
                System.out.println("Service was not found");
            }

        } catch (CException e) {
            System.out.println(e.getMessage());
        }
    }

}

