/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */


package org.jlab.clara.service;

import org.jlab.clara.system.ICService;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 *
 * @author smancill
 * @version 3.x
 */
public class CServiceInfo
{
    private final ICService engine;

    // Services daisy chain using links.
    // This set shows where (i.e. to what service) the results of the
    // particular local service execution will be sent.
    private final Set<CServiceOutputLink> outputs = new HashSet<CServiceOutputLink>();

    // The list of input service that must all send their execution
    // results ( i.e. to be present) to the local service to be executed.
    private final Set<CServiceInputLink> inputs = new LinkedHashSet<CServiceInputLink>();

    // The set holds information for listeners that are registered to this service
    private final Set<CServiceListener> listeners = new HashSet<CServiceListener>();


    public CServiceInfo(ICService serviceEngine)
    {
        engine = serviceEngine;
    }


    public ICService getEngine()
    {
        return engine;
    }


    public synchronized boolean addInput(CServiceInputLink newInput)
    {
        return inputs.add(newInput);
    }


    public synchronized boolean removeInput(CServiceInputLink target)
    {
        return inputs.remove(target);
    }


    public synchronized Set<CServiceInputLink> getInputs()
    {
        return inputs;
    }


    public synchronized boolean addOutput(CServiceOutputLink newOutput)
    {
        return outputs.add(newOutput);
    }


    public synchronized boolean removeOutput(CServiceOutputLink target)
    {
        return outputs.remove(target);
    }


    public synchronized Set<CServiceOutputLink> getOutputs()
    {
        return outputs;
    }


    public synchronized boolean addListener(CServiceListener newListener)
    {
        return listeners.add(newListener);
    }


    public synchronized boolean removeListener(CServiceListener target)
    {
        return listeners.remove(target);
    }


    public synchronized Set<CServiceListener> getListeners()
    {
        return listeners;
    }
}
