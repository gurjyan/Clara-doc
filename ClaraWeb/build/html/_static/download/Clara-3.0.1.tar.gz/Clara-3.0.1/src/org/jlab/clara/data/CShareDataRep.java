/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */


package org.jlab.clara.data;

import java.util.HashMap;
import java.util.Map;

/**
 * @author gurjyan
 * @version 3.x
 */
public class CShareDataRep
{
    // key = receiver service name
    // value = map where
    // key = sender-service-name/requestID, value = data JioSerial Object
    private static final Map<String, Map<String, JioSerial>> sharedData = new HashMap<String, Map<String,JioSerial>>();


    public static synchronized void putInputData(String receiver, String sender, int requestID, JioSerial data)
    {
        Map<String, JioSerial> inputs = sharedData.get(receiver);
        if (inputs != null) {
            String key = sender + "/" + requestID;
            inputs.put(key, data);
        }
    }


    public static synchronized JioSerial getInputData(String receiver, String sender, int requestID)
    {
        Map<String, JioSerial> inputs = sharedData.get(receiver);
        JioSerial data = null;
        if (inputs != null) {
            String key = sender + "/" + requestID;
            data = inputs.get(key);
            inputs.remove(key);
        }
        return data;
    }


    static synchronized void putInputData(String receiver, String sender, JioSerial data)
    {
        Map<String, JioSerial> input = sharedData.get(receiver);
        if (input != null) {
            input.put(sender, data);
        }
    }


    public static synchronized JioSerial getInputData(String receiver, String sender)
    {
        Map<String, JioSerial> inputs = sharedData.get(receiver);
        JioSerial data = null;
        if (inputs != null) {
            data = inputs.get(sender);
            inputs.remove(sender);
        }
        return data;
    }


    public static synchronized void addReceiver(String receiver)
    {
        sharedData.put(receiver, new HashMap<String, JioSerial>());
    }


    public static synchronized void removeReceiver(String receiver)
    {
        sharedData.remove(receiver);
    }


    public static synchronized boolean isInJvm(String receiver){
        return sharedData.containsKey(receiver);
    }
}
