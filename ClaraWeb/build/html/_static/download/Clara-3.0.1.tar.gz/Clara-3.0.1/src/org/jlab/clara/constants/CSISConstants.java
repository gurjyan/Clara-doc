package org.jlab.clara.constants;

import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @author gurjyan
 * @version 3.x
 */
public class CSISConstants {

    public static AtomicBoolean debug = new AtomicBoolean();

    public static String pswDir = "./.pswd";

    public static final String LOCAL_SERVICE                            = "local_service";
    public static final String REMOTE_CONTAINER                         = "remote_container";
    public static final String REMOTE_SERVICE                           = "remote_service";
    public static final String DATA_IN_SHARED_MEMORY                    = "data_in_shared_memory";
    public static final String DATA_IN_MESSAGE                          = "data_in_message";

    public static final String SERVICE_NAME                             = "service_name";
    public static final String SERVICE_NAME1                            = "service_name1";
    public static final String SERVICE_NAME2                            = "service_name2";
    public static final String SERVICE_AUTHOR                           = "service_author";
    public static final String SERVICE_DESCRIPTION                      = "service_description";
    public static final String SERVICE_VERSION                          = "service_version";
    public static final String SERVICE_LANGUAGE                         = "service_language";
    public static final String SERVICE_STATUS                           = "service_status";
    public static final String SERVICE_LOG_MESSAGE                      = "service_log_message";

    public static final String SERVICE_NAMES                            = "service_names";
    public static final String SERVICE_AUTHORS                           = "service_authors";
    public static final String SERVICE_DESCRIPTIONS                      = "service_descriptions";
    public static final String SERVICE_VERSIONS                          = "service_versions";
    public static final String SERVICE_LANGUAGES                         = "service_languages";

    // Platform and DPE names
    public static final String    PLATFORM_NAME_SUFFIX      = "_platform";
    public static final String    DPE_NAME_SUFFIX_JAVA      = "_admin";
    public static final String    DPE_NAME_SUFFIX_CPP       = "_cpp_admin";

    public static final String    NAME                 = "claraName";

    public static final String    DESCRIPTION          = "description";
    public static final String    TYPE                 = "type";
    public static final String    HOST                 = "host";
    public static final String    EXPID                = "EXPID";
    public static final String    STARTTIME            = "myStartTime";
    public static final String    SERVICES             = "serviceNames";
    public static final String    SERVICE_LOADS        = "serviceLoads";
    public static final String    DALOGSEVERITY        = "severity";
    public static final String    DALOGSEVERITYID      = "dseverityId";
    public static final String    DALOGTEXT            = "dalogText";
    public static final String    TIMESTAMP            = "timeStamp";

    // environment specific
    public static final String    CPUTOTALMEMORY       = "cpuTotalMemory";
    public static final String    CPUFREEMEMORY        = "cpuFreeMemory";
    public static final String    CPUBUFFERS           = "cpuBuffers";
    public static final String    CPULOAD              = "cpuLoad";
    public static final String    CPUACTIVEPROCESSES   = "cpuActiveProcesses";
    public static final String    CPUTOTALPROCESSES    = "cpuTotoalProcesses";

    public static final String    CONTAINER_TYPE_JAVA  = "Java_Service_Container";
    public static final String    CONTAINER_TYPE_CPP   = "Cpp_Service_Container";

    public static final String SERVICE_REQUEST_ID                       = "service_request_id";
    public static final String SERVICE_REQUEST_TIMEOUT                  = "service_request_timeout";
    public static final String SERVICE_EXCEPTION_SOURCE                 = "service_exception_source";
    public static final String SERVICE_EXCEPTION_DESTINATION            = "service_exception_destination";
    public static final String SERVICE_DATA_SOURCE                      = "service_data_source";
    public static final String SERVICE_DATA_BROADCAST                   = "service_data_broadcast";
    public static final String SERVICE_DONE_BROADCAST                   = "service_done_broadcast";
    public static final String SERVICE_DATA_DESTINATION                 = "service_data_destination";
    public static final String SERVICE_DATA                             = "service_data";
    public static final String SERVICE_DATA_DESCRIPTION                 = "service_data_description";
    public static final String SERVICE_DATA_UNIT                        = "service_data_unit";
    public static final String SERVICE_DATA_MIME_TYPE                   = "service_data_mime_type";
    public static final String SERVICE_DATA_ENDIANNESS                  = "service_data_endianness";
    public static final String SERVICE_DATA_VERSION                     = "service_data_version";
    public static final String SERVICE_ENGINE_CONTROL                   = "service_engine_control";

    public static final String CLARA_DPE_NAME                           = "clara_dpe_name";
    public static final String CLARA_DPE_EXPID                          = "clara_dpe_expid";
    public static final String CLARA_DPE_HOST                           = "clara_dpe_host";
    public static final String CLARA_DPE_DESCRIPTION                    = "clara_dpe_description";
    public static final String CLARA_DPE_STARTTIME                      = "clara_dpe_startTime";

    public static final String SERVICE_CONTAINERS                       = "service_containers";
    public static final String SERVICE_CONTAINER_NAME                   = "service_container_name";
    public static final String SERVICE_CONTAINER_HOST                   = "service_container_host";
    public static final String SERVICE_CONTAINER_TYPE                   = "service_container_type";
    public static final String CONTAINER_POOL_SIZE                      = "service_container_pool_size";
    public static final String SERVICE_CONTAINER_STARTTIME              = "service_container_startTime";
    public static final String SERVICE_CONTAINER_LOAD                   = "service_container_load";
    public static final String SERVICE_CONTAINER_STATUS                 = "service_container_status";
    public static final String SERVICE_ENGINE_CLASSPATH                 = "service_engine_classpath";
    public static final String SERVICE_CONTAINER_LOAD_INTERVAL          = "service_container_load_interval";
    public static final String SERVICE_ENGINE_NAME                      = "service_engine_name";

    public static final String REQUESTER_NAME                           = "service_requester_name";
    public static final String REQUESTER_SUBJECT                        = "service_requester_subject";
    public static final String REQUESTER_TYPE                           = "service_requester_type";

    public static final String DATA_REPORT                              = "data_report";
    public static final String EXCEPTION_REPORT                         = "exception_report";
    public static final String WARNING_REPORT                           = "warning_report";
    public static final String DONE_REPORT                              = "done_report";

    public static final String LOG_SUBJECT                              = "log_subject";
    public static final String LOG_TYPE                                 = "log_type";

    public static final String DB_URL                                  = "jdbc:mysql://clasdb.jlab.org:3306/clara";
    public static final String DB_DRIVER                               = "com.mysql.jdbc.Driver";
    public static final String DB_USER                                 = "clasuser";
    public static final String DB_PASSWORD                             = "";


    /***********************************************************************
     *
     *                            Clara Platform
     *
     * *********************************************************************/

    public static final String PlatformRegistrationRequest               = "platform/registration/request/*";
    public static final String PlatformRegistrationRequestAddClaraDPE    = "platform/registration/request/dpe/add";
    public static final String PlatformRegistrationRequestUpdateClaraDPE = "platform/registration/request/dpe/update";
    public static final String PlatformRegistrationRequestRemoveDPE      = "platform/registration/request/dpe/remove";
    public static final String PlatformRegistrationRequestAddServiceContainer        = "platform/registration/request/sc/add";
    public static final String PlatformRegistrationRequestServiceContainerLoadUpdate = "platform/registration/request/sc/updateLoad";
    public static final String PlatformRegistrationRequestRemoveServiceContainer     = "platform/registration/request/sc/remove";

    public static final String PlatformInfoResponseName                 = "platform/info/response/name";
    public static final String PlatformInfoResponseHost                 = "platform/info/response/host";
    public static final String PlatformInfoResponsePort                 = "platform/info/response/port";
    public static final String PlatformInfoResponseStartTime            = "platform/info/response/myStartTime";

    public static final String PlatformInfoRequest                      = "platform/info/request/*";
    public static final String PlatformInfoRequestIsRegistered          = "platform/info/request/isRegistered";
    public static final String PlatformInfoRequestRegisteredDPEs        = "platform/info/request/registeredDPEs";
    public static final String PlatformInfoRequestRegisteredServices    = "platform/info/request/registeredServices";
    public static final String PlatformInfoRequestServiceInfo           = "platform/info/request/serviceInfo";
    public static final String PlatformInfoRequestName                  = "platform/info/request/name";
    public static final String PlatformInfoRequestHost                  = "platform/info/request/host";
    public static final String PlatformInfoRequestPort                  = "platform/info/request/port";
    public static final String PlatformInfoRequestStartTime             = "platform/info/request/myStartTime";
    public static final String PlatformInfoServiceContainers            = "platform/info/request/serviceContainers";

    /***********************************************************************
     *
     *                            Clara Normative Gateway Service
     *
     * *********************************************************************/

    public static final String GatewayControl                             = "gateway/control/*";
    public static final String GatewayControlStartContainer               = "gateway/control/startContainer";
    public static final String GatewayControlStopContainer                = "gateway/control/stopContainer";
    public static final String GatewayControlStartService                 = "gateway/control/startService";
    public static final String GatewayControlStopService                  = "gateway/control/stopService";
    public static final String GatewayControlConfigureService             = "gateway/control/configureService";
    public static final String GatewayControlServiceMonitorOn             = "gateway/control/serviceMonitorOn";
    public static final String GatewayControlServiceMonitorOff            = "gateway/control/serviceMonitorOff";
    public static final String GatewayControlLinkServices                 = "gateway/control/linkServices";
    public static final String GatewayControlUnLinkServices               = "gateway/control/unLinkServices";
    public static final String GatewayControlRequestService               = "gateway/control/requestService";
    public static final String GatewayControlSyncRequestService           = "gateway/control/syncRequestService";
    public static final String GatewayServiceControlRequestVersion        = "gateway/control/RequestVesrion";
    public static final String GatewayServiceControlRequestBroadcast      = "gateway/control/RequestBroadcast";
    public static final String GatewayControlSetContainerLoadStatInterval = "gateway/control/setContainerLoadStatInterval";

    /***********************************************************************
     *
     *                            Clara Platform Scheduler
     *
     * *********************************************************************/
    public static final String SchedulerControl                          = "gateway/control/*";
    public static final String SchedulerControlSetPassword               = "gateway/control/setPassword";
    public static final String SchedulerControlSetPermissions            = "gateway/control/setPermissions";

    /***********************************************************************
     *
     *                            Clara Data Processing Environment (DPE)
     *
     * *********************************************************************/

    public static final String DPEControlRequest               = "dpe/control/request/*";
    public static final String DPEControlStartServiceContainer = "dpe/control/request/startClaraServiceContainer";
    public static final String DPEControlStopServiceContainer  = "dpe/control/request/stopClaraServiceContainer";
    public static final String DPEControlSetUser               = "dpe/control/request/setUser";
    public static final String DPEControlRemoveUser            = "dpe/control/request/removeUser";
    public static final String DPEControlExit                  = "dpe/control/request/exit";

    public static final String DPEInfoRequest                  = "dpe/info/request/*";
    public static final String DPEInfoRequestState             = "dpe/info/request/state";
    public static final String DPEInfoRequestServiceContainers = "dpe/info/request/serviceContainers";

    public static final String DPEInfoResponse                 = "dpe/info/response/*";
    public static final String DPEInfoResponseStatus           = "dpe/info/response/status";

    public static final String ServiceReportDalog              = "system/service/report/dalog";

    public static final String ProxyRequest                    = "proxy/request";

    /***********************************************************************
     *
     *                            Clara Service addressed to container
     *
     * *********************************************************************/

    public static final String ServiceControlRequest                    = "system/service/control/request/*";
    public static final String ServiceControlRequestStartService        = "system/service/control/request/startService";
    public static final String ServiceControlRequestStartServiceFSHM    = "system/service/control/request/startServiceFromSharedMemory";
    public static final String ServiceControlRequestAddInput            = "system/service/control/request/addInput";
    public static final String ServiceControlRequestRemoveInput         = "system/service/control/request/removeInput";
    public static final String ServiceControlRequestLink                = "system/service/control/request/link";
    public static final String ServiceControlRequestUnLink              = "system/service/control/request/unLink";
    public static final String ServiceControlReportLinks                = "system/service/control/request/serviceLinks";
    public static final String ServiceControlRequestAddService          = "system/service/control/request/addService";
    public static final String ServiceControlRequestRemoveService       = "system/service/control/request/removeService";
    public static final String ServiceControlRequestStop                = "system/service/control/request/stop";
    public static final String ServiceControlRequestConfigure           = "system/service/control/request/configure";
    public static final String ServiceControlRequestSubscribe           = "system/service/control/request/subscribe";
    public static final String ServiceControlRequestUnSubscribe         = "system/service/control/request/un_subscribe";
    public static final String ServiceControlRequestVersion             = "system/service/control/request/version";
    public static final String ServiceControlRequestBroadcast           = "system/service/control/request/broadcast";
    public static final String ServiceControlSetLoadStatInterval        = "system/service/control/request/setLoadStatInterval";

}
