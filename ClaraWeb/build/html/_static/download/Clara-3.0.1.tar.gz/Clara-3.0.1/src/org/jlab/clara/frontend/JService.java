/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */


package org.jlab.clara.frontend;


import org.jlab.clas12.tools.MimeType;
import org.jlab.clara.system.ICService;
import org.jlab.clara.data.JioSerial;
import org.jlab.clara.util.CPrintStream;
import org.jlab.clara.util.CUtil;

import java.nio.ByteBuffer;

/**
 * @author gurjyan
 * @version 3.x
 */
public abstract class JService extends BaseApi implements ICService {

    protected String myName;


    protected JService(String name){
        super(name);
        myName = name;
    }

    /**
     * This will permanently allow System.out and System.err printouts to succeed.
     * Note:  any other service running in the same DPE can change the permanent
     * verbosity by calling disableVerbose() method.
     */
    protected void enableVerbose() {
        System.setOut(new CPrintStream(System.out,1));
        System.setErr(new CPrintStream(System.err,1));
    }
    /**
     * This will permanently disallow System.out and System.err printouts to succeed.
     * Note:  any other service running in the same DPE can change the permanent
     * verbosity by calling setVerbose() or enableVerbose() method.
     */
    protected void disableVerbose() {
        System.setOut(new CPrintStream(System.out,0));
        System.setErr(new CPrintStream(System.err,0));
    }


    /**
     * Creates a transient data, describing the cause for rejecting the service request.
     *
     * @param text description of the rejection
     * @param severity of the exception
     * @return  {@link JioSerial} transient data object
     */
    protected JioSerial createRejectTData(String text, String severity){
        JioSerial td = new JioSerial();
        td.setData(text, MimeType.STRING);
        td.setStatus(severity);
        td.setDataDescription(text);
        return td;
    }

    /**
     * Creates an output transient data based on the service engine execution result.
     *
     * @param data service engine output data
     * @param msg  description of the execution
     * @param severity status of the execution
     * @return  {@link JioSerial} transient data object
     */
    protected JioSerial createReportTData(ByteBuffer data, String msg, String severity){
        JioSerial td = new JioSerial();
        byte[] bytes = CUtil.getByteArray(data);
        td.setData(bytes, MimeType.EVIO);
        td.setDataDescription(msg);
        td.setStatus(severity);
        return td;
    }
}
