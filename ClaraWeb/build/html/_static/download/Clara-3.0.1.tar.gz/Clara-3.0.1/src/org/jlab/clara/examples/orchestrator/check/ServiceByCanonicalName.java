/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */


package org.jlab.clara.examples.orchestrator.check;


import org.jlab.clara.frontend.JOrchestrator;
import org.jlab.clara.system.CException;

/**
 *
 * An example of an orchestrator that checks the required service
 * registration information
 *
 * @author gurjyan
 * @version 3.x
 */

public class ServiceByCanonicalName extends JOrchestrator {
    /**
     * Constructor
     * Connects to the Clara platform
     *
     */
    public ServiceByCanonicalName() throws CException {
        super();
    }

    public static void main(String[] args) {
        String serviceName = args[0];

        // instance of this class
        ServiceByCanonicalName csr = null;
        try {
            csr = new ServiceByCanonicalName();

        // get registration information form the platform normative service
        csr.requestRegistrationData(1000);

        // check the platform registration if the service is registered
        if(csr.isServiceDeployed(serviceName)){

            // list service registration information
            csr.getServiceInformation(serviceName);

        } else {
            System.out.println("Service was not found");
        }
            csr.exit();
        } catch (CException e) {
            System.out.println(e.getMessage());
        }
    }
}
