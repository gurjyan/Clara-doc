
/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */



package org.jlab.clara.examples.orchestrator;

import org.jlab.clara.constants.CConstants;
import org.jlab.clara.data.JioSerial;
import org.jlab.clara.frontend.JOrchestrator;
import org.jlab.clas12.tools.MimeType;
import org.jlab.clara.system.CException;

/**
 *
 * Service configuration example
 *
 * @author gurjyan
 * @version 3.x
 */
public class ConfigureService extends JOrchestrator {

    /**
     * Constructor
     * Connects to the Clara platform
     *
     */
    public ConfigureService() throws CException {
        super();
    }

    public static void main(String[] args) {
        String service   = args[0];
        String data  = args[1];

        ConfigureService cs = null;
        try {
            cs = new ConfigureService();
        } catch (CException e) {
            System.out.println(e.getMessage());
        }

        // get registration information form the platform normative examples.services
        try {
            cs.requestRegistrationData(1000);
        } catch (CException e) {
            System.out.println(e.getMessage());
        }

        // check if the service1 is registered
        if(!cs.isServiceDeployed(service)){
            System.err.println("Error: Can not find the " +
                    "registration information for the service = "+service);
            System.exit(1);
        }

        // create configuration data
        JioSerial cData = new JioSerial();
        cData.setLanguage(CConstants.LANG_JAVA);
        cData.setData(data, MimeType.STRING);

        try {
            if(!cs.configureService(service,cData)){
                System.out.println("Error: Configure failed.");
            }
        cs.exit();
        } catch (CException e) {
            System.out.println(e.getMessage());
        }
    }
}
