/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */


package org.jlab.clara.container;

import org.jlab.coda.cMsg.cMsgException;
import org.jlab.coda.cMsg.cMsgMessage;
import org.jlab.coda.cMsg.cMsgPayloadItem;
import org.jlab.clara.constants.CConstants;
import org.jlab.clara.constants.CSISConstants;
import org.jlab.clara.service.CServiceRegistration;

import java.io.Serializable;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * @author gurjyan
 * @version 3.x
 */

public class CSContainerRegistration implements Serializable {
    private String name              = CConstants.udf;
    private String host              = CConstants.udf;
    private String type              = CConstants.udf;
    private String startTime         = CConstants.udf;
    private double load;
    private int    status;
    private CopyOnWriteArrayList<CServiceRegistration> services = new CopyOnWriteArrayList<CServiceRegistration>();

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public CopyOnWriteArrayList<CServiceRegistration> getServices() {
        return services;
    }

    public void setServices(CopyOnWriteArrayList<CServiceRegistration> services) {
        this.services = services;
    }

    public void addService(CServiceRegistration ser){
        services.add(ser);
    }
    public void removeService(CServiceRegistration ser){
        services.remove(ser);
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    /**
     *
     * @param name
     * @return CServiceRegistration object
     */
    public CServiceRegistration getServiceRegistration(String name){
        for(CServiceRegistration sr:services){
            if(sr.getRegistrationName().equals(name)) return sr;
        }
        return null;
    }

    public double getLoad() {
        return load;
    }

    public void setLoad(double load) {
        this.load = load;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public String[] getAsArray(){
        String[] as = new String[5];
        as[0] = name;
        as[1] = host;
        as[2] = Double.toString(load);
        as[3] = type;
        as[4] = startTime;
        return as;
    }

    public cMsgMessage getAscMsgMessage(){
        cMsgMessage m = new cMsgMessage();

        // not sure if this is necessary
        m.setSubject(CConstants.udf);
        m.setType(CConstants.udf);

        try {
            if(!name.equals(CConstants.udf) && !host.equals(CConstants.udf)){
                m.addPayloadItem(new cMsgPayloadItem(CSISConstants.SERVICE_CONTAINER_NAME,name));
                m.addPayloadItem(new cMsgPayloadItem(CSISConstants.SERVICE_CONTAINER_HOST,host));
                m.addPayloadItem(new cMsgPayloadItem(CSISConstants.SERVICE_CONTAINER_TYPE,type));
                m.addPayloadItem(new cMsgPayloadItem(CSISConstants.SERVICE_CONTAINER_LOAD,load));
                m.addPayloadItem(new cMsgPayloadItem(CSISConstants.SERVICE_CONTAINER_STATUS,status));
                m.addPayloadItem(new cMsgPayloadItem(CSISConstants.SERVICE_CONTAINER_STARTTIME,startTime));

                if(services!=null && services.size()>0){
                    String[] sNames        = new String[services.size()];
                    String[] sDescriptions = new String[services.size()];
                    String[] sAuthors      = new String[services.size()];
                    String[] sVersions     = new String[services.size()];
                    String[] sLanguages    = new String[services.size()];

                    int i = 0;
                    for(CServiceRegistration sr:services){
                        sNames[i]        = sr.getRegistrationName();
                        sDescriptions[i] = sr.getDescription();
                        sAuthors[i]      = sr.getAuthor();
                        sVersions[i]     = sr.getVersion();
                        sLanguages[i]    = sr.getLanguage();
                        i++;
                    }
                    m.addPayloadItem(new cMsgPayloadItem(CSISConstants.SERVICE_NAMES,sNames));
                    m.addPayloadItem(new cMsgPayloadItem(CSISConstants.SERVICE_DESCRIPTIONS,sDescriptions));
                    m.addPayloadItem(new cMsgPayloadItem(CSISConstants.SERVICE_AUTHORS,sAuthors));
                    m.addPayloadItem(new cMsgPayloadItem(CSISConstants.SERVICE_VERSIONS,sVersions));
                    m.addPayloadItem(new cMsgPayloadItem(CSISConstants.SERVICE_LANGUAGES,sLanguages));
                }
            }
        } catch (cMsgException e) {
            e.printStackTrace();
        }

        return m;
    }



    public String toHtmlStringS() {
        int n = services.size();
        return "<font color =\"blue\"> Clara Service Container </font><br> " +
                "<table border=\"1\" cellpadding=\"0\" cellspacing=\"0\">" +
                "<tr>" +
                "<td> Name </td> " +
                "<td>" + name + "</td> " +
                "</tr>" +
                "<tr>" +
                "<td> Host </td>" +
                "<td>" + host + "</td>" +
                "</tr>" +
                "<tr>" +
                "<td< Type </td>" +
                "<td>" + type +  "</td>" +
                "</tr>" +
                "<tr>" +
                "<td> StartTime </td>" +
                "<td>" + startTime + "</td>" +
                "</tr>" +
                "<tr>" +
                "<td> Load </td>" +
                "<td>" + load + "</td>" +
                "</tr>" +
                "<tr>" +
                "<td> Services </td>" +
                "<td>" + n + "</td>" +
                "</tr>" +
                "</table>";
    }

    public String toHtmlString() {
        StringBuffer sb = new StringBuffer();
        sb.append(toHtmlStringS());
        for(CServiceRegistration srv:services){
            sb.append(srv.toHtmlString());
        }
        return sb.toString();
    }

    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append("Container:\n" +
                "  Name        = " + name + "\n" +
                "  Host        = " + host + "\n" +
                "  Type        = " + type + "\n" +
                "  StartTime   = " + startTime + "\n" +
                "  Load        = " + load + "\n\n"+
                "Services:\n\n");
        for(CServiceRegistration srv:services){
            sb.append(srv.toString());
        }
        return sb.toString();
    }


}
