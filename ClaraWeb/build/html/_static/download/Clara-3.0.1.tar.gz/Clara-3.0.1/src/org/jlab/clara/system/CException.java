package org.jlab.clara.system;

/**
 * Main exception class for the Clara
 * @author gurjyan
 * @version 3.x
 */
    public class CException extends Exception {

        public CException() {
        }

        public CException(String msg) {
            super(msg);
        }

        public CException(Throwable cause) {
            super(cause);
        }

        public CException(String msg, Throwable cause) {
            super(msg, cause);
        }
    }

