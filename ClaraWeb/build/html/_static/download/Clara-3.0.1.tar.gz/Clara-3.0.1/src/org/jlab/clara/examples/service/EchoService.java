/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */


package org.jlab.clara.examples.service;

import org.jlab.clara.constants.CConstants;
import org.jlab.clara.data.JioSerial;
import org.jlab.clara.frontend.JService;
import org.jlab.clas12.tools.MimeType;


/**
 *
 * A toy service that echos a received string
 *
 * @author gurjyan
 * @version 3.x
 */

public class EchoService extends JService {

    protected EchoService(String name) {
        super(name);
    }

    @Override
    public JioSerial execute(JioSerial data) {

        // output transient data object
        JioSerial out = new JioSerial();
        out.setLanguage(CConstants.LANG_JAVA);

        // check the input data mime-type
        if(data.getMimeType() == MimeType.STRING){

            // get the data content
             String inputDataObject = data.getStringObject();

            // generate the output data
            out.setData(inputDataObject);
            out.setDataDescription("response to "+inputDataObject);
            out.setStatus(CConstants.info);
        } else {

            // Reject with an execution status = error
            out.setData(CConstants.REJECT);
            out.setDataDescription("I can accept only strings");
            out.setStatus(CConstants.error);
        }
        return out;
    }


    @Override
    public String getName() {
        return "echo";
    }

    @Override
    public String getAuthor() {
        return "Gyurjyan";
    }

    @Override
    public String getDescription() {
        return "Echo service";
    }

    @Override
    public String getVersion() {
        return  "1.0";
    }

    @Override
    public String getLanguage() {
        return CConstants.LANG_JAVA;
    }

    @Override
    public JioSerial execute(JioSerial[] data) {
        return null;
    }

    @Override
    public void configure(JioSerial data) {
    }

    @Override
    public void destruct() {
    }

}





