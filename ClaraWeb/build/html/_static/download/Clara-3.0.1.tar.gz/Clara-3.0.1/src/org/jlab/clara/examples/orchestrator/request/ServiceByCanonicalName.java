/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */


package org.jlab.clara.examples.orchestrator.request;

import org.jlab.clara.data.JioSerial;
import org.jlab.clara.frontend.JOrchestrator;
import org.jlab.clas12.tools.MimeType;
import org.jlab.clara.system.CException;

/**
 *
 * @author gurjyan
 * @version 3.x
 */

public class ServiceByCanonicalName extends JOrchestrator {
    /**
     * Constructor
     * Connects to the Clara platform
     *
     */
    public ServiceByCanonicalName() throws CException {
        super();
    }

    public static void main(String[] args) {
        String serviceName = args[0];
        String data;
        if (args.length == 2)
            data = args[1];
        else
            data = "none";

        // instance of this class
        ServiceByCanonicalName rs = null;
        try {
            rs = new ServiceByCanonicalName();

            // get registration information form the platform registration and discovery clas12.services
            rs.requestRegistrationData(1000);

            // check the platform registration if the service in question is registered
            if(rs.isServiceDeployed(serviceName)){

                // request the service

                // create a request transient data
                JioSerial dataRequest = new JioSerial();
                dataRequest.setData(data, MimeType.STRING);

                // send the request
                JioSerial dataResponse = rs.syncRunService(serviceName, dataRequest,1,1000);

                // print the response
                System.out.println(dataResponse);
            } else {
                System.out.println("Service was not found");
            }
            rs.exit();
        } catch (CException e) {
            System.out.println(e.getMessage());
        }
    }
}
