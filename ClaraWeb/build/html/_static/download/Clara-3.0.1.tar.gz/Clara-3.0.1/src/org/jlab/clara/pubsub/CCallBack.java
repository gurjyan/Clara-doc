/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */

package org.jlab.clara.pubsub;

import org.jlab.clara.data.JioSerial;
import org.jlab.coda.cMsg.cMsgCallbackAdapter;
import org.jlab.coda.cMsg.cMsgMessage;
import org.jlab.clara.constants.CConstants;

/**
 * Callback class that calls interface <code>ICallBack<code> method
 * whenever it receives the callback.
 * This callback can check received message subject, type and sender,
 * or ignore them.
 *
 * @author gurjyan
 * @version 3.x
 */

public abstract class CCallBack extends cMsgCallbackAdapter implements ICallBack{

    private static String sender  = CConstants.udf;
    private static String subject = CConstants.udf;
    private static String type    = CConstants.udf;

    /**
     * Basic constructor
     * @param sender author of the incoming message
     * @param subject subject of the message of interest
     * @param type type of the message of interest
     */
    public CCallBack(String sender, String subject, String type){
        if(sender != null) CCallBack.sender = sender;
        if(subject !=null) CCallBack.subject = subject;
        if(type != null) CCallBack.type = type;
    }

    protected CCallBack() {
    }

    @Override
    public void callback(cMsgMessage msg, Object userObject){

            // ignore sender, subject and type and execute the callback method
        if(sender.equals(CConstants.udf) && subject.equals(CConstants.udf) && type.equals(CConstants.udf)){
            monitorCallBack(new JioSerial(msg));

            // check sender
        } else if(!sender.equals(CConstants.udf) && subject.equals(CConstants.udf) && type.equals(CConstants.udf)){
            if(msg.getSender().equals(sender)){
                 monitorCallBack(new JioSerial(msg));
            }

            // check subject
        } else if(sender.equals(CConstants.udf) && !subject.equals(CConstants.udf) && type.equals(CConstants.udf)){
            if(msg.getSubject().equals(subject)){
                 monitorCallBack(new JioSerial(msg));
            }

            // check type
        } else if(sender.equals(CConstants.udf) && subject.equals(CConstants.udf) && !type.equals(CConstants.udf)){
            if(msg.getType().equals(type)){
                 monitorCallBack(new JioSerial(msg));
            }

            // check subject and type before execution the callback method
        } else if(sender.equals(CConstants.udf) && !subject.equals(CConstants.udf) && !type.equals(CConstants.udf)){
            if(msg.getSubject().equals(subject)&& msg.getType().equals(type)){
                 monitorCallBack(new JioSerial(msg));
            }

            // check sender and the subject
        } else if(!sender.equals(CConstants.udf) && !subject.equals(CConstants.udf) && type.equals(CConstants.udf)){
            if(msg.getSender().equals(sender) && msg.getSubject().equals(subject)){
                 monitorCallBack(new JioSerial(msg));
            }

            // check the sender and the type
        } else if(!sender.equals(CConstants.udf) && subject.equals(CConstants.udf) && !type.equals(CConstants.udf)){
            if(msg.getSender().equals(sender) && msg.getType().equals(type)){
                 monitorCallBack(new JioSerial(msg));
            }

            // check everything, sender, subject and type before execution of the callback method
        } else if(!sender.equals(CConstants.udf) && !subject.equals(CConstants.udf) && !type.equals(CConstants.udf)){
            if(msg.getSender().equals(sender) && msg.getSubject().equals(subject)&& msg.getType().equals(type)){
                 monitorCallBack(new JioSerial(msg));
            }
        }
    }
}

