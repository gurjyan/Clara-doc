/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */
package org.jlab.clara.system;

import org.jlab.clara.dpe.CDPEnvironmentData;
import org.jlab.clara.dpe.CDPEnvironmentInfo;
import org.jlab.clara.container.CSContainerRegistration;
import org.jlab.coda.cMsg.*;
import org.jlab.coda.cMsg.cMsgDomain.server.cMsgNameServer;
import org.jlab.clara.constants.CConstants;
import org.jlab.clara.constants.CSISConstants;
import org.jlab.clara.pubsub.CTrParameter;
import org.jlab.clara.util.CLogger;
import org.jlab.clara.util.CPrintStream;
import org.jlab.clara.util.CUtil;
import org.jlab.clara.util.CpuMonitoringThread;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @author gurjyan
 * @version 3.x
 */
public class CDPEnvironment extends CcMsgDrive {

    // CDPEnvironmentInfo object describing this DPE admin service
    private CDPEnvironmentInfo myInfo;

    // Exclusive user for this DPE
    private String myUser = CConstants.udf;


    // Map of all service container objects started by the help of this
    // DPE administrative service (running in the same jvm)
    private ConcurrentHashMap<String, CServiceContainer> myServiceContainers = new ConcurrentHashMap<String, CServiceContainer>();

    // Map containing entire platform registered service information
    public static ConcurrentHashMap<String, CSContainerRegistration> _serviceContainers = new ConcurrentHashMap<String, CSContainerRegistration>();

    // indicates when the message from the platform admin service arrives
    public static AtomicBoolean update = new AtomicBoolean(false);

    // Reporting threads
    private PlatformReportingThread platformReport = new PlatformReportingThread();
    private LifeLineT lifeLine = new LifeLineT();

    // Subscription handlers
    private cMsgSubscriptionHandle dpeControl;
    private cMsgSubscriptionHandle dpeInfo;
    private cMsgSubscriptionHandle containerInfo;
    private String myName;

    // local instance of the logger object
    private static CLogger lg = CLogger.getInstance();

    public static void main(String[] args){
        int log = 0;
        String plHost = CConstants.udf;
        if(args.length==2){
            if(args[0].equalsIgnoreCase("-host")){
                plHost = args[1];
            } else {
                printSynopsis();
            }
        } else if(args.length==3){
            for(int i=0;i<3;i++){
                if(args[i].equalsIgnoreCase("-host")){
                    plHost = args[i+1];
                } else {
                    if(args[i].equalsIgnoreCase("-log")){
                        log = 1;
                    }
                }
            }
        } else {
            printSynopsis();
            System.exit(1);
        }

        String plIpAdd = CUtil.getIPAddress(plHost);
        if (plIpAdd.equals(CConstants.udf)) {
            System.err.println("Error: bad platform host.");
            System.exit(1);
        }
        if (plIpAdd.equalsIgnoreCase(CUtil.getIPAddress("localhost"))) {
            System.err.println("Error: Clara DPE on a local node must run within the platform.");
            System.exit(1);
        }

        new CDPEnvironment(plIpAdd, log);
    }


    private static void printSynopsis(){
        System.out.println("synopsis: clara-dpe -host (platform host name) [ -log (error, warning, info) ]");
    }


    /**
     * Constructor for the standalone DPE.
     */
    public CDPEnvironment(String platformHost, int stdout){
        myConfig.configPlatformConnection(platformHost);

        myName = myConfig.getLocalDpeName();

        try {
            connect2Platform(myName);
        } catch (CException e) {
            lg.logger.severe(CUtil.stack2str(e));
        }

        if (isPlatformConnected()) {
            startDPEServer();
            try {
                connect2LocalDpe(myName);
            } catch (CException e) {
                lg.logger.severe(CUtil.stack2str(e));
            }

            if (stdout == 0) {
                disableOutput();
            }

            myInfo = new CDPEnvironmentInfo(
                    myName,
                    myConfig.getLocalDpeHost(),
                    myConfig.getPlatformHost(),
                    "Data Processing Environment");
            printStartupMessage(true);

            register();
            doSubscriptions();
            reportUpAndRunning();

            platformReport.start();
            lifeLine.start();
        } else {
            System.err.println("Error: could not connect to the platform.");
            System.exit(1);
        }
    }


    /**
     * Constructor for the platform DPE.
     */
    public CDPEnvironment(boolean x) {
        myName = myConfig.getLocalDpeName();

        try {
            connect2Platform(myName);
        } catch (CException e) {
            lg.logger.severe(CUtil.stack2str(e));
        }
        if (isPlatformConnected()) {
            myInfo = new CDPEnvironmentInfo(
                    myName,
                    myConfig.getLocalDpeHost(),
                    myConfig.getPlatformHost(),
                    "Data Processing Environment");
            printStartupMessage(false);

            register();
            doSubscriptions();
            reportUpAndRunning();

            platformReport.start();
        } else {
            lg.logger.severe(" Could not connect to the platform.");
            System.exit(1);
        }
    }


    private void disableOutput() {
        System.setOut(new CPrintStream(System.out, 0));
        System.setErr(new CPrintStream(System.err, 0));
    }


    private void printStartupMessage(boolean standalone) {
        System.out.println("**************************************************");
        System.out.println("*      Clara-3 Data Processing Environment       *");
        System.out.println("**************************************************");
        System.out.println("- Name                  = "+ myConfig.getLocalDpeName());
        System.out.println("- Host                  = "+ myConfig.getLocalDpeHost());
        System.out.println("- Start time            = "+ myInfo.getStartTime());
        if (standalone) {
            System.out.println("- Stand alone");
        } else {
            System.out.println("-");
        }
        System.out.println("- Platform host         = "+ myConfig.getPlatformHost());
        System.out.println("- Platform name         = "+ myConfig.getPlatformName());
        System.out.println("- Platform TCP port     = "+ myConfig.getPlatformTcpPort());
        System.out.println("- Platform UDP port     = "+ myConfig.getPlatformUdpPort());
        System.out.println("**************************************************");
    }


    private boolean reportUpAndRunning(){
        CTrParameter p = new CTrParameter();
        p.setConnection(getPlatformConnection());
        p.setSubject("dpe");
        p.setType("report");
        ArrayList<cMsgPayloadItem> al = new ArrayList<cMsgPayloadItem>();
        try {
            al.add(new cMsgPayloadItem("host",myConfig.getLocalDpeHost()));
            al.add(new cMsgPayloadItem("cores",Runtime.getRuntime().availableProcessors()));
            al.add(new cMsgPayloadItem("clara-services",System.getenv("CLARA_SERVICES")));
        } catch (cMsgException e) {
            lg.logger.severe(CUtil.stack2str(e));
        }
        p.setPayloadItems(al);
        try {
            return send(p);
        } catch (CException e) {
            lg.logger.severe(CUtil.stack2str(e));
            return false;
        }
    }


    private boolean reportHeartBeet(){
        CTrParameter p = new CTrParameter();
        p.setConnection(getPlatformConnection());
        p.setSubject("dpe");
        p.setType("report");
        ArrayList<cMsgPayloadItem> al = new ArrayList<cMsgPayloadItem>();
        try {
            al.add(new cMsgPayloadItem("host",myConfig.getLocalDpeHost()));
            al.add(new cMsgPayloadItem("cores",Runtime.getRuntime().availableProcessors()));
            al.add(new cMsgPayloadItem("clara-services",System.getenv("CLARA_SERVICES")));
            al.add(new cMsgPayloadItem("containers",myServiceContainers.size()));
        } catch (cMsgException e) {
            lg.logger.severe(CUtil.stack2str(e));
        }
        p.setPayloadItems(al);
        try {
            return send(p);
        } catch (CException e) {
            lg.logger.severe(CUtil.stack2str(e));
            return false;
        }
    }


    /**
     * Starts Clara DPE cMsg server and connects to the platform server to form star-cloud
     */
    private void startDPEServer(){
        cMsgNameServer   dpeServer = new cMsgNameServer(
                myConfig.getPlatformTcpPort(),
                myConfig.getPlatformTcpDomainPort(),
                myConfig.getPlatformUdpPort(),
                true,
                true,
                null,
                null,
                null,
                cMsgConstants.debugNone,
                10);
//        dpeServer.setName(myName.replace(".", ""));
        dpeServer.startServer();
    }


    /**
     * registration of this DPE administrator service with the platform
     * @return status of the operation
     */
    private boolean register(){
//        System.out.println(myName+ " sending registration request to subject = "+
//                myConfig.getPlatformName()+" type = "+ CSISConstants.PlatformRegistrationRequestAddClaraDPE);

        CTrParameter p = new CTrParameter();
        p.setConnection(getPlatformConnection());
        p.setSubject(myConfig.getPlatformName());
        p.setType(CSISConstants.PlatformRegistrationRequestAddClaraDPE);
        p.setPayloadItems(myInfo.toPayload());
        boolean stat = false;
        try {
            stat = send(p);
        } catch (CException e) {
            lg.logger.severe(CUtil.stack2str(e));
        }

        if(stat) System.out.println(myName+ " registered with the platform at "+CUtil.getCurrentTime());
        else lg.logger.warning(myName+": Failed to register with the platform.");

        return stat;
    }


    /**
     * Subscribes basic DPE subscriptions.
     * @return status of the operation
     */
    private boolean doSubscriptions(){
        boolean status = true;
        try {
            // subscribe messages asking DPE to start or stop agents
            dpeControl = getLoaclDPEConnection().subscribe(myInfo.getName(), CSISConstants.DPEControlRequest, new DPEControlRequestCB(), null);
            // subscribe messages asking to report status of the DPE,
            // that includes the names and loads of all service running in this DPE.
            dpeInfo = getLoaclDPEConnection().subscribe(myInfo.getName(), CSISConstants.DPEInfoRequest, new DPEInfoRequestCB(), null);

            // subscribe information from the platform administrative agent periodically reporting about
            // all registered services
            containerInfo = getPlatformConnection().subscribe(myConfig.getPlatformName(),
                    CSISConstants.PlatformInfoServiceContainers, new ContainerInfoCB(), null);

        } catch (cMsgException e) {
            lg.logger.severe(CUtil.stack2str(e));
            status = false;
        }
        return status;
    }


    /**
     * Returns the data of this agent as an ArrayList of payloadItems
     * @return  array list of payload items.
     */
    private ArrayList<cMsgPayloadItem> getAsPayload(){
        ArrayList<cMsgPayloadItem> al = new ArrayList<cMsgPayloadItem>();
        try {
            if(myInfo.getName()!=null) al.add(new cMsgPayloadItem(CSISConstants.NAME, myInfo.getName()));
            if(myInfo.getDescription()!=null) al.add(new cMsgPayloadItem(CSISConstants.DESCRIPTION, myInfo.getDescription()));
            if(myInfo.getHost()!=null) al.add(new cMsgPayloadItem(CSISConstants.HOST, myInfo.getHost()));
            if(myInfo.getExpid()!=null) al.add(new cMsgPayloadItem(CSISConstants.EXPID, myInfo.getExpid()));
            if(myInfo.getStartTime()!=null) al.add(new cMsgPayloadItem(CSISConstants.STARTTIME, myInfo.getStartTime()));
            if(myServiceContainers !=null && !myServiceContainers.isEmpty()){
                String [] n = new String[myServiceContainers.keySet().size()];
                double [] l    = new double[myServiceContainers.keySet().size()];
                int i=0;
                for(String s: myServiceContainers.keySet()){
                    n[i] = s;
                    if(myServiceContainers.contains(s))
                        l[i] = myServiceContainers.get(s).getLoad();
                    i++;
                }
                al.add(new cMsgPayloadItem(CSISConstants.SERVICES,n));
                al.add(new cMsgPayloadItem(CSISConstants.SERVICE_LOADS,l));
            }
            if(CpuMonitoringThread.cpuTotalMemory.get() >0)
                al.add(new cMsgPayloadItem(CSISConstants.CPUTOTALMEMORY, CpuMonitoringThread.cpuTotalMemory.get()));
            if(CpuMonitoringThread.cpuFreeMemory.get()>0)
                al.add(new cMsgPayloadItem(CSISConstants.CPUFREEMEMORY,CpuMonitoringThread.cpuFreeMemory.get()));
            if(CpuMonitoringThread.cpuBuffers.get()>0)
                al.add(new cMsgPayloadItem(CSISConstants.CPUBUFFERS,CpuMonitoringThread.cpuBuffers.get()));
            if(Double.longBitsToDouble(CpuMonitoringThread.cpuLoad.get())>0)
                al.add(new cMsgPayloadItem(CSISConstants.CPULOAD,Double.longBitsToDouble(CpuMonitoringThread.cpuLoad.get())));
            if(CpuMonitoringThread.cpuActiveProcesses.get()>0)
                al.add(new cMsgPayloadItem(CSISConstants.CPUACTIVEPROCESSES,CpuMonitoringThread.cpuActiveProcesses.get()));
            if(CpuMonitoringThread.cpuTotalProcesses.get()>0)
                al.add(new cMsgPayloadItem(CSISConstants.CPUTOTALPROCESSES,CpuMonitoringThread.cpuTotalProcesses.get()));

        } catch (cMsgException e) {
            lg.logger.severe(CUtil.stack2str(e));
        }
        return al;
    }


    private void startServiceContainer(cMsgMessage msg) {
        String result = "rejected";
        String contName = msg.getText();
        if (contName != null) {
            if (validateUser(msg.getSender())) {
                try {
                    if (!myServiceContainers.containsKey(contName)) {
                        cMsgPayloadItem payload = msg.getPayloadItem(CSISConstants.SERVICE_CONTAINER_TYPE);
                        if (payload != null) {
                            String containerType = payload.getString();
                            if (containerType.equals("java")) {
                                int threadPoolSize = 100;
                                payload = msg.getPayloadItem(CSISConstants.CONTAINER_POOL_SIZE);
                                if (payload != null) {
                                    threadPoolSize = payload.getInt();
                                }
                                CServiceContainer sc = null;
                                try {
                                    sc = new CServiceContainer(contName, threadPoolSize);
                                } catch (CException e) {
                                    lg.logger.severe(CUtil.stack2str(e));
                                }
                                myServiceContainers.put(contName,sc);
                                result = "done";
                            }
                        }
                    } else {
                        result = "container exists";
                    }
                    if (msg.isGetRequest()) {
                        cMsgMessage mr = msg.response();
                        mr.setSubject(CConstants.udf);
                        mr.setType(CConstants.udf);
                        mr.setText(result);
                        getLoaclDPEConnection().send(mr);
                    }
                } catch (cMsgException e) {
                    lg.logger.severe(CUtil.stack2str(e));
                }
            }
        }
    }


    private void stopServiceContainer(cMsgMessage msg) {
        String contName = msg.getText();
        if (contName != null) {
            if (myServiceContainers.containsKey(contName)) {
                System.out.println(myName + ": Request to stop Clara service container " + contName);
                try {
                    myServiceContainers.get(contName).scExit();
                } catch (CException e) {
                    lg.logger.severe(CUtil.stack2str(e));
                }
                myServiceContainers.remove(contName);
                System.gc();
                System.gc();
            }
        }
    }


    private boolean validateUser(String sender) {
        return myUser.equals(CConstants.udf) || myUser.equals(sender);
    }


    private void setUser(String user) {
        myUser = user.trim();
        reportUpAndRunning();
    }


    private void removeUser() {
        myUser = CConstants.udf;
        reportUpAndRunning();
    }


    private void exit() {
        try {
            getLoaclDPEConnection().unsubscribe(dpeControl);
            getLoaclDPEConnection().unsubscribe(dpeInfo);
            getPlatformConnection().unsubscribe(containerInfo);
        } catch (cMsgException e) {
            lg.logger.severe(CUtil.stack2str(e));
        }
        System.exit(0);
    }



    /**
     * Private inner class for responding to messages for this administrative service of
     * the data processing environment ( for example starting/stopping service containers).
     */
    private class DPEControlRequestCB extends cMsgCallbackAdapter {

        @Override
        public void callback(cMsgMessage msg, Object userObject){
            String type = msg.getType();

            if (type.equals(CSISConstants.DPEControlStartServiceContainer)){
                startServiceContainer(msg);

            } else if (type.equals(CSISConstants.DPEControlStopServiceContainer)) {
                stopServiceContainer(msg);

            } else if(type.equals(CSISConstants.DPEControlExit)){
                exit();

            } else if (type.equals(CSISConstants.DPEControlSetUser)) {
                setUser(msg.getText());

            } else if (type.equals(CSISConstants.DPEControlRemoveUser)) {
                removeUser();
            }
        }
    }



    /************************************************************************
     * Private inner class for responding to this data processing environment info request messages
     */
    private class DPEInfoRequestCB extends cMsgCallbackAdapter {
        @Override
        public void callback(cMsgMessage msg, Object userObject){
            String type = msg.getType();
            if(type.equals(CSISConstants.DPEInfoRequestState)){
                if(msg.isGetRequest()){
                    try {
                        cMsgMessage mr = msg.response();
                        mr.setSubject(CConstants.udf);
                        mr.setType(CConstants.udf);
                        mr.setText("I am alive");
                        getLoaclDPEConnection().send(mr);
                    } catch (cMsgException e) {
                        lg.logger.severe(CUtil.stack2str(e));
                    }
                }
            } else if (type.equals(CSISConstants.DPEInfoRequestServiceContainers)){
                if(msg.isGetRequest()){
                    try {
                        cMsgMessage mr = msg.response();
                        mr.setSubject(CConstants.udf);
                        mr.setType(CConstants.udf);
                        try {
                            mr.setByteArray(CUtil.O2B(_serviceContainers));
                        } catch (IOException e) {
                            lg.logger.severe(CUtil.stack2str(e));
                        }
                        getLoaclDPEConnection().send(mr);
                    } catch (cMsgException e) {
                        lg.logger.severe(CUtil.stack2str(e));
                    }
                }
            }
        }
    }



    /************************************************************************
     * Private inner call back class that is called whenever message arrives
     * from the platform administrative service.
     */
    private class ContainerInfoCB extends cMsgCallbackAdapter {
        @SuppressWarnings("unchecked")
        @Override
        public void callback(cMsgMessage msg, Object userObject){
            ConcurrentHashMap<String, CSContainerRegistration> scs = null;
            if(msg.getByteArray()!=null){
                try {
                    scs = (ConcurrentHashMap<String, CSContainerRegistration>)CUtil.B2O(msg.getByteArray());
                } catch (IOException e) {
                    lg.logger.severe(CUtil.stack2str(e));
                } catch (ClassNotFoundException e) {
                    lg.logger.severe(CUtil.stack2str(e));
                }
                _serviceContainers = scs;
                update.set(true);
            }
        }
    }



    /**
     * **********************************************************************
     * Thread checks if we are connected to the platform.
     * If not will try every 1sec until it succeeds
     * This thread will run forever.
     */
    private class LifeLineT extends Thread {

        private boolean isActive = true;

        @Override
        public void run() {
            super.run();
            while(isActive){

                if(!isPlatformConnected()){
                    platformReport.isConnected = false;
                    lg.logger.severe("Error: Lost connection to the platform!");
                    while(!isPlatformConnected()){
                        try {
                            connect2Platform(myName);
                        } catch (CException e) {
                            lg.logger.severe(CUtil.stack2str(e));
                        }
                        CUtil.sleep(1000);
                    }
                    lg.logger.warning("Restored connection to the platform!");
                    doSubscriptions();
                    register();
                    CUtil.sleep(5000);
                    platformReport.isConnected = true;
                }
                CUtil.sleep(3000);
                // broadcast heart-beet
                reportHeartBeet();
            }
        }
    }



    /*************************************************************************
     * Periodically reports to the platform administrator service the names
     * for all service containers running in this data processing environment
     */
    private class PlatformReportingThread extends Thread {

        private boolean isRunning = true;
        private boolean isConnected = true;

        @Override
        public void run() {
            super.run();
            while (isRunning) {
                if (isConnected) {
                    reportDpeData();
                }
                CUtil.sleep(1000);
            }
        }


        public void stopReporting(){
            isRunning = false;
        }


        private void reportDpeData() {
            CDPEnvironmentData cd = new CDPEnvironmentData();

            // create arrayList containing names of all service containers of this DPE
            CopyOnWriteArrayList<String> containers = new CopyOnWriteArrayList<String>();
            for (String container : myServiceContainers.keySet()) {
                containers.add(container);
            }
            cd.setServiceContainers(containers);

            CTrParameter p = new CTrParameter();
            p.setConnection(getPlatformConnection());
            p.setSubject(myConfig.getPlatformName());
            p.setType(CSISConstants.DPEInfoResponseStatus);

            // payload describing DPE. CPU info will be empty 0's since currently this class
            // is not instantiated the CpuMonitoringThread
            p.setPayloadItems(getAsPayload());

            // this dpe environment data object
            p.setData(cd);

            try {
                send(p);
            } catch (CException e) {
                lg.logger.severe(CUtil.stack2str(e));
            }
        }
    }
}
