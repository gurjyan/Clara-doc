package org.jlab.clara.system;

import org.jlab.clara.pubsub.CTrParameter;

/**
 * Clara publish subscribe communication interface
 *
 * @author gurjyan
 * @version Clara-3.0.1
 * @date 4/4/14
 */
public interface IClaraDataBus {

    public Object connect(String name, String udl, String description) throws CException;
    public Object connect2Dpe(String name, String host) throws CException;
    public Object connect2Platform(String name) throws CException;
    public Object connect2LocalDpe(String name) throws CException;
    public void disconnect(Object connection) throws CException;
    public void platformDisconnect() throws CException;
    public void localDpeDisconnect() throws CException;
    public boolean isConnected(Object connection);
    public boolean isPlatformConnected();
    public boolean isLocalDpeConnected();
    public boolean send(CTrParameter p) throws CException;
    public Object syncSend(CTrParameter p) throws CException;

}
