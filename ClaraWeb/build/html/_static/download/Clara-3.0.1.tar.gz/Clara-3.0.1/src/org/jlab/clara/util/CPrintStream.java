/*
 * Copyright (c) 2013 by JSA, TJNAF DAQ. All rights reserved.
 * This software was developed under a United States Government license.
 * Initiated V. Gyurjyan
 */

package org.jlab.clara.util;

import java.io.OutputStream;
import java.io.PrintStream;

/**
 * The print stream that takes into account verbosity level.
 * At the moment it will ignore prints  both for System.out
 * and System.err in case verbosity = 0 (default)
 *
 * @author gurjyan
 * @version Clara
 * @date 10/24/13
 */

public class CPrintStream extends PrintStream {

    private int verbosity = 0;

    /**
     * Clara print stream
     * @param out output stream, usually System.out
     * @param verbosity if set 0 System.out and System.err printouts will be ignored.
     */
    public CPrintStream(OutputStream out, int verbosity) {
        super(out);
        this.verbosity= verbosity;
    }

    @Override
    public void println(String x) {
        if(verbosity>0) super.println(x);
    }

    @Override
    public void print(String s) {
        if(verbosity>0) super.print(s);
    }
}
