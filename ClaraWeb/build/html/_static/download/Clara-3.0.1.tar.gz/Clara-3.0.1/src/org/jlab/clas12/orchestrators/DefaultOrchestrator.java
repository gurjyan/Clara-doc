/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */
package org.jlab.clas12.orchestrators;

import com.martiansoftware.jsap.*;
import org.jlab.clara.config.CConfig;
import org.jlab.clara.constants.CConstants;
import org.jlab.clara.data.JioSerial;
import org.jlab.clara.pubsub.CCallBack;
import org.jlab.clara.system.CException;
import org.jlab.clara.util.CUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Runs the standard reconstruction of a CLAS12 file.
 * The reconstruction chain should be already registered by {@link DefaultDeploy}.
 * <p>
 * This orchestrator is called by the {@code run} command of the
 * {@code default-orchestrator} script distributed with CLARA. Check the
 * {@link #setArguments} method for a full description of the input
 * parameters.
 */
public class DefaultOrchestrator {

    private ReconstructionOrchestrator orchestrator = null;
    private final ReconstructionNode ioNode;

    private final int nCores;
    private final List<String> nodeNames;

    private final String inputFileName;
    private final String outputFileName;

    private int frequency = 1000;
    private List<String> reconstructionChain;


    public static void main(String[] args) {
        /* Check the arguments */
        JSAP jsap = new JSAP();
        setArguments(jsap);
        JSAPResult config = jsap.parse(args);
        if (!config.success()) {
            System.err.printf("Usage:%n%n  default-orchestrator run %s%n%n%n", jsap.getUsage());
            System.err.println(jsap.getHelp());
            System.exit(1);
        }

        String platform = config.getString(ARG_PLATFORM);
        boolean remote = config.getBoolean(ARG_REMOTE_IO);
        String inFile = config.getString(ARG_INPUT_FILE);
        String outFile = config.getString(ARG_OUTPUT_FILE);
        int nc = config.getInt(ARG_THREADS);


        /* Check that the number of cores is valid */
        if (nc <= 0) {
            System.err.printf("Error: bad number of threads: %d%n", nc);
            System.exit(1);
        }

        /* If no nodes given, use default value */
        String[] recNodes = config.getStringArray(ARG_NODES);
        if (recNodes.length == 0) {
            if (remote) {
                recNodes = new String[] { platform };
            } else {
                recNodes = new String[] { "localhost" };
            }
        }

        /* Check that all the node names are valid */
        List<String> nodeNames = new ArrayList<String>();
        for (String node : recNodes) {
            String nodeIp = CUtil.getIPAddress(node);
            if (nodeIp.equals(CConstants.udf)) {
                System.exit(1);
            }
            nodeNames.add(nodeIp);
        }

        /* Run the orchestrator */
        DefaultOrchestrator dfo = new DefaultOrchestrator(platform, inFile, outFile, nc, nodeNames, remote);
        dfo.run();
    }


    private static final String ARG_PLATFORM = "platform";
    private static final String ARG_REMOTE_IO = "remote";
    private static final String ARG_THREADS = "nThreads";
    private static final String ARG_INPUT_FILE = "inputFile";
    private static final String ARG_OUTPUT_FILE = "outputFile";
    private static final String ARG_NODES = "nodes";

    private static void setArguments(JSAP jsap) {

        FlaggedOption platform = new FlaggedOption(ARG_PLATFORM)
                .setStringParser(JSAP.STRING_PARSER)
                .setRequired(false)
                .setShortFlag('p')
                .setDefault(CConfig.getInstance().getPlatformHost());
        platform.setHelp("The IP of the CLARA platform.");

        Switch remoteIO = new Switch(ARG_REMOTE_IO)
                .setShortFlag('r');
        remoteIO.setHelp("Use the remote platform for I/O and reconstruction.");

        UnflaggedOption inputFile = new UnflaggedOption(ARG_INPUT_FILE)
                .setStringParser(JSAP.STRING_PARSER)
                .setRequired(true);
        inputFile.setHelp("The EVIO input file to be reconstructed.");

        UnflaggedOption outputFile = new UnflaggedOption(ARG_OUTPUT_FILE)
                .setStringParser(JSAP.STRING_PARSER)
                .setRequired(true);
        outputFile.setHelp("The EVIO output file where reconstructed events will be saved.");

        UnflaggedOption nThreads = new UnflaggedOption(ARG_THREADS)
                .setStringParser(JSAP.INTEGER_PARSER)
                .setRequired(true);
        nThreads.setHelp("The number of threads per node for event processing.");

        UnflaggedOption nodes = new UnflaggedOption(ARG_NODES)
                .setGreedy(true);
        nodes.setHelp("The nodes that should be used for reconstruction.");

        try {
            jsap.registerParameter(platform);
            jsap.registerParameter(remoteIO);
            jsap.registerParameter(inputFile);
            jsap.registerParameter(outputFile);
            jsap.registerParameter(nThreads);
            jsap.registerParameter(nodes);
        } catch (JSAPException e) {
            e.printStackTrace();
            System.exit(1);
        }
    }


    /**
     * Creates a generic object to reconstruct events.
     *
     * @param infile the input file with the events
     * @param outfile the output file to save the events
     * @param nCores the number of threads per node for event processing
     * @param nodeNames arrayList of Clara cloud node names
     */
    DefaultOrchestrator(String platform,
                        String infile,
                        String outfile,
                        int nCores,
                        List<String> nodeNames,
                        boolean remote) {
        try {
            this.orchestrator = new ReconstructionOrchestrator(platform, "default_orchestrator");
        } catch (CException e) {
            System.out.println(e.getMessage());
        }

        this.inputFileName = infile;
        this.outputFileName = outfile;
        this.nCores = nCores;

        String ioNodeName;
        if (remote) {
            ioNodeName = orchestrator.getPlatformHost();
        } else {
            ioNodeName = orchestrator.getLocalHost();
        }
        DpeInfo ioDpe = new DpeInfo(ioNodeName, 0, DpeInfo.defaultClaraServices);
        this.ioNode = new ReconstructionNode(orchestrator, ioDpe);
        this.nodeNames = nodeNames;
    }


    void run() {
        if (check()) {
            setup();
            start();
            processFile();
        }
    }


    private boolean check() {
        if (!orchestrator.isPlatformConnected()) {
            System.err.println("Error: could not connect to CLARA cloud.");
            orchestrator.end();
            return false;
        }
        boolean status = true;
        if (!orchestrator.checkDpe(ioNode.dpe.name)) {
            System.err.printf("Error: %s DPE is not alive (needed for I/O)%n", ioNode.dpe.name);
            status = false;
        }
        for (String host : nodeNames) {
            if (!orchestrator.checkDpe(host)) {
                System.err.printf("Error: DPE %s is not alive%n", host);
                status = false;
            }
        }
        reconstructionChain = orchestrator.getRegisteredReconstructionServicesNames(ioNode.dpe);
        if (reconstructionChain.isEmpty()) {
            status = false;
        }
        if (status == false) {
            orchestrator.end();
        }
        return status;
    }


    private void processFile() {
        System.out.println("Start processing...");
        for (String host : nodeNames) {
            ioNode.sendEventsToDpe(host, nCores);
        }
    }


    private void setup() {
        ioNode.setFiles(inputFileName, outputFileName);
        ioNode.openFiles(frequency);
    }


    private void start() {
        try {
            orchestrator.errorMonitorOn(ioNode.readerName, new ErrorHandlerCB(),false);
            orchestrator.errorMonitorOn(ioNode.writerName, new ErrorHandlerCB(),false);

            for(String s:reconstructionChain){
                orchestrator.errorMonitorOn(s, new ErrorHandlerCB(),false);
            }
            orchestrator.dataMonitorOn(ioNode.writerName, new DataHandlerCB(),false);

            JioSerial configData = new JioSerial(ioNode.currentInputFile);
            for (String recService : reconstructionChain) {
                orchestrator.configService(recService, configData,false);
            }
        } catch (CException e) {
            System.out.println(e.getMessage());
        }

    }


    private void stop() {
        try {
            orchestrator.errorMonitorOff(ioNode.readerName,false);
            orchestrator.dataMonitorOff(ioNode.writerName,false);
        } catch (CException e) {
            System.out.println(e.getMessage());
        }
    }


    private void end() {
        System.out.println("Processing is complete...");
        orchestrator.end();
    }



    private class DataHandlerCB extends CCallBack {

        @Override
        public void monitorCallBack(JioSerial data) {
            long endTime = System.currentTimeMillis();
            ioNode.eventNumber += frequency;
            double timePerEvent = (endTime - ioNode.startTime) /  (double) ioNode.eventNumber;
            System.out.printf("Average event processing time = %.2f ms%n", timePerEvent);
        }
    }



    private class ErrorHandlerCB extends CCallBack {

        @Override
        public void monitorCallBack(JioSerial data) {
            String source = data.getExceptionSource();
            String description = data.getDataDescription();
            String host = CUtil.parse4DpeHostName(source);
            int requestId = data.getRequestID();

            if (description.equalsIgnoreCase("End of file")) {
                if (data.getIntObject() == 1) {
                    ioNode.closeFiles();
                    stop();
                    end();
                }
            } else {
                System.err.printf("Error in %s (requestId: %d):%n%s%n", source, requestId, description);
                ioNode.requestEvent(host, requestId, "next-rec");
            }
        }
    }
}
