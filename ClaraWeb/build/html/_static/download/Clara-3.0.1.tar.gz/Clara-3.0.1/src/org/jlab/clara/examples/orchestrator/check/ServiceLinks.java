/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */


package org.jlab.clara.examples.orchestrator.check;


import org.jlab.clara.frontend.JOrchestrator;
import org.jlab.clara.system.CException;

import java.util.List;

/**
 *
 * An example of an orchestrator that lists information about
 * all service that are linked to a particular service
 *
 * @author gurjyan
 * @version 3.x
 */

public class ServiceLinks extends JOrchestrator {
    /**
     * Constructor
     * Connects to the Clara platform
     *
     */
    public ServiceLinks() throws CException {
        super();
    }

    public static void main(String[] args) {
        String serviceName = args[0];

        // instance of this class
        ServiceLinks csl;
        try {
            csl = new ServiceLinks();

            // get registration information form the platform normative service
            csl.requestRegistrationData(1000);

            // get the name of all linked service
            List<String> l = csl.getLinks(serviceName, 1000);
            int i = 0;
            for (String s : l) {
                System.out.println("... " + ++i);
                System.out.println(csl.getServiceInformation(s));
                System.out.println();
            }
            if (i == 0) {
                System.out.println("No service are linked.");
                System.out.println();
            }
            csl.exit();
        } catch (CException e) {
            System.out.println(e.getMessage());
        }
    }
}
