/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */


package org.jlab.clas12.services.system;


import org.jlab.clara.constants.CConstants;
import org.jlab.clara.data.JioSerial;
import org.jlab.clara.frontend.JService;
import org.jlab.clas12.tools.MimeType;
import org.jlab.clas12.tools.property.JProperty;
import org.jlab.clas12.tools.property.JPropertyList;


/**
 *
 * This service provides an information about the JVM of the Clara data processing environment.
 * Information includes the number of available processors and info about the memory.
 *
 * @author gurjyan
 * @version 3.x
 */

public class JVMInfoService extends JService {

    protected JVMInfoService(String name) {
        super(name);
    }

    @Override
    public JioSerial execute(JioSerial data) {

        // output transient data object
        JioSerial out;

        // check the input data mime-type and the content
        if(data.getMimeType().type().equals(MimeType.STRING.type()) &&
                data.getStringObject().equals("mem-stat") ){

            // generate the output data by getting run-time specific information
            // number of available processors
            JProperty ap = new JProperty("Available processors",Integer.toString(Runtime.getRuntime().availableProcessors()));

            // amount of the free memory
            JProperty fm = new JProperty("Free memory",Long.toString(Runtime.getRuntime().freeMemory()));

            //  maximum amount of memory that the Java virtual machine will attempt to use
            JProperty mm = new JProperty("Maximum memory",Long.toString(Runtime.getRuntime().maxMemory()));

            //  total amount of memory in the Java virtual machine
            JProperty tm = new JProperty("Total memory",Long.toString(Runtime.getRuntime().totalMemory()));

            // create property list
            JProperty[] ppa = {ap,fm,mm,tm};
            JPropertyList ppl = new JPropertyList(ppa);

            // create an output transient data object
            out = new JioSerial(ppl);
            out.setLanguage(CConstants.LANG_JAVA);
            out.setDataDescription("Run time information for the data " +
                    "processing environment running on "+getClientName());
            out.setStatus(CConstants.info);
        } else {

            // Reject with an execution status = error
            out = new JioSerial();
            out.setLanguage(CConstants.LANG_JAVA);
            out.setData(CConstants.REJECT);
            out.setDataDescription("Can not understand your request");
            out.setStatus(CConstants.error);
        }
        return out;
    }

    @Override
    public String getName() {
        return "cpu";
    }

    @Override
    public String getAuthor() {
        return "Gyurjyan";
    }

    @Override
    public String getDescription() {
        return "Returns current status of the local CPU,"+"\n"
                +"including number of cores (i.e. available processors),"+"\n"
                +"amount of the free memory,"+"\n"
                +"maximum amount of memory that the Java virtual machine will attempt to use,"+"\n"
                +"total amount of memory used in the Java virtual machine,"+"\n"
                +"The expected input is a string \"mem-stat\" and the output is a property list" +"\n"
                +"with the following (respective) property names:" +"\n"
                +"\"Available processors\"" + "\n"
                +"\"Free memory\"" + "\n"
                +"\"Maximum memory\"" + "\n"
                +"\"Total memory\"" + "\n";
    }

    @Override
    public String getVersion() {
        return "1.0";
    }

    @Override
    public String getLanguage() {
        return CConstants.LANG_JAVA;
    }

    @Override
    public void configure(JioSerial data) {
    }

    @Override
    public JioSerial execute(JioSerial[] data) {
        return null;
    }

    @Override
    public void destruct() {

    }

}
