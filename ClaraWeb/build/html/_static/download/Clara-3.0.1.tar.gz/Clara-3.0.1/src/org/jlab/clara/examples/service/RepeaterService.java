/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */


package org.jlab.clara.examples.service;


import org.jlab.clara.constants.CConstants;
import org.jlab.clara.data.JioSerial;
import org.jlab.clara.frontend.JService;

public class RepeaterService extends JService {
    JioSerial data;

    protected RepeaterService(String name) {
        super(name);
    }

    @Override
    public void configure(JioSerial data) {
        data.setDataDescription("repeated data");
        this.data = data;
    }

    @Override
    public JioSerial execute(JioSerial data) {
        return this.data;
    }

    @Override
    public JioSerial execute(JioSerial[] data) {
        System.out.println("repeater service executing");
        return this.data;
    }

    @Override
    public void destruct() {
        data = null;
    }

    @Override
    public String getName() {
        return "RepeaterService";
    }

    @Override
    public String getAuthor() {
        return "Sebouh Paul";
    }

    @Override
    public String getDescription() {
        return "An object is given to the service at configuration time.  " +
                "This object is returned every time the service is executed, until" +
                "a new object is given to the service via configuration";
    }

    @Override
    public String getVersion() {
        return "0.1";
    }

    @Override
    public String getLanguage() {
        return CConstants.LANG_JAVA;
    }
}
