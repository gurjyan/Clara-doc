package org.jlab.clara.constants;

/**
 * @author gurjyan
 * @version 3.x
 */
public class CConstants {
    public static final String LANG_JAVA        = "java";
    public static final String LANG_CPP         = "cpp";
    public static final String LANG_PYTHON      = "python";

    public static final String COMMAND_START    = "start";
    public static final String COMMAND_STOP     = "stop";
    public static final String COMMAND_CLEAR    = "clear";

    public static final String udf              = "undefined";
    public static final String failed           = "Failed";
    public static final String yes              = "yes";
    public static final String no               = "no";
    public static final String info             = "Info";
    public static final String warning          = "Warning";
    public static final String error            = "Error";
    public static final String serror           = "Severe";

    public static final String REJECT           = "rejected";


    public static int defineSeverityID(String severity){
        if(severity.equalsIgnoreCase(info))return 1;
        else if(severity.equalsIgnoreCase(warning))return 2;
        else if(severity.equalsIgnoreCase(error))return 3;
        else if(severity.equalsIgnoreCase(serror))return 4;
        else return 0;

    }

}
