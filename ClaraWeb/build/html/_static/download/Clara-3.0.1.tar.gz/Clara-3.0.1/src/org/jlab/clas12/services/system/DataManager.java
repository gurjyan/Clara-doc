/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */


package org.jlab.clas12.services.system;

import org.jlab.clara.constants.CConstants;
import org.jlab.clara.data.JioSerial;
import org.jlab.clara.frontend.JService;
import org.jlab.clas12.tools.MimeType;
import org.jlab.clas12.tools.property.JPropertyList;
import org.jlab.clara.system.CException;
import org.jlab.clara.util.CUtil;
import org.jlab.clara.util.StdIO;

import java.io.File;
import java.util.Arrays;
import java.util.List;

/**
 * date  8/26/13
 *
 * @author smancill
 */
public class DataManager extends JService {

    private final static String NAME = "StageFiles";

    private final static String PROP_INPUT_PATH = "input_path";
    private final static String PROP_OUTPUT_PATH = "output_path";
    private final static String PROP_STAGE_PATH = "stage_path";

    private final static String PROP_ACTION = "action";
    private final static String PROP_FILENAME = "file";

    private final static String PROP_ACTION_STAGE = "stage_input";
    private final static String PROP_ACTION_REMOVE = "remove_input";
    private final static String PROP_ACTION_SAVE = "save_output";

    private final static String PROP_INPUT_FILE = "input_file";
    private final static String PROP_OUTPUT_FILE = "output_file";


    private String inputPath = System.getenv("CLARA_SERVICES") + File.separator + "data" + File.separator + "in";
    private String outputPath = System.getenv("CLARA_SERVICES") + File.separator + "data" + File.separator + "out";
    private String stagePath = "/scratch";
    private String outputPrefix = "out_";

    protected DataManager(String name) {
        super(name);
    }

    /**
     * Configuration data from an orchestrator should contain the following properties:
     * <ol>
     * <li> {@code input_path}: path to the location of the input-data files.</li>
     * <li> {@code output_path}: destination path of the output-data file.</li>
     * <li> {@code staging_path} (optional): data-file staging location,
     *      that is also used by the orchestrator to configure RW services.</li>
     * </ol>
     * @param data property-list containing the configuration properties
     */
    @Override
    public void configure(JioSerial data) {
        MimeType mt = data.getMimeType();
        if (mt == MimeType.PROPERTY_LIST) {
            JPropertyList pl = data.getPropertyList();
            if (pl.containsProperty(PROP_INPUT_PATH) && pl.containsProperty(PROP_OUTPUT_PATH)) {
                inputPath = pl.getPropertyValue(PROP_INPUT_PATH);
                outputPath = pl.getPropertyValue(PROP_OUTPUT_PATH);
                System.out.printf("%s service: Input path set to %s%n", NAME, inputPath);
                System.out.printf("%s service: Output path set to %s%n", NAME, outputPath);
                if (pl.containsProperty(PROP_STAGE_PATH)) {
                    stagePath = pl.getPropertyValue(PROP_STAGE_PATH);
                    System.out.printf("%s service: Stage path set to %s%n", NAME, stagePath);
                }
            } else {
                System.err.printf("%s config: Missing properties: %s%n", NAME, pl);
            }
        } else {
            System.err.printf("%s config: Wrong mimetype: %s%n", NAME, mt.type());
        }
    }


    /**
     * Accepts a property list with an action and an input file name.
     *
     * Current version assumes that there is a CLAS12 convention
     * that reconstructed/output file name is constructed as:
     * {@code "out_" + input_file_name}
     * <ul>
     * <li>
     * If the <em>action</em> is {@code stage_input} the input file will be
     * copied to the staging directory. The full paths to the input and output files
     * in the staging directory will be returned, so the orchestrator can use them to
     * configure the reader and writer services.
     * <li>
     * If the <em>action</em> is {@code remove_input} the input file will be
     * removed from the staging directory.
     * <li>
     * If the <em>action</em> is {@code save_output} the output file will be
     * saved to the final location and removed from the staging directory.
     * </ul>
     *
     * The data can also be the string {@code get_config}, in which case a property list
     * with the configured paths will be returned.
     *
     * @param data property-list or string
     * @return paths, file names or error
     */
    @Override
    public JioSerial execute(JioSerial data) {
        JioSerial out = new JioSerial();
        MimeType mt = data.getMimeType();

        if (mt.equals(MimeType.PROPERTY_LIST)) {
            JPropertyList pl = data.getPropertyList();
            if (pl.containsProperty(PROP_ACTION) && pl.containsProperty(PROP_FILENAME)) {
                runAction(pl, out);
            } else {
                setError("Missing properties: " + pl, out);
            }
        } else if (mt.equals(MimeType.STRING)) {
            String action = data.getStringObject();
            if (action.equals("get_config")) {
                getConfiguration(out);
            } else {
                setError("Wrong request: " + action, out);
            }
        } else {
            setError("Wrong mimetype: " + mt, out);
        }

        return out;
    }


    private void runAction(JPropertyList pl, JioSerial out) {
        String action = pl.getPropertyValue(PROP_ACTION);
        String inputFileName = pl.getPropertyValue(PROP_FILENAME);
        FilePaths files = new FilePaths(inputFileName);
        if (action.equals(PROP_ACTION_STAGE)) {
            stageInputFile(files, out);
        } else if (action.equals(PROP_ACTION_REMOVE)) {
            removeStagedInputFile(files, out);
        } else if (action.equals(PROP_ACTION_SAVE)) {
            saveOutputFile(files, out);
        } else {
            setError("Wrong " + PROP_ACTION + " value: " + action, out);
        }
    }


    private void stageInputFile(FilePaths files, JioSerial out) {
            List<String> copyInputFile = Arrays.asList("cp", files.inputFile, stagePath);
            StdIO result = null;
            try {
                result = CUtil.fork(copyInputFile, true);
            } catch (CException e) {
                System.out.println(e.getMessage());
                String msg = String.format("Could not stage input file%n%n%s", CUtil.reportException(e));
                setError(msg, out);
            }

            if (result.getExitValue() == 0) {
                System.out.printf("Input file '%s' copied to '%s'%n", files.inputFile, stagePath);
                // return data
                JPropertyList fileNames = new JPropertyList();
                fileNames.addTailProperty(PROP_INPUT_FILE, files.stagedInputFile);
                fileNames.addTailProperty(PROP_OUTPUT_FILE, files.stagedOutputFile);
                out.setData(fileNames);
                out.setStatus(CConstants.info);
            } else {
                String msg = String.format("Could not stage input file%n%n%s", result.getStderr());
                setError(msg, out);
            }
    }


    private void removeStagedInputFile(FilePaths files, JioSerial out) {
        try {
            List<String> removeStagedInputFile = Arrays.asList("rm", files.stagedInputFile);
            StdIO result = CUtil.fork(removeStagedInputFile, true);

            if (result.getExitValue() == 0) {
                System.out.printf("Staged input file %s removed%n", files.stagedOutputFile);
                // return data
                out.setData(files.inputFile);
                out.setStatus(CConstants.info);
            } else {
                String msg = String.format("Could not remove staged input file%n%n%s", result.getStderr());
                setError(msg, out);
            }
        } catch (CException e) {
            String msg = String.format("Could not remove staged input file%n%n%s", CUtil.reportException(e));
            setError(msg, out);
        }
    }


    private void saveOutputFile(FilePaths files, JioSerial out) {
        try {
            // move output file to final location
            List<String> moveStagedOutputFile = Arrays.asList("mv", files.stagedOutputFile, files.outputFile);
            StdIO result = CUtil.fork(moveStagedOutputFile, true);

            if (result.getExitValue() == 0) {
                System.out.printf("Output file '%s' saved to '%s'%n", files.stagedOutputFile, outputPath);
                // return data
                out.setData(files.outputFile);
                out.setStatus(CConstants.info);
            } else {
                String msg = String.format("Could not save output file%n%n%s", result.getStderr());
                setError(msg, out);
            }
        } catch (CException e) {
            String msg = String.format("Could not save output file%n%n%s", CUtil.reportException(e));
            setError(msg, out);
        }
    }


    private void getConfiguration(JioSerial out) {
        JPropertyList config = new JPropertyList();
        config.addTailProperty(PROP_INPUT_PATH, inputPath);
        config.addTailProperty(PROP_OUTPUT_PATH, outputPath);
        config.addTailProperty(PROP_STAGE_PATH, stagePath);
        out.setData(config);
        out.setStatus(CConstants.info);
    }



    private class FilePaths {

        private String stagedOutputFile;
        private String outputFile;
        private String stagedInputFile;
        private String inputFile;


        public FilePaths(String inputFileName) {
            inputFile = inputPath + File.separator + inputFileName;
            stagedInputFile = stagePath + File.separator + inputFileName;

            String outputFileName = outputPrefix + inputFileName;
            outputFile = outputPath + File.separator + outputFileName;
            stagedOutputFile = stagePath + File.separator + outputFileName;
        }
    }



    @Override
    public JioSerial execute(JioSerial[] data) {
        return null;
    }


    @Override
    public void destruct() {
        // nothing
    }


    private void setError(String msg, JioSerial out) {
        out.setDataDescription(msg);
        out.setStatus(CConstants.error);
        System.err.println(msg);
    }


    @Override
    public String getName() {
        return NAME;
    }


    @Override
    public String getAuthor() {
        return "smancill";
    }


    @Override
    public String getDescription() {
        return "Copy files from/to local disk.";
    }


    @Override
    public String getVersion() {
        return "0.7";
    }


    @Override
    public String getLanguage() {
        return CConstants.LANG_JAVA;
    }
}
