/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */

package org.jlab.clara.pubsub;

import org.jlab.coda.cMsg.cMsg;
import org.jlab.coda.cMsg.cMsgMessage;
import org.jlab.coda.cMsg.cMsgPayloadItem;
import org.jlab.clara.constants.CConstants;

import java.util.ArrayList;

/**
 * Utility class to define parameter set to be used to
 * define a connection, form a message, and send
 * through cMsg pub-sub middleWare
 *
 * @author gurjyan
 * @version 3.x
 */

public class CTrParameter {
    private Object                      connection     = null;
    private cMsgMessage                 message        = null;
    private Object                      data           = null;
    private ArrayList<cMsgPayloadItem>  payloadItems   = null;
    private String                      subject        = CConstants.udf;
    private String                      type           = CConstants.udf;
    private String                      text           = CConstants.udf;
    private int                         timeout        = 0;
    private int                         endian         = 0;

    public Object getConnection() {
        return connection;
    }

    public void setConnection(Object connection) {
        this.connection = connection;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public int getEndian() {
        return endian;
    }

    public void setEndian(int endian) {
        this.endian = endian;
    }

    public cMsgMessage getMessage() {
        return message;
    }

    public void setMessage(cMsgMessage message) {
        this.message = message;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public int getTimeout() {
        return timeout;
    }

    public void setTimeout(int timeout) {
        this.timeout = timeout;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public ArrayList<cMsgPayloadItem> getPayloadItems() {
        return payloadItems;
    }

    public void setPayloadItems(ArrayList<cMsgPayloadItem> payloadItems) {
        this.payloadItems = payloadItems;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("subject    = ").append(subject).append("\n");
        sb.append("type       = ").append(type).append("\n");
        sb.append("text       = ").append(text).append("\n");
        sb.append("timeout    = ").append(timeout).append("\n");
        sb.append("endian     = ").append(endian).append("\n");

        return sb.toString();
    }
}
