/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */

package org.jlab.clara.system;

import org.jlab.coda.cMsg.*;
import org.jlab.clara.constants.*;
import org.jlab.clara.data.*;
import org.jlab.clara.pubsub.CCallBack;
import org.jlab.clara.pubsub.CTrParameter;
import org.jlab.clara.util.CLogger;
import org.jlab.clara.util.CUtil;


import java.util.ArrayList;

/**
 * This class plays a role of a gateway services between cloud behind the firewall and
 * an orchestrator set to orchestrate the applications running on the cloud.
 *
 * Attention: this class does not support all methods of COrchestratorBase. To get an access to all
 * methods of COrchestratorBase it is recommended Orchestrator connecting to the platform DPE.
 * This class will be instantiated by the platform as a platform normative service,
 * and will connect to the platform DPE pub-sub server.
 *
 * @author gurjyan
 * @version 3.x
 */

public class ClGateway extends CDriver {
    // local instance of the logger object
    private static CLogger lg = CLogger.getInstance();


    /**
     * Constructor connects to the platform and
     * subscribes Gateway service specific control messages
     */
    public ClGateway(){
        super("Clara_Gateway");
        String myName = "Clara_Gateway";

        // connect to the local DPE (in reality this is platform DPE).
        try {
            connect2Platform(myName);
        } catch (CException e) {
            lg.logger.severe(CUtil.stack2str(e));
        }

        // subscribe gateway control messages
        try {
            getPlatformConnection().subscribe(myName,
                    CSISConstants.GatewayControl,
                    new GatewayControlRequestCB(),
                    null);
        } catch (cMsgException e) {
            lg.logger.severe(CUtil.stack2str(e));
        }
    }

    /**
     * Method to create a container
     *
     */
    private void _createContainer(cMsgMessage msg){
        String ch=null, cn=null, ct= CConstants.LANG_JAVA;
        int cps;
        cMsgPayloadItem payload;

        try {
            payload = msg.getPayloadItem(CSISConstants.SERVICE_CONTAINER_HOST);
            if (payload != null) {
                ch = payload.getString();
            }
            payload = msg.getPayloadItem(CSISConstants.SERVICE_CONTAINER_NAME);
            if (payload != null) {
                cn = payload.getString();
            }

            payload = msg.getPayloadItem(CSISConstants.SERVICE_CONTAINER_TYPE);
            if (payload != null) {
                ct = payload.getString();
            }

            if(ch!=null && cn!=null && ct!=null) {
                payload = msg.getPayloadItem(CSISConstants.CONTAINER_POOL_SIZE);
                if (payload != null) {
                    cps = payload.getInt();
                    createContainerWPool(ch, cn, ct, cps);
                } else {
                    createContainer(ch, cn, ct);
                }
            }
        } catch (cMsgException e) {
            lg.logger.severe(CUtil.stack2str(e));
        } catch (CException e) {
            lg.logger.severe(CUtil.stack2str(e));
        }
    }

    /**
     * Method to remove a container
     *
     */
    private void _removeContainer(cMsgMessage msg){
        String ch=null, cn=null;
        cMsgPayloadItem payload;

        try {
            payload = msg.getPayloadItem(CSISConstants.SERVICE_CONTAINER_HOST);
            if (payload != null) {
                ch = payload.getString();
            }
            payload = msg.getPayloadItem(CSISConstants.SERVICE_CONTAINER_NAME);
            if (payload != null) {
                cn = payload.getString();
            }

            if(ch!=null && cn!=null) {
                removeContainer(ch, cn);
            }
        } catch (cMsgException e) {
            lg.logger.severe(CUtil.stack2str(e));
        } catch (CException e) {
            lg.logger.severe(CUtil.stack2str(e));
        }
    }

    /**
     * Method to deploy a service on a container
     *
     */
    private void _deployService(cMsgMessage msg){
        String ch=null, cn=null, scp = null;
        cMsgPayloadItem payload;

        try {
            payload = msg.getPayloadItem(CSISConstants.SERVICE_CONTAINER_HOST);
            if (payload != null) {
                ch = payload.getString();
            }
            payload = msg.getPayloadItem(CSISConstants.SERVICE_CONTAINER_NAME);
            if (payload != null) {
                cn = payload.getString();
            }

            payload = msg.getPayloadItem(CSISConstants.SERVICE_ENGINE_CLASSPATH);
            if (payload != null) {
                scp = payload.getString();
            }

            if(ch!=null && cn!=null && scp!=null) {
                addService(ch, cn, scp);
            }
        } catch (cMsgException e) {
            lg.logger.severe(CUtil.stack2str(e));
        } catch (CException e) {
            lg.logger.severe(CUtil.stack2str(e));
        }

    }

    /**
     * Method to stop a service on a container
     * Attention: accepts service canonical name.
     *
     */
    private void _stopService(cMsgMessage msg){

        String scn=null;
        cMsgPayloadItem payload;

        try {
            payload = msg.getPayloadItem(CSISConstants.SERVICE_NAME);
            if (payload != null) {
                scn = payload.getString();
            }
            if(scn!=null) {
                removeService(scn);
            }
        } catch (cMsgException e) {
            lg.logger.severe(CUtil.stack2str(e));
        } catch (CException e) {
            lg.logger.severe(CUtil.stack2str(e));
        }
    }

    private void _configService(cMsgMessage msg){
        String serviceCanonicalName = msg.getText();

        try {
            configureServiceGW(serviceCanonicalName, new JioSerial(msg));
        } catch (CException e) {
            lg.logger.severe(CUtil.stack2str(e));
        }

    }

    private void _syncRequestVersion(cMsgMessage msg){
        String requestServiceName = msg.getText();
        int timeOut = 1000;
        try {
            if(msg.getPayloadItem(CSISConstants.SERVICE_REQUEST_TIMEOUT)!=null){
                timeOut = msg.getPayloadItem(CSISConstants.SERVICE_REQUEST_TIMEOUT).getInt();
            }
            syncPingServiceGW(requestServiceName,timeOut);

        } catch (cMsgException e) {
            lg.logger.severe(CUtil.stack2str(e));
        } catch (CException e) {
            lg.logger.severe(CUtil.stack2str(e));
        }
    }

    private void _reportNextEvent(cMsgMessage msg){

        String serviceCanonicalName = msg.getText();
        try {
            reportNextEventGW(serviceCanonicalName);
        } catch (CException e) {
            lg.logger.severe(CUtil.stack2str(e));
        }
    }

    private void _linkServices(cMsgMessage msg){
        String s1=null, s2=null;
        cMsgPayloadItem payload;

        try {
            payload = msg.getPayloadItem(CSISConstants.SERVICE_NAME1);
            if (payload != null) {
                s1 = payload.getString();
            }
            payload = msg.getPayloadItem(CSISConstants.SERVICE_NAME2);
            if (payload != null) {
                s2 = payload.getString();
            }

            if(s1!=null && s2!=null) {
                chainServices(s1, s2);
            }
        } catch (cMsgException e) {
            lg.logger.severe(CUtil.stack2str(e));
        } catch (CException e) {
            lg.logger.severe(CUtil.stack2str(e));
        }
    }

    private void _unLinkServices(cMsgMessage msg){
        String s1=null, s2=null;
        cMsgPayloadItem payload;

        try {
            payload = msg.getPayloadItem(CSISConstants.SERVICE_NAME1);
            if (payload != null) {
                s1 = payload.getString();
            }
            payload = msg.getPayloadItem(CSISConstants.SERVICE_NAME2);
            if (payload != null) {
                s2 = payload.getString();
            }

            if(s1!=null && s2!=null) {
                unChainServices(s1, s2);
            }
        } catch (cMsgException e) {
            lg.logger.severe(CUtil.stack2str(e));
        } catch (CException e) {
            lg.logger.severe(CUtil.stack2str(e));
        }
    }

    private void _requestService(cMsgMessage msg){
        String serviceCanonicalName = msg.getText();
        JioSerial j = new JioSerial(msg);

        try {
            runService(serviceCanonicalName, j, j.getRequestID());
        } catch (CException e) {
            lg.logger.severe(CUtil.stack2str(e));
        }
    }

    private void _syncRequestService(cMsgMessage msg){
        if(msg.isGetRequest()){
            // get the input transient data object from the message
            JioSerial data = new JioSerial(msg);
            String requesteServiceName = msg.getText();
            int reqID = 0,timeOut = 0;
            try {
                reqID = msg.getPayloadItem(CSISConstants.SERVICE_REQUEST_ID).getInt();
                timeOut = msg.getPayloadItem(CSISConstants.SERVICE_REQUEST_TIMEOUT).getInt();
            } catch (cMsgException e) {
                lg.logger.severe(CUtil.stack2str(e));
            }
            if(requesteServiceName!=null && timeOut>0){
                JioSerial o = null;
                try {
                    o = syncRunService(requesteServiceName, data, reqID, timeOut);
                } catch (CException e) {
                    lg.logger.severe(CUtil.stack2str(e));
                }

                ArrayList<cMsgPayloadItem> al = new ArrayList<cMsgPayloadItem>();

                // prepare response message
                cMsgMessage mr;
                try {
                    mr = msg.response();

                    if(o!=null){
                        o.packEnvelope(al,mr);
                    }
                    for(cMsgPayloadItem item:al){
                        mr.addPayloadItem(item);
                    }

                    getPlatformConnection().send(mr);

                } catch (cMsgException e) {
                    e.printStackTrace();
                } catch (CException e) {
                    lg.logger.severe(CUtil.stack2str(e));
                }
            }
        }
    }

    /**
     * Method to monitor an output of a service. Output can be data, error, warning, and or done.
     *
     */
    private void _serviceOutputMonitorOn(cMsgMessage msg){
        String subject=null, type = null;
        String monitoredService = msg.getText();
        cMsgPayloadItem payload;

        try {
            payload = msg.getPayloadItem(CSISConstants.REQUESTER_SUBJECT);
            if (payload != null) {
                subject = payload.getString();
            }

            payload = msg.getPayloadItem(CSISConstants.REQUESTER_TYPE);
            if (payload != null) {
                type = payload.getString();
            }

            if(monitoredService!=null && subject!=null && type!=null) {
                serviceMonitorOn(monitoredService, subject, type, new ServiceMonitorCB(subject, type));
            }
        } catch (cMsgException e) {
            lg.logger.severe(CUtil.stack2str(e));
        } catch (CException e) {
            lg.logger.severe(CUtil.stack2str(e));
        }

    }

    /**
     * Method to stop monitoring the output of a service
     *
     */
    private void _serviceOutputMonitorOff(cMsgMessage msg){
        String subject=null, type = null;
        String monitoredService = msg.getText();
        cMsgPayloadItem payload;

        try {
            payload = msg.getPayloadItem(CSISConstants.REQUESTER_SUBJECT);
            if (payload != null) {
                subject = payload.getString();
            }

            payload = msg.getPayloadItem(CSISConstants.REQUESTER_TYPE);
            if (payload != null) {
                type = payload.getString();
            }

            if(monitoredService!=null && subject!=null && type!=null) {

                serviceMonitorOff(monitoredService, subject, type);
            }
        } catch (cMsgException e) {
            lg.logger.severe(CUtil.stack2str(e));
        } catch (CException e) {
            lg.logger.severe(CUtil.stack2str(e));
        }

    }

    private void _setContainerLoadStatInterval(cMsgMessage msg){
        String ch=null, cn=null;
        int li;
        cMsgPayloadItem payload;

        try {
            payload = msg.getPayloadItem(CSISConstants.SERVICE_CONTAINER_HOST);
            if (payload != null) {
                ch = payload.getString();
            }
            payload = msg.getPayloadItem(CSISConstants.SERVICE_CONTAINER_NAME);
            if (payload != null) {
                cn = payload.getString();
            }

            if(ch!=null && cn!=null ) {
                payload = msg.getPayloadItem(CSISConstants.SERVICE_CONTAINER_LOAD_INTERVAL);
                if (payload != null) {
                    li = payload.getInt();
                    setLoadStatInterval(ch,cn,li);
                }
            }
        } catch (cMsgException e) {
            lg.logger.severe(CUtil.stack2str(e));
        } catch (CException e) {
            lg.logger.severe(CUtil.stack2str(e));
        }
    }

    private class MsgForwardThread extends Thread {
        private String subject, type;
        private cMsgMessage msg;

        MsgForwardThread(cMsgMessage msg, String subject, String type) {
            this.msg = msg;
            this.subject = subject;
            this.type = type;
        }
        @Override
        public void run() {
            super.run();
            // create and add parameters for the transport
            CTrParameter p = new CTrParameter();
            p.setConnection(getLoaclDPEConnection());
            p.setMessage(msg);
            p.setText(subject);
            p.setSubject(subject);
            p.setType(type);
            try {
                send(p);
            } catch (CException e) {
                lg.logger.severe(CUtil.stack2str(e));
            }
        }
    }

    /**
     * Private inner class for listening monitored service output data
     */
    private class ServiceMonitorCB extends CCallBack {
        private String subject, type;

        ServiceMonitorCB(String subject , String type){
            super(null,subject,type);
            this.subject = subject;
            this.type = type;
        }

        @Override
        public void monitorCallBack(JioSerial data) {
            // This method does nothing because we are not using
            // CCallBack callback method, but we will override
            // our own callback method below.
        }

        @Override
        public void callback(cMsgMessage msg, Object userObject){
            new MsgForwardThread(msg,subject,type).start();
        }
    }

    /**
     * Private inner class for responding to messages for an orchestrator
     */
    private class GatewayControlRequestCB extends cMsgCallbackAdapter {
        @Override
        public void callback(cMsgMessage msg, Object userObject){
            String type = msg.getType();
            if(type.equals(CSISConstants.GatewayControlStartContainer)){
                _createContainer(msg);
            }
            else if (type.equals(CSISConstants.GatewayControlStopContainer)){
                _removeContainer(msg);
            }
            else if (type.equals(CSISConstants.GatewayControlStartService)){
                _deployService(msg);
            }
            else if (type.equals(CSISConstants.GatewayControlStopService)){
                _stopService(msg);
            }
            else if (type.equals(CSISConstants.GatewayControlConfigureService)){
                _configService(msg);
            }
            else if (type.equals(CSISConstants.GatewayControlLinkServices)){
                _linkServices(msg);
            }
            else if (type.equals(CSISConstants.GatewayControlUnLinkServices)){
                _unLinkServices(msg);
            }
            else if (type.equals(CSISConstants.GatewayControlRequestService)){
                _requestService(msg);
            }
            else if (type.equals(CSISConstants.GatewayControlServiceMonitorOn)){
                _serviceOutputMonitorOn(msg);
            }
            else if (type.equals(CSISConstants.GatewayControlServiceMonitorOff)){
                _serviceOutputMonitorOff(msg);
            }
            else if (type.equals(CSISConstants.GatewayControlSetContainerLoadStatInterval)){
                _setContainerLoadStatInterval(msg);
            }
            else if (type.equals(CSISConstants.GatewayServiceControlRequestBroadcast)){
                _reportNextEvent(msg);
            }
            else if (type.equals(CSISConstants.GatewayServiceControlRequestVersion)){
                _syncRequestVersion(msg);
            }
            else if (type.equals(CSISConstants.GatewayControlSyncRequestService)){
                _syncRequestService(msg);
            }
        }
    }

}