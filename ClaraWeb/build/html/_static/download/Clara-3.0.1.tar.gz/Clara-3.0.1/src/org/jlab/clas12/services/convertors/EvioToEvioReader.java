/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */
package org.jlab.clas12.services.convertors;

import org.jlab.clara.constants.CConstants;
import org.jlab.clara.data.JioSerial;
import org.jlab.clas12.tools.MimeType;
import org.jlab.clas12.tools.property.JPropertyList;
import org.jlab.coda.jevio.EvioCompactReader;
import org.jlab.coda.jevio.EvioException;
import org.jlab.clara.system.ICService;
import org.jlab.clara.util.CUtil;

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Converter service that converts EvIO persistent data to EvIO transient data
 * (i.e. Reads EvIO events from an input file)
 *
 * @author smancill
 */
public class EvioToEvioReader implements ICService
{
    private final String NAME = "EvioToEvioReader";

    private static final String CONF_ACTION = "action";
    private static final String CONF_FILENAME = "file";

    private static final String CONF_ACTION_OPEN = "open";
    private static final String CONF_ACTION_CLOSE = "close";
    private static final String CONF_ACTION_CACHE = "cache";

    private static final String CONF_REPORT_DONE = "report_done";
    private static final String CONF_REPORT_DATA = "report_data";
    private static final String CONF_REPORT_FREQUENCY = "report_frequency";

    private static final String REQUEST_NEXT = "next";
    private static final String REQUEST_NEXT_REC = "next-rec";
    private static final String REQUEST_EVENT = "event";
    private static final String REQUEST_ORDER = "order";
    private static final String REQUEST_COUNT = "count";

    private static final String NO_FILE = "No open file";
    private static final String END_OF_FILE = "End of file";

    private static final int EOF_NOT_FROM_WRITER = 0;
    private static final int EOF_WAITING_REC = -1;

    private String fileName = CConstants.udf;
    private String openError = NO_FILE;

    private EvioCompactReader evioReader;
    private final Object readerLock = new Object();

    private boolean useCached = false;
    private ByteBuffer cachedEvent;

    private int currentEvent = 1;
    private int eventCount;
    private Set<Integer> processingEvents;

    private int dataRequestCount;
    private String dataRequestTarget = CConstants.udf;
    private AtomicInteger rcData = new AtomicInteger(0);

    private int doneRequestCount;
    private String doneRequestTarget = CConstants.udf;
    private AtomicInteger rcDone = new AtomicInteger(0);

    private int eofRequestCount;


    @Override
    public void configure(JioSerial data)
    {
        final long startTime = System.currentTimeMillis();
        if (data.getMimeType() == MimeType.PROPERTY_LIST) {
            JPropertyList pl = data.getPropertyList();
            if (pl.containsProperty(CONF_ACTION) && pl.containsProperty(CONF_FILENAME)) {
                String action = pl.getPropertyValue(CONF_ACTION);
                if (action.equals(CONF_ACTION_OPEN)) {
                    openFile(pl);
                } else if (action.equals(CONF_ACTION_CLOSE)) {
                    closeFile(pl);
                } else if (action.equals(CONF_ACTION_CACHE)) {
                    readCachedEvent(pl);
                } else {
                    String errMsg = "%s config: Wrong value of '%s' property = '%s'%n";
                    System.err.printf(errMsg, NAME, CONF_ACTION, action);
                }
            } else {
                String errMsg = "%s config: Missing '%s' or '%s' properties. PL: %s%n";
                System.err.printf(errMsg, NAME, CONF_ACTION, CONF_FILENAME, pl);
            }
            configureReports(pl);
        } else {
            String errMsg = "%s config: Wrong mimetype '%s'%n";
            System.err.printf(errMsg, NAME, data.getMimeType().type());
        }
        long configureTime = System.currentTimeMillis() - startTime;
        System.out.printf("%s config time: %d [ms]%n", NAME, configureTime);
    }


    private void openFile(JPropertyList pl)
    {
        synchronized (readerLock) {
            if (evioReader != null) {
                closeFile();
            }
            fileName = CUtil.getFileName(pl.getPropertyValue(CONF_FILENAME));
            System.out.printf("%s service: Request to open file %s%n", NAME, fileName);
            try {
                evioReader = new EvioCompactReader(new File(fileName));
                eventCount = evioReader.getEventCount();
                currentEvent = 1;
                processingEvents = new HashSet<Integer>();
                eofRequestCount = 0;
                rcDone.set(0);
                rcData.set(0);
                System.out.printf("%s service: Opened file %s%n", NAME, fileName);
            } catch (IOException e) {
                openError = String.format("Error opening the file %s%n%s",
                        fileName, CUtil.reportException(e));
                System.err.printf("%s service: %s%n", NAME, openError);
                fileName = CConstants.udf;
            } catch (EvioException e) {
                openError = String.format("Error opening the file %s%n%s",
                        fileName, CUtil.reportException(e));
                System.err.printf("%s service: %s%n", NAME, openError);
                fileName = CConstants.udf;
            }
            if (useCached) {
                useCached = false;
                cachedEvent = null;
            }
        }
    }


    private void closeFile(JPropertyList pl)
    {
        synchronized (readerLock) {
            fileName = CUtil.getFileName(pl.getPropertyValue(CONF_FILENAME));
            System.out.printf("%s service: Request to close file %s%n", NAME, fileName);
            if (evioReader != null) {
                closeFile();
            } else {
                System.err.printf("%s service: File %s not open%n", NAME, fileName);
            }
            openError = NO_FILE;
            fileName = CConstants.udf;
            useCached = false;
            cachedEvent = null;
        }
    }


    private void readCachedEvent(JPropertyList pl)
    {
        openFile(pl);
        synchronized (readerLock) {
            useCached = true;
            if (evioReader != null) {
                try {
                    System.out.printf("%s service: Caching a single event to avoid IO%n", NAME);
                    cachedEvent = evioReader.getEventBuffer(currentEvent, true);
                    System.out.printf("%s service: Event size: %d%n", NAME, cachedEvent.limit());
                    closeFile();
                } catch (EvioException e) {
                    String msg = String.format("Error requesting event from file %s%n%n%s",
                            fileName, CUtil.reportException(e));
                    System.err.printf("%s service: %s%n", NAME, msg);
                }
            }
        }
    }


    private void closeFile()
    {
        evioReader.close();
        evioReader = null;
        System.out.printf("%s service: Closed file %s%n", NAME, fileName);
    }


    private void configureReports(JPropertyList pl)
    {
        // configure done reporting
        if (pl.containsProperty(CONF_REPORT_DONE) && pl.containsProperty(CONF_REPORT_FREQUENCY)) {
            String sf = pl.getPropertyValue(CONF_REPORT_FREQUENCY);
            int nf = CUtil.isNumber(sf);
            if (nf > 0) {
                doneRequestTarget = pl.getPropertyValue(CONF_REPORT_DONE);
                doneRequestCount = nf;
                System.out.printf("%s service: Report 'done' each %d events%n", NAME, nf);
            }
        }

        // configure data reporting
        if (pl.containsProperty(CONF_REPORT_DATA) && pl.containsProperty(CONF_REPORT_FREQUENCY)) {
            String sf = pl.getPropertyValue(CONF_REPORT_FREQUENCY);
            int nf = CUtil.isNumber(sf);
            if (nf > 0) {
                dataRequestTarget = pl.getPropertyValue(CONF_REPORT_DATA);
                dataRequestCount = nf;
                System.out.printf("%s service: Report 'data' each %d events%n", NAME, nf);
            }
        }
    }


    @Override
    public JioSerial execute(JioSerial data)
    {
        JioSerial out = new JioSerial();

        MimeType mt = data.getMimeType();

        // request to get the next event
        if (mt == MimeType.STRING) {
            String value = data.getStringObject();
            if (value.equals(REQUEST_NEXT) || value.equals(REQUEST_NEXT_REC)) {
                if (currentEvent == 1) System.out.printf("%s execute request: %s%n", NAME, REQUEST_NEXT);
                getNextEvent(data, out);
                updateReportCounter(out);
            } else if (value.equals(REQUEST_ORDER)) {
                System.out.printf("%s execute request: %s%n", NAME, REQUEST_ORDER);
                getFileByteOrder(out);
                System.out.printf("%s done request: %s%n", NAME, REQUEST_ORDER);
            } else if (value.equals(REQUEST_COUNT)) {
                System.out.printf("%s execute request: %s%n", NAME, REQUEST_COUNT);
                getEventCount(out);
                System.out.printf("%s done request: %s%n", NAME, REQUEST_COUNT);
            } else {
                setError(String.format("Wrong input data = '%s'", value), out);
            }
            // request to get an specific event or an specific bank
        } else if (mt == MimeType.PROPERTY_LIST) {
            JPropertyList pl = data.getPropertyList();
            // specific event request
            if (pl.containsProperty(REQUEST_EVENT)) {
                String reqEvent = pl.getPropertyValue(REQUEST_EVENT);
                int evtNum = CUtil.isNumber(reqEvent);
                if (evtNum > 0) {
                    getSpecificEvent(evtNum, out);
                    updateReportCounter(out);
                } else {
                    setError(String.format("Wrong event number = '%s'", reqEvent), out);
                }
            } else {
                setError(String.format("Unrecognized properties = '%s'", pl), out);
            }
        } else {
            setError(String.format("Wrong input type '%s'", mt), out);
        }

        return out;
    }


    private boolean isReconstructionRequest(JioSerial data) {
        String type = data.getStringObject();
        return type.equalsIgnoreCase(REQUEST_NEXT_REC);
    }


    private void getNextEvent(JioSerial input, JioSerial out)
    {
        synchronized (readerLock) {
            boolean fromRec = isReconstructionRequest(input);
            if (fromRec) {
                processingEvents.remove(input.getRequestID());
            }
            if (evioReader == null) {
                setError(openError, out);
            } else if (currentEvent > eventCount) {
                setError(END_OF_FILE, out);
                if (fromRec) {
                    if (processingEvents.isEmpty()) {
                        eofRequestCount++;
                        out.setData(eofRequestCount);
                    } else {
                        out.setData(EOF_WAITING_REC);
                    }
                } else {
                    out.setData(EOF_NOT_FROM_WRITER);
                }
            } else {
                if (useCached) {
                    returnCachedEvent(out);
                } else {
                    returnNextEvent(out);
                }
            }
        }
    }


    private void returnNextEvent(JioSerial out)
    {
        try {
            ByteBuffer event = evioReader.getEventBuffer(currentEvent, false);
            out.setData(event, MimeType.EVIO);
            out.setStatus(CConstants.info);
            out.setDataDescription("data");
            out.setRequestID(currentEvent);
            processingEvents.add(currentEvent);
            currentEvent++;
        } catch (EvioException e) {
            String msg = String.format("Error requesting event from file %s%n%n%s",
                    fileName, CUtil.reportException(e));
            setError(msg, out);
        }
    }


    private void returnCachedEvent(JioSerial out)
    {
        if (cachedEvent == null) {
            String msg = String.format("Error getting cached event of file %s%n", fileName);
            setError(msg, out);
        } else {
            out.setData(cachedEvent, MimeType.EVIO);
            out.setStatus("skip");
            out.setDataDescription("data");
            out.setRequestID(currentEvent);
            processingEvents.add(currentEvent);
            currentEvent++;
        }
    }


    private void getSpecificEvent(int eventNumber, JioSerial out)
    {
        synchronized (readerLock) {
            if (evioReader == null) {
                setError(openError, out);
            } else if (eventNumber > eventCount) {
                setError(END_OF_FILE, out);
            } else {
                try {
                    ByteBuffer event = evioReader.getEventBuffer(eventNumber, false);
                    out.setData(event, MimeType.EVIO);
                    out.setStatus(CConstants.info);
                    out.setDataDescription("data");
                } catch (EvioException e) {
                    String msg = String.format("Error requesting event from file %s%n%n%s",
                            fileName, CUtil.reportException(e));
                    setError(msg, out);
                }
            }
        }
    }


    private void updateReportCounter(JioSerial out)
    {
        if (dataRequestCount > 0) rcData.incrementAndGet();
        if (doneRequestCount > 0) rcDone.incrementAndGet();

        // set up data reporting
        if (rcData.get() >= dataRequestCount) {
            out.setDataBroadcast(dataRequestTarget);
            rcData.set(0);
        }

        // set up done reporting
        if (rcDone.get() >= doneRequestCount) {
            out.setDoneBroadcast(doneRequestTarget);
            rcDone.set(0);
        }
    }


    private void getFileByteOrder(JioSerial out)
    {
        synchronized (readerLock) {
            if (evioReader == null) {
                setError(openError, out);
            } else {
                out.setData(evioReader.getFileByteOrder().toString(), MimeType.STRING);
                out.setStatus(CConstants.info);
                out.setDataDescription("byte order");
            }
        }
    }


    private void getEventCount(JioSerial out)
    {
        synchronized (readerLock) {
            if (evioReader == null) {
                setError(openError, out);
            } else {
                out.setData(eventCount);
                out.setStatus(CConstants.info);
                out.setDataDescription("event count");
            }
        }
    }


    private void setError(String msg, JioSerial out)
    {
        out.setDataDescription(msg);
        out.setStatus(CConstants.error);
    }


    @Override
    public JioSerial execute(JioSerial[] data)
    {
        return null;
    }


    @Override
    public void destruct()
    {
        synchronized (readerLock) {
            if (evioReader != null) {
                closeFile();
            }
        }
    }


    @Override
    public String getName()
    {
        return NAME;
    }


    @Override
    public String getAuthor()
    {
        return "Sebastian Mancilla <code>&lt;smancill@jlab.org&gt;</code>";
    }


    @Override
    public String getDescription()
    {
        return
                "Reads EVIO events from a file. " +
                        "Returns a new event on each request or an error if there was some problem.<br><br>" +
                        "<strong>Configuration:</strong>" +
                        "<ul>" +
                        "  <li><font \"color=navy\">type:</font> <code>text/property-list</code>" +
                        "  <li><font \"color=navy\">value:</font> the following properties are accepted:" +
                        "    <ul>" +
                        "      <li><code>\"" + CONF_ACTION + "\"</code>:" +
                        "        <code>\""+ CONF_ACTION_OPEN  + "\"</code> to open the input file, or"  +
                        "        <code>\""+ CONF_ACTION_CLOSE + "\"</code> to close it."  +
                        "      <li><code>\"" + CONF_FILENAME + "\"</code>:" +
                        "        <code>\"&lt;path_to_file&gt;\"</code>, the input file."  +
                        "      <li><code>\"" + CONF_REPORT_DONE + "\"</code>: (optional)" +
                        "        configure which service is going to report 'done' messages every" +
                        "        certain amount of read events."  +
                        "        Set <code>\"true\"</code> if this service will report 'done',"  +
                        "        or set a <code>\"&lt;service_canonical_name&gt;\"</code>" +
                        "        if the given service will report 'done',"  +
                        "        or set <code>\"false\"</code> to stop reporting."  +
                        "      <li><code>\"" + CONF_REPORT_DATA + "\"</code>: (optional)" +
                        "        configure which service is going to report 'data' messages every" +
                        "        certain amount of read events."  +
                        "        Set <code>\"true\"</code> if this service will report the output data,"  +
                        "        or set a <code>\"&lt;service_canonical_name&gt;\"</code>" +
                        "        if the given service will report its output data,"  +
                        "        or set <code>\"false\"</code> to stop reporting."  +
                        "      <li><code>\"" + CONF_REPORT_FREQUENCY + "\"</code>: " +
                        "        <code>\"&lt;number_of_events&gt;\"</code>, (optional)" +
                        "        the frequency of the events that will report 'done' or data," +
                        "        example: set it to 1000 to report every 1000 read events." +
                        "    </ul>" +
                        "</ul>" +
                        "<strong>Requests:</strong>" +
                        "<ul>" +
                        "  <li><font \"color=navy\">input type:</font> <code>text/string</code>" +
                        "  <li><font \"color=navy\">input value:</font> <code>\"" + REQUEST_NEXT + "\"</code>" +
                        "  <li><font \"color=navy\">request action:</font> " +
                        "    read the next sequential event from the input file." +
                        "  <li><font \"color=navy\">output type:</font> <code>binary/data-evio</code>" +
                        "  <li><font \"color=navy\">output value:</font> " +
                        "     the event that was read from the input file in EVIO 4.1 format." +
                        "</ul>" +
                        "<ul>" +
                        "  <li><font \"color=navy\">input type:</font> <code>text/string</code>" +
                        "  <li><font \"color=navy\">input value:</font> <code>\"" + REQUEST_ORDER + "\"</code>" +
                        "  <li><font \"color=navy\">request action:</font> " +
                        "    get the byte order of the input file." +
                        "  <li><font \"color=navy\">output type:</font> <code>text/string</code>" +
                        "  <li><font \"color=navy\">output value:</font> " +
                        "     the byte order of the evio data in the file." +
                        "</ul>" +
                        "<ul>" +
                        "  <li><font \"color=navy\">input type:</font> <code>text/property-list</code>" +
                        "  <li><font \"color=navy\">input value:</font> " +
                        "    <code>\"" + REQUEST_EVENT + "\"</code>: <code>\"&lt;event_number&gt;\"</code>," +
                        "    the desired event number" +
                        "  <li><font \"color=navy\">request action:</font> " +
                        "    read the specific event with the given number from the input file." +
                        "  <li><font \"color=navy\">output type:</font> <code>binary/data-evio</code>" +
                        "  <li><font \"color=navy\">output value:</font> " +
                        "     the event that was read from the input file in EVIO 4.1 format." +
                        "</ul>" +
                        "<strong>Errors:</strong>:" +
                        "<ul>" +
                        "  <li>If the service has not been configured to open an input file."  +
                        "  <li>If the service could not open the input file."  +
                        "  <li>If the mime-type of the input data was wrong."  +
                        "  <li>If the value of the input data was wrong."  +
                        "  <li>If the service could not read the next/specific event from the input file."  +
                        "</ul>" +
                        "";
    }


    @Override
    public String getVersion()
    {
        return "1.4";
    }


    @Override
    public String getLanguage()
    {
        return CConstants.LANG_JAVA;
    }
}
