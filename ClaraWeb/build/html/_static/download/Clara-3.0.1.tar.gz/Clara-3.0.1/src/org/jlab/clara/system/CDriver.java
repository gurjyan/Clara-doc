/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */
package org.jlab.clara.system;

import org.jlab.clara.container.CSContainerRegistration;
import org.jlab.clara.data.CShareDataRep;
import org.jlab.clara.data.JioSerial;
import org.jlab.coda.cMsg.*;
import org.jlab.clara.constants.CConstants;
import org.jlab.clara.constants.CSISConstants;
import org.jlab.clara.pubsub.CCallBackContainer;
import org.jlab.clara.pubsub.CTrParameter;
import org.jlab.clara.pubsub.CCallBack;
import org.jlab.clara.service.CServiceRegistration;
import org.jlab.clara.util.CUtil;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * This is a base class for both: service-container (system component) and
 * CLARA clients (service-engine and orchestrator).
 * This class is used to establish and store platform and/or dpe connection
 * object, pub-sub subscription objects and organize service communications
 * (both sync and a-sync).Includes set of methods for communicating with the
 * platform gateway service.
 *
 * Note: for this release CLARA gateway service is required to run
 * on the master dpe (platform).
 *
 * Note: we always use already active connection objects from the store
 * for communications. In case connection object is missing (i.e.
 * this is temporary connection, i.e. not a connection that was previously
 * established for subscription and/or monitoring purposes) we create a new
 * connection and close it after the use.
 *
 * @author gurjyan
 * @version 3.x
 */

public class CDriver extends CcMsgDrive {

    /** permanent pub-sub connection object (to platform and/or any dpe) storage */
    private ConcurrentHashMap<String, Object>
            _connections = new ConcurrentHashMap<String, Object>();

    /** pub-sub subscription object storage */
    private ConcurrentHashMap<String, CCallBackContainer>
            _callBacks = new ConcurrentHashMap<String, CCallBackContainer>();

    /** CLARA cloud distributed service-container registration information
     * local database. Original database is stored within the CLARA platform registrar
     * normative service. The service registration database is updated whenever
     * a service is deployed on a cloud.*/
    private List<CSContainerRegistration> _plRegInfo;

    /** anyone who wants to interact with the CLARA cloud must have a unique name.
     * this field stores the name of the CLARA client.*/
    private String clientName;

    // we need a thread to keep this object active
    //@todo I am not sure we need this. Test it and remove....
    private boolean isRunning = true;

    private int _syncReqTimeOut = 3000;


    /**
     * Constructor sets the name of this client
     */
    public CDriver(){
        clientName = CUtil.generateName();
    }

    /**
     * Constructor sets the name of this client
     *
     * @param name unique name of the client
     */
    public CDriver(String name){
        clientName = name;
    }

    /**
     * Returns the name of the client
     * @return
     */
    protected String getClientName(){
        return clientName;
    }

    /**
     * In case we are running within the local DPE run-time environment
     * and we are connected to the local DPE pub-sub server
     * tell the framework that I can receive data through shared memory
     *
     * @return  status of the operation
     */
    boolean registerSharedMem()
    {
        if (isLocalDpeConnected()) {
            CShareDataRep.addReceiver(clientName);
            return true;
        } else {
            return false;
        }
    }

    /**
     * Add a new DPE connection object to the permanent connections storage.
     *
     * @param host of the DPE
     * @param connection cMsg connection object
     */
    void addConnection(String host, Object connection){
        if(connection != null && isConnected(connection)) {
            _connections.put(host, connection);
        }
    }

    /**
     * Remove a DPE connection from the connections storage.
     * This will actually close the connection.
     *
     * @param host of the DPE
     * @throws CException
     */
    void removeConnection(String host) throws CException {
        Object connection = _connections.remove(host);
        if(connection!=null && isConnected(connection)){
            disconnect(connection);
        }
    }

    /**
     * Get the DPE connection object from the storage
     *
     * @param host of the DPE
     * @return cMsg connection object
     * @throws CException
     */
    Object getConnection(String host) throws CException {
        Object connection = _connections.get(host);
        if(connection==null || !isConnected(connection)){
            throw new CException("not connected to the DPE host = "+host);
        }
        return connection;
    }

    /**
     * Checks to see if the connection object is stored in the storage.
     *
     * @param host of the DPE
     * @return true/false
     */
    boolean isConnectionSaved(String host){
        return _connections.containsKey(host);
    }

    /**
     * Checks to see if a DPE is alive
     *
     * @param dh DPE host name
     * @param timeOut time out
     * @return true/false
     */
    protected boolean isDpeActive(String dh, int timeOut) throws CException {
        boolean stat;
        String dpHost = CUtil.getIPAddress(dh.trim());
        Object connection;
        boolean willDelete = false;

        // first get connection from the local map
        try {
            connection = getConnection(dpHost);
        } catch (CException e) {

            // create a new connection to the DPE.
            // flag it to remove afterwards.
            willDelete = true;
            connection = connect2Dpe(clientName,dpHost);
        }
        if(isConnected(connection)){

            // fill transport parameters
            CTrParameter p =new CTrParameter();
            p.setConnection(connection);
            p.setSubject(dpHost+ CSISConstants.DPE_NAME_SUFFIX_JAVA);
            p.setType(CSISConstants.DPEInfoRequestState);
            p.setTimeout(timeOut);

            cMsgMessage msb = syncSend(p);
            stat = (msb != null) && (msb.getText() != null);

            // remove connection if flag is set
            if(willDelete){
                disconnect(connection);
            }
        } else {
            throw new CException("connection failed to a DPE on the host = "+dpHost);
        }
        return stat;
    }

    /**
     * Requests removal of a DPE running on a given host.
     *
     * @param dh DPE host name
     * @return status of the operation
     */
    protected boolean removeDpe(String dh) throws CException {
        boolean stat;
        Object connection;
        String dpHost = CUtil.getIPAddress(dh.trim());
        // first get connection from the local map
        try {
            connection = getConnection(dpHost);
        } catch (CException e) {

            // create a new connection to the DPE.
            // flag it to remove afterwards.
            connection = connect2Dpe(clientName,dpHost);
        }
        if(isConnected(connection)){

            // fill transport parameters
            CTrParameter p =new CTrParameter();
            p.setConnection(connection);
            p.setSubject(dpHost+ CSISConstants.DPE_NAME_SUFFIX_JAVA);
            p.setType(CSISConstants.DPEControlExit);

            //send the message
            stat = send(p);

            // disconnect the connection
            disconnect(connection);
        } else {
            throw new CException("connection failed to a DPE on the host = "+dpHost);
        }
        return stat;
    }

    /**
     * Sets the reporting period of a service container.
     * Service containers is report periodically statistic information, including
     * load (i.e. number of requests per unit time).
     *
     * @param dh DPE host name
     * @param cn container name
     * @param interval load statistics interval
     * @return status
     */
    boolean setLoadStatInterval(String dh, String cn, int interval) throws CException {
        boolean stat;
        String dpHost = CUtil.getIPAddress(dh.trim());

        // service container canonical name is constructed as host/containerName
        String containerCanonicalName = dpHost+"/"+cn;
        Object connection;
        boolean willDelete = false;

        // first get connection from the local map
        try {
            connection = getConnection(dpHost);
        } catch (CException e) {

            // create a new connection to the DPE.
            // flag it to remove afterwards.
            willDelete = true;
            connection = connect2Dpe(clientName,dpHost);
        }
        if(isConnected(connection)){

            // fill transport parameters
            CTrParameter p =new CTrParameter();
            p.setConnection(connection);
            p.setSubject(containerCanonicalName);
            p.setType(CSISConstants.ServiceControlSetLoadStatInterval);
            p.setText(Integer.toString(interval));

            stat = send(p);

            // remove connection if flag is set
            if(willDelete){
                disconnect(connection);
            }
        } else {
            throw new CException("connection failed to a DPE on the host = "+dpHost);
        }
        return stat;
    }

    /**
     * Sets the reporting period of a service container through the
     * platform gateway service.
     *
     * @param ch DPE host name, where service container is running
     * @param cn service container name
     * @param interval reporting period
     * @return status of the operation (false for failure)
     * @throws CException
     */
    boolean setLoadStatIntervalGW(String ch,
                                  String cn,
                                  int interval) throws CException {
        boolean stat;
        Object connection;
        boolean willDelete = false;

        // dpHost is the platform host by default, since gateway service runs on the platform
        String dpHost = CUtil.getIPAddress(myConfig.getPlatformHost());

        ArrayList<cMsgPayloadItem> al = new ArrayList<cMsgPayloadItem>();
        try {
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_CONTAINER_LOAD_INTERVAL,interval));
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_CONTAINER_NAME,cn));
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_CONTAINER_HOST,ch));
        } catch (cMsgException e) {
            throw new CException(e.getMessage());
        }

        // first get connection from the local map
        try {
            connection = getConnection(dpHost);
        } catch (CException e) {

            // create a new connection to the DPE.
            // flag it to remove afterwards.
            willDelete = true;
            connection = connect2Dpe(clientName,dpHost);
        }
        if(isConnected(connection)){

            // fill transport parameters
            CTrParameter p =new CTrParameter();
            p.setConnection(connection);
            p.setSubject("Clara_Gateway");
            p.setType(CSISConstants.GatewayControlSetContainerLoadStatInterval);
            p.setPayloadItems(al);

            stat = send(p);

            // remove connection if flag is set
            if(willDelete){
                disconnect(connection);
            }
        } else {
            throw new CException("connection failed to a DPE on the host = "+dpHost);
        }
        return stat;
    }

    /**
     * Asks DPE administrative service to create a service container
     *
     * @param dh the host name of the DPE (data processing environment),
     * where the service container will be running.
     * @param cn service container name.
     * @param ct service container type (java or cpp) .
     * @return status of the operation
     */
    protected boolean createContainer(String dh, String cn, String ct) throws CException {
        boolean stat = false;
        String dpHost = CUtil.getIPAddress(dh.trim());
        Object connection;
        boolean willDelete = false;

        if(dpHost!=null && cn != null){

            // service container canonical name is constructed as host/containerName
            String containerCanonicalName = dpHost+"/"+cn.trim();

            String dpeName;
            if (ct.equals(CConstants.LANG_JAVA)) dpeName = dpHost + CSISConstants.DPE_NAME_SUFFIX_JAVA;
            else if (ct.equals(CConstants.LANG_CPP)) dpeName = dpHost + CSISConstants.DPE_NAME_SUFFIX_CPP;
            else return false;

            ArrayList<cMsgPayloadItem> al = new ArrayList<cMsgPayloadItem>();
            try {
                al.add(new cMsgPayloadItem(CSISConstants.SERVICE_CONTAINER_TYPE,ct));
            } catch (cMsgException e) {
                throw new CException(e.getMessage());
            }

            // first get connection from the local map
            try {
                connection = getConnection(dpHost);
            } catch (CException e) {

                // create a new connection to the DPE.
                // flag it to remove afterwards.
                willDelete = true;
                connection = connect2Dpe(clientName,dpHost);
            }
            if(isConnected(connection)){

                // fill transport parameters
                CTrParameter p =new CTrParameter();
                p.setConnection(connection);
                p.setSubject(dpeName);
                p.setType(CSISConstants.DPEControlStartServiceContainer);
                p.setPayloadItems(al);
                p.setText(containerCanonicalName);

                stat = send(p);

                // remove connection if flag is set
                if(willDelete){
                    disconnect(connection);
                }
            } else {
                throw new CException("connection failed to a DPE on the host = "+dpHost);
            }
        }
        return stat;
    }

    /**
     * Asks DPE administrative service to create a service container.
     * Synchronous request
     *
     * @param dh the host name of the DPE, where the service container will be running.
     * @param cn service container name.
     * @param ct service container type (java or cpp) .
     * @param timeout time out of the sync request.
     * @return true if succeeded
     */
    protected boolean syncCreateContainer(String dh, String cn, String ct, int timeout) throws CException {
        boolean stat = false;
        String dpHost = CUtil.getIPAddress(dh.trim());
        Object connection;
        boolean willDelete = false;

        if(dpHost!=null && cn != null){

            // service container canonical name is constructed as host/containerName
            String containerCanonicalName = dpHost+"/"+cn.trim();

            String dpeName;
            if (ct.equals(CConstants.LANG_JAVA)) dpeName = dpHost + CSISConstants.DPE_NAME_SUFFIX_JAVA;
            else if (ct.equals(CConstants.LANG_CPP)) dpeName = dpHost + CSISConstants.DPE_NAME_SUFFIX_CPP;
            else return false;

            ArrayList<cMsgPayloadItem> al = new ArrayList<cMsgPayloadItem>();
            try {
                al.add(new cMsgPayloadItem(CSISConstants.SERVICE_CONTAINER_TYPE,ct));
            } catch (cMsgException e) {
                throw new CException(e.getMessage());
            }

            // first get connection from the local map
            try {
                connection = getConnection(dpHost);
            } catch (CException e) {

                // create a new connection to the DPE.
                // flag it to remove afterwards.
                willDelete = true;
                connection = connect2Dpe(clientName,dpHost);
            }
            if(isConnected(connection)){

                // fill transport parameters
                CTrParameter p =new CTrParameter();
                p.setConnection(connection);
                p.setSubject(dpeName);
                p.setType(CSISConstants.DPEControlStartServiceContainer);
                p.setPayloadItems(al);
                p.setText(containerCanonicalName);
                p.setTimeout(timeout);

                //sync send the message
                cMsgMessage msb = syncSend(p);
                if(msb!=null && msb.getText()!=null){
                    String result = msb.getText();
                    if(result.equals("done") || result.contains("container exists")) {
                        stat = true;
                    } else {
                        throw new CException(result);
                    }
                }

                // remove connection if flag is set
                if(willDelete){
                    disconnect(connection);
                }
            } else {
                throw new CException("connection failed to a DPE on the host = "+dpHost);
            }
        }
        return stat;
    }

    /**
     * Create a service container using platform normative gateway service
     * @param dh Host of the DPE, where container will be running
     * @param cn container name
     * @param ct container type
     * @return status of the operation
     * @throws CException
     */
    protected boolean createContainerGW(String dh,
                                        String cn,
                                        String ct) throws CException {
        boolean stat;
        Object connection;
        boolean willDelete = false;

        // dpHost is the platform host by default, since gateway service runs on the platform
        String dpHost = CUtil.getIPAddress(myConfig.getPlatformHost());

        ArrayList<cMsgPayloadItem> al = new ArrayList<cMsgPayloadItem>();
        try {
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_CONTAINER_TYPE,ct));
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_CONTAINER_NAME,cn));
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_CONTAINER_HOST,dh));
        } catch (cMsgException e) {
            throw new CException(e.getMessage());
        }

        // first get connection from the local map
        try {
            connection = getConnection(dpHost);
        } catch (CException e) {

            // create a new connection to the DPE.
            // flag it to remove afterwards.
            willDelete = true;
            connection = connect2Dpe(clientName,dpHost);
        }
        if(isConnected(connection)){

            // fill transport parameters
            CTrParameter p =new CTrParameter();
            p.setConnection(connection);
            p.setSubject("Clara_Gateway");
            p.setType(CSISConstants.GatewayControlStartContainer);
            p.setPayloadItems(al);

            stat = send(p);

            // remove connection if flag is set
            if(willDelete){
                disconnect(connection);
            }
        } else {
            throw new CException("connection failed to a DPE on the host = "+dpHost);
        }
        return stat;
    }

    /**
     * Asks DPE administrative service to create a service container with
     * defining the size of the thread pool.
     *
     * @param dh the host name of the data processing environment,
     * where the service container will be running.
     * @param cn service container name.
     * @param ct service container type (java or cpp) .
     * @param tps size of the thread pool.
     * @return status of the operation
     */
     protected boolean createContainerWPool(String dh,
                                           String cn,
                                           String ct,
                                           int tps) throws CException{
        boolean stat = false;
        String dpHost = CUtil.getIPAddress(dh.trim());
        Object connection;
        boolean willDelete = false;

        if(dpHost!=null && cn != null){

            // service container canonical name is constructed as host/containerName
            String containerCanonicalName = dpHost+"/"+cn.trim();

            String dpeName;
            if (ct.equals(CConstants.LANG_JAVA)) dpeName = dpHost + CSISConstants.DPE_NAME_SUFFIX_JAVA;
            else if (ct.equals(CConstants.LANG_CPP)) dpeName = dpHost + CSISConstants.DPE_NAME_SUFFIX_CPP;
            else return false;

            ArrayList<cMsgPayloadItem> al = new ArrayList<cMsgPayloadItem>();
            try {
                al.add(new cMsgPayloadItem(CSISConstants.SERVICE_CONTAINER_TYPE,ct));
                al.add(new cMsgPayloadItem(CSISConstants.CONTAINER_POOL_SIZE,tps));
            } catch (cMsgException e) {
                throw new CException(e.getMessage());
            }

            // first get connection from the local map
            try {
                connection = getConnection(dpHost);
            } catch (CException e) {

                // create a new connection to the DPE.
                // flag it to remove afterwards.
                willDelete = true;
                connection = connect2Dpe(clientName,dpHost);
            }
            if(isConnected(connection)){

                // fill transport parameters
                CTrParameter p =new CTrParameter();
                p.setConnection(connection);
                p.setSubject(dpeName);
                p.setType(CSISConstants.DPEControlStartServiceContainer);
                p.setPayloadItems(al);
                p.setText(containerCanonicalName);

                stat = send(p);

                // remove connection if flag is set
                if(willDelete){
                    disconnect(connection);
                }
            } else {
                throw new CException("connection failed to a DPE on the host = "+dpHost);
            }
        }
        return stat;
    }

    /**
     * Creates a container with a specified thread pool size using
     * platform normative gateway service.
     *
     * @param dh DPE host name, where the container will be running
     * @param cn container name
     * @param ct container type
     * @param tps thread pool size
     * @return status of the operation
     * @throws CException
     */
    protected boolean createContainerWPoolGW(String dh,
                                             String cn,
                                             String ct,
                                             int tps) throws CException{
        boolean stat;
        Object connection;
        boolean willDelete = false;

        // dpHost is the platform host by default, since gateway service runs on the platform
        String dpHost = CUtil.getIPAddress(myConfig.getPlatformHost());

        ArrayList<cMsgPayloadItem> al = new ArrayList<cMsgPayloadItem>();
        try {
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_CONTAINER_TYPE,ct));
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_CONTAINER_NAME,cn));
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_CONTAINER_HOST,dh));
            al.add(new cMsgPayloadItem(CSISConstants.CONTAINER_POOL_SIZE,tps));
        } catch (cMsgException e) {
            throw new CException(e.getMessage());
        }

        // first get connection from the local map
        try {
            connection = getConnection(dpHost);
        } catch (CException e) {

            // create a new connection to the DPE.
            // flag it to remove afterwards.
            willDelete = true;
            connection = connect2Dpe(clientName,dpHost);
        }
        if(isConnected(connection)){

            // fill transport parameters
            CTrParameter p =new CTrParameter();
            p.setConnection(connection);
            p.setSubject("Clara_Gateway");
            p.setType(CSISConstants.GatewayControlStartContainer);
            p.setPayloadItems(al);

            stat = send(p);

            // remove connection if flag is set
            if(willDelete){
                disconnect(connection);
            }
        } else {
            throw new CException("connection failed to a DPE on the host = "+dpHost);
        }
        return stat;
    }

    /**
     * Sends a request to the platform and asks to report
     * all registered service containers registration data.
     * Note: be careful not to overuse this method since
     *       this might be a network expensive
     * @return list of SCSContainerRegistration objects
     */

    /**
     * Sends a request to the platform asking to report
     * service containers registration database.
     * This method also copies returned database into the local
     * container registration database
     * @see CDriver#_plRegInfo
     * Note: this is a sync request
     *
     * @param timeout of the sync request
     * @return list of {@link CSContainerRegistration} objects
     * @throws CException
     */
    protected List<CSContainerRegistration> requestRegistrationData(int timeout) throws CException{
        List<CSContainerRegistration> al = null;
        Object connection;
        String dpHost = myConfig.getPlatformHost();

        if(isPlatformConnected()){
            connection = getPlatformConnection();
        } else {
            try {
                connection = getConnection(dpHost);
            } catch (CException e) {

                // create a new connection to the platform DPE.
                connection = connect2Dpe(clientName,dpHost);
            }
        }
        if(isConnected(connection)){
            // fill transport parameters
            CTrParameter p =new CTrParameter();
            p.setConnection(connection);
            p.setSubject(myConfig.getPlatformName());
            p.setType(CSISConstants.DPEInfoRequestServiceContainers);
            p.setTimeout(timeout);

            //send the message
            cMsgMessage rMsg = syncSend(p);
            if(rMsg!=null && rMsg.getByteArray()!=null){

                try {
                    ConcurrentHashMap<String, CSContainerRegistration> scs =
                            (ConcurrentHashMap<String, CSContainerRegistration>)CUtil.B2O(rMsg.getByteArray());
                    al = new ArrayList<CSContainerRegistration>();
                    for(CSContainerRegistration s:scs.values()){
                        al.add(s);
                    }
                    _plRegInfo = al;
                } catch (IOException e) {
                    throw new CException(e.getMessage());
                } catch (ClassNotFoundException e) {
                    throw new CException(e.getMessage());
                }

            }
            if(!isConnectionSaved(dpHost)){
                disconnect(connection);
            }
        }
        return al;
    }

    /**
     * Asks DPE administrative service to remove the service container
     *
     * @param dh the host name of the data processing environment,
     * where the service container is running.
     * @param cn service container name.
     * @return status of the operation
     */
    boolean removeContainer(String dh,
                                      String cn) throws CException{
        boolean stat = false;
        String dpHost = CUtil.getIPAddress(dh.trim());
        Object connection;
        boolean willDelete = false;

        if(dpHost!=null && cn != null){

            // service container canonical name is constructed as host/containerName
            String containerCanonicalName = dpHost+"/"+cn;
            String dpeName;

            requestRegistrationData(_syncReqTimeOut);

            CSContainerRegistration registration = getContainer(containerCanonicalName);

            if (registration != null) {
                String type = registration.getType();
                if (type.equals(CSISConstants.CONTAINER_TYPE_JAVA)){
                    dpeName = dpHost + CSISConstants.DPE_NAME_SUFFIX_JAVA;
                } else if (type.equals(CSISConstants.CONTAINER_TYPE_CPP)) {
                    dpeName = dpHost + CSISConstants.DPE_NAME_SUFFIX_CPP;
                } else{
                    throw new CException("Unknown container type.");
                }

                // first get connection from the local map
                try {
                    connection = getConnection(dpHost);
                } catch (CException e) {

                    // create a new connection to the DPE.
                    // flag it to remove afterwards.
                    willDelete = true;
                    connection = connect2Dpe(clientName,dpHost);
                }
                if(isConnected(connection)){

                    // fill transport parameters
                    CTrParameter p =new CTrParameter();
                    p.setConnection(connection);
                    p.setSubject(dpeName);
                    p.setType(CSISConstants.DPEControlStopServiceContainer);
                    p.setText(containerCanonicalName);

                    stat = send(p);

                    // remove connection if flag is set
                    if(willDelete){
                        disconnect(connection);
                    }
                } else {
                    throw new CException("connection failed to a DPE on the host = "+dpHost);
                }
            } else {
                throw new CException("Null registration information");
            }
        }
        return stat;
    }

    /**
     * Removes the service container through the
     * platform normative gateway service
     *
     * @param dh DPE host where the required container is running
     * @param cn container name
     * @return status of the operation
     * @throws CException
     */
     boolean removeContainerGW(String dh,
                              String cn) throws CException{
        boolean stat = false;
        String dpHost = CUtil.getIPAddress(myConfig.getPlatformHost());
        Object connection;
        boolean willDelete = false;

        if(dpHost!=null && cn != null){

            // service container canonical name is constructed as host/containerName
            String containerCanonicalName = dpHost+"/"+cn;

            requestRegistrationData(_syncReqTimeOut);

            CSContainerRegistration registration = getContainer(containerCanonicalName);

            if (registration != null) {

                ArrayList<cMsgPayloadItem> al = new ArrayList<cMsgPayloadItem>();
                try {
                    al.add(new cMsgPayloadItem(CSISConstants.SERVICE_CONTAINER_NAME,cn));
                    al.add(new cMsgPayloadItem(CSISConstants.SERVICE_CONTAINER_HOST,dh));
                } catch (cMsgException e) {
                    throw new CException(e.getMessage());
                }

                // first get connection from the local map
                try {
                    connection = getConnection(dpHost);
                } catch (CException e) {

                    // create a new connection to the DPE.
                    // flag it to remove afterwards.
                    willDelete = true;
                    connection = connect2Dpe(clientName,dpHost);
                }
                if(isConnected(connection)){

                    // fill transport parameters
                    CTrParameter p =new CTrParameter();
                    p.setConnection(connection);
                    p.setSubject("Clara_Gateway");
                    p.setType(CSISConstants.GatewayControlStopContainer);
                    p.setPayloadItems(al);

                    stat = send(p);

                    // remove connection if flag is set
                    if(willDelete){
                        disconnect(connection);
                    }
                } else {
                    throw new CException("connection failed to a DPE on the host = "+dpHost);
                }
            } else {
                throw new CException("Null registration information");
            }
        }
        return stat;
    }

    /**
     * Sends a message to the service container to add a new service.
     *
     * @param dh the host name of the data processing environment,
     * where the service container is running.
     * @param cn service container name
     * @param se  full path to the required service engine class.
     * @return  status of the operation
     */
    protected boolean addService(String dh,
                       String cn,
                       String se) throws CException{
        Object connection;
        boolean willDelete = false;
        boolean stat = false;

        String dpHost = CUtil.getIPAddress(dh.trim());
        String containerName   = cn.trim();
        String containerCanonicalName = dpHost+"/"+containerName;
        String serviceEngineClassPath = se.trim().replaceAll("/",".");

        if(dpHost!=null && containerName != null) {
            ArrayList<cMsgPayloadItem> al = new ArrayList<cMsgPayloadItem>();
            try {
                al.add(new cMsgPayloadItem(CSISConstants.CLARA_DPE_HOST,dpHost));
                al.add(new cMsgPayloadItem(CSISConstants.SERVICE_CONTAINER_NAME,containerName));
                al.add(new cMsgPayloadItem(CSISConstants.SERVICE_ENGINE_CLASSPATH,serviceEngineClassPath));
            } catch (cMsgException e) {
                throw new CException(e.getMessage());
            }

            // first get connection from the local map
            try {
                connection = getConnection(dpHost);
            } catch (CException e) {

                // create a new connection to the DPE.
                // flag it to remove afterwards.
                willDelete = true;
                connection = connect2Dpe(clientName,dpHost);
            }
            if(isConnected(connection)){

                // fill transport parameters
                CTrParameter p =new CTrParameter();
                p.setConnection(connection);
                p.setType(CSISConstants.ServiceControlRequestAddService);
                p.setSubject(containerCanonicalName);
                p.setPayloadItems(al);

                stat = send(p);

                // remove connection if flag is set
                if(willDelete){
                    disconnect(connection);
                }
            } else {
                throw new CException("connection failed to a DPE on the host = "+dpHost);
            }
        }
        return stat;
    }

    /**
     * Adding a service to the service engine through the
     * platform normative gateway service.
     *
     * @param dh the host name of the data processing environment,
     * where the service container is running.
     * @param cn service container name
     * @param se  full path to the required service engine class.
     * @return  status of the operation
     */
    protected boolean addServiceGW(String dh,
                         String cn,
                         String se) throws CException {
        Object connection;
        String dpHost = CUtil.getIPAddress(myConfig.getPlatformHost());
        boolean willDelete = false;
        boolean stat = false;

        if(dpHost!=null && cn != null) {
            ArrayList<cMsgPayloadItem> al = new ArrayList<cMsgPayloadItem>();
            try {
                al.add(new cMsgPayloadItem(CSISConstants.SERVICE_CONTAINER_NAME,cn));
                al.add(new cMsgPayloadItem(CSISConstants.SERVICE_CONTAINER_HOST,dh));
                al.add(new cMsgPayloadItem(CSISConstants.SERVICE_ENGINE_CLASSPATH,se));
            } catch (cMsgException e) {
                throw new CException(e.getMessage());
            }

            // first get connection from the local map
            try {
                connection = getConnection(dpHost);
            } catch (CException e) {

                // create a new connection to the DPE.
                // flag it to remove afterwards.
                willDelete = true;
                connection = connect2Dpe(clientName,dpHost);
            }
            if(isConnected(connection)){

                // fill transport parameters
                CTrParameter p =new CTrParameter();
                p.setConnection(connection);
                p.setSubject("Clara_Gateway");
                p.setType(CSISConstants.GatewayControlStartService);
                p.setPayloadItems(al);

                stat = send(p);

                // remove connection if flag is set
                if(willDelete){
                    disconnect(connection);
                }
            } else {
                throw new CException("connection failed to a DPE on the host = "+dpHost);
            }
        }
        return stat;
    }

    /**
     * Remove the service from the container
     *
     * @param scn the canonical name of the service.
     *            Note: service canonical name  = dpe_host/container_name/engine_name
     * @return true for success
     */
    boolean removeService(String scn) throws CException{
        Object connection;
        boolean willDelete = false;
        boolean stat;

        // get the host name from the service from its canonical name
        String dpHost = CUtil.parse4DpeHostName(scn);

        // get the service container name from the service canonical name
        String container = CUtil.parse4ContainerCanonicalName(scn);

        // first get connection from the local map
        try {
            connection = getConnection(dpHost);
        } catch (CException e) {

            // create a new connection to the DPE.
            // flag it to remove afterwards.
            willDelete = true;
            connection = connect2Dpe(clientName,dpHost);
        }
        if(isConnected(connection)){

            // fill transport parameters
            CTrParameter p =new CTrParameter();
            p.setConnection(connection);
            p.setSubject(container);
            p.setType(CSISConstants.ServiceControlRequestRemoveService);
            p.setText(scn);

            stat = send(p);

            // remove connection if flag is set
            if(willDelete){
                disconnect(connection);
            }
        } else {
            throw new CException("connection failed to a DPE on the host = "+dpHost);
        }

        return stat;
    }

    /**
     * Remove the service from the container, using the platform
     * normative gateway service.
     *
     * @param scn the canonical name of the service.
     *            Note: service canonical name  = dpe_host/container_name/engine_name
     * @return true for success
     */
    boolean removeServiceGW(String scn) throws CException {
        Object connection;
        boolean willDelete = false;
        boolean stat;

        String dpHost = CUtil.getIPAddress(myConfig.getPlatformHost());

        ArrayList<cMsgPayloadItem> al = new ArrayList<cMsgPayloadItem>();
        try {
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_NAME,scn));
        } catch (cMsgException e) {
            throw new CException(e.getMessage());
        }

        // first get connection from the local map
        try {
            connection = getConnection(dpHost);
        } catch (CException e) {

            // create a new connection to the DPE.
            // flag it to remove afterwards.
            willDelete = true;
            connection = connect2Dpe(clientName,dpHost);
        }
        if(isConnected(connection)){

            // fill transport parameters
            CTrParameter p =new CTrParameter();
            p.setConnection(connection);
            p.setSubject("Clara_Gateway");
            p.setType(CSISConstants.GatewayControlStopService);
            p.setPayloadItems(al);

            stat = send(p);

            // remove connection if flag is set
            if(willDelete){
                disconnect(connection);
            }
        } else {
            throw new CException("connection failed to a DPE on the host = "+dpHost);
        }
        return stat;
    }

    /**
     * Gets the service container registration information from the
     * local database
     * @see CDriver#_plRegInfo
     *
     * @param containerCanonicalName, constructed as dpe_host/container_name
     * @return {@link CSContainerRegistration} object or null if service
     *         container is not registered
     */
    protected CSContainerRegistration getContainer(String containerCanonicalName){

        if(_plRegInfo!=null && !_plRegInfo.isEmpty()){
            for(CSContainerRegistration cr:_plRegInfo){
                if(cr.getName().equals(containerCanonicalName)){
                    return cr;
                }
            }
        }
        return null;
    }

    /**
     * Gets the service registration information from the
     * local database
     * @see CDriver#_plRegInfo
     *
     * @param serviceCanonicalName, constructed as dpe_host/container_name/engine_name
     * @return {@link CServiceRegistration} object or null if service
     *         is not registered
     */
    protected CServiceRegistration getServiceInformation(String serviceCanonicalName){
        if(_plRegInfo!=null && !_plRegInfo.isEmpty()){
            for(CSContainerRegistration cr:_plRegInfo){
                for(CServiceRegistration service:cr.getServices()){
                    if(service.getRegistrationName().equals(serviceCanonicalName)){
                        return service;
                    }
                }
            }
        }
        return null;
    }

    /**
     * Gets the service registration information for all service that
     * share the same description. The information is obtained from the
     * local database.
     * @see CDriver#_plRegInfo
     *
     * Note: the same service engine with the same engine-name, description,
     *       etc. can be deployed as a service in different service containers,
     *       on a same or different DPEs.
     *
     * @param description of the service engine
     *                    @see org.jlab.clara.system.ICService#getDescription()
     * @return list of {@link CServiceRegistration} objects or null if
     *         no service with the specified description was found.
     */
    protected List<CServiceRegistration> getServiceByDescription (String description){
        List<CServiceRegistration> al = new ArrayList<CServiceRegistration>();
        if(_plRegInfo!=null && !_plRegInfo.isEmpty()){
            for(CSContainerRegistration cr:_plRegInfo){

                for(CServiceRegistration service:cr.getServices()){
                    String desc = service.getDescription().toUpperCase();
                    String keyword = description.toUpperCase();
                    if(desc.contains(keyword)){
                        al.add(service);
                    }
                }
            }
        }
        return al;
    }

    /**
     * Gets the service registration information for all service that
     * share the same engine-name. The information is obtained from the
     * local database.
     * @see CDriver#_plRegInfo
     *
     * Note: the same service engine with the same engine-name, description,
     *       etc. can be deployed as a service in different service containers,
     *       on a same or different DPEs.
     *
     * @param eName the name of the service engine
     *                    @see org.jlab.clara.system.ICService#getName()
     * @return list of {@link CServiceRegistration} objects or null if
     *         no service with the specified service engine name was found.
     */
    protected List<CServiceRegistration> getServiceByEngineName (String eName){
        List<CServiceRegistration> al = new ArrayList<CServiceRegistration>();
        if(_plRegInfo!=null && !_plRegInfo.isEmpty()){
            for(CSContainerRegistration cr:_plRegInfo){
                for(CServiceRegistration service:cr.getServices()){
                    if(service.getRegistrationName().endsWith("/" + eName)){
                        al.add(service);
                    }
                }
            }
        }
        return al;
    }

    /**
     * Gets the service registration information for all service that
     * are running within the same service container.
     * Note: we can have same name containers on a different DPEs.
     *       Thus, the list will include cloud deployed services running on
     *       a same name container/containers on a different DPEs.
     * The information is obtained from the local database.
     * @see CDriver#_plRegInfo
     *
     * @param cName the name of the service container.
     *              Note: this is NOT a canonical name
     * @return list of {@link CServiceRegistration} objects or null if
     *         there are no services deployed in a specified container.
     */
    List<CServiceRegistration> getServiceByContainerName (String cName){
        List<CServiceRegistration> al = new ArrayList<CServiceRegistration>();
        if(_plRegInfo!=null && !_plRegInfo.isEmpty()){
            for(CSContainerRegistration cr:_plRegInfo){
                for(CServiceRegistration service:cr.getServices()){
                    if(service.getRegistrationName().contains("/" + cName + "/")){
                        al.add(service);
                    }
                }
            }
        }
        return al;
    }

    /**
     * Gets the service registration information for all service that
     * are running on the same DPE. Hence, these are all services running
     * on a multiple containers on a same DPE.
     * The information is obtained from the local database.
     * @see CDriver#_plRegInfo
     *
     * @param hName the host name of the DPE
     * @return list of {@link CServiceRegistration} objects or null if
     *         there are no services deployed on a DPE host.
     */
    List<CServiceRegistration> getServiceByHostName (String hName){
        String host = CUtil.getIPAddress(hName);
        List<CServiceRegistration> al = new ArrayList<CServiceRegistration>();
        if(_plRegInfo!=null && !_plRegInfo.isEmpty()){
            for(CSContainerRegistration cr:_plRegInfo){
                for(CServiceRegistration service:cr.getServices()){
                    if(service.getRegistrationName().startsWith(host + "/")){
                        al.add(service);
                    }
                }
            }
        }
        return al;
    }

    /**
     * Gets the list of service registration information for all service that
     * are running on a specified DPE and a specified container.
     * The information is obtained from the local database.
     * @see CDriver#_plRegInfo
     *
     * @param hName the host name of the DPE
     * @param cName the name of the container (Note: this is NOT the canonical name)
     * @return list of {@link CServiceRegistration} objects or null if
     *         there are no services deployed on a DPE host and on a container.
     */
    protected List<CServiceRegistration> getServiceByHostContainer (String hName, String cName){
        String host = CUtil.getIPAddress(hName);
        List<CServiceRegistration> al = new ArrayList<CServiceRegistration>();
        if(_plRegInfo!=null && !_plRegInfo.isEmpty()){
            for(CSContainerRegistration cr:_plRegInfo){
                for(CServiceRegistration service:cr.getServices()){
                    if((CUtil.parse4DpeHostName(service.getRegistrationName()).equals(host)) &&
                            (CUtil.parse4ContainerName(service.getRegistrationName()).equals(cName))) {
                        al.add(service);
                    }
                }
            }
        }
        return al;
    }

    /**
     * Get the service description
     *
     * @param scn service canonical name
     * @return String describing the service or null if not found
     *         @see org.jlab.clara.system.ICService#getDescription()
     */
    String getServiceDescription(String  scn){
        CServiceRegistration sr =  getServiceInformation(scn);
        if(sr!=null){
            return sr.getDescription();
        } else {
            return null;
        }
    }

    /**
     * Get the service version
     * @param scn service canonical name
     * @return version of the service or null if not found
     *         @see org.jlab.clara.system.ICService#getVersion()
     */
    String getServiceVersion(String  scn){
        CServiceRegistration sr =  getServiceInformation(scn);
        if(sr!=null){
            return sr.getVersion();
        } else {
            return null;
        }
    }

    /**
     * Get the service author
     * @param scn service canonical name
     * @return author of the service or null if not found
     *         @see org.jlab.clara.system.ICService#getAuthor()
     */
    String getServiceAuthor(String  scn){
        CServiceRegistration sr =  getServiceInformation(scn);
        if(sr!=null){
            return sr.getAuthor();
        } else {
            return null;
        }
    }

    /**
     * Get the service language
     * @param scn service canonical name
     * @return language of the service or null if not found
     *         @see org.jlab.clara.system.ICService#getLanguage()
     */
    String getServiceLanguage(String  scn){
        CServiceRegistration sr =  getServiceInformation(scn);
        if(sr!=null){
            return sr.getLanguage();
        } else {
            return null;
        }
    }

    /**
     * Returns the number of requests per unit of a time for a
     * specified service.
     * Note: this is an integral number for all requests of a
     * service container. So, in case there are multiple service engines
     * (i.e. services) are deployed within the same container the returned
     * number will be for integral number of requests for all services
     * within the container.
     *
     * @param scn canonical name of the service
     * @return number of requests per unit of a time or
     *         -1 in case container was not found
     */
   protected double getServiceLoad(String scn){
        CSContainerRegistration cr = getContainer(CUtil.parse4ContainerCanonicalName(scn));
        if(cr!=null){
            return cr.getLoad();
        } else {
            return -1.0;
        }
    }

    /**
     * Returns list of service container canonical
     * names deployed in the Clara cloud
     *
     * @return list of service container names
     */
    protected List<String> getContainerNames(){
        ArrayList<String> al = new ArrayList<String>();
        if(_plRegInfo!=null && !_plRegInfo.isEmpty()){
            for(CSContainerRegistration s:_plRegInfo){
                al.add(s.getName());
            }
        }
        return al;
    }

    /**
     * Returns list of service canonical names deployed in the
     * required container of the Clara cloud
     *
     * @param containerCanonicalName service container name
     * @return list of service canonical names
     */
    protected List<String> getServiceNames(String containerCanonicalName){
        ArrayList<String> al = new ArrayList<String>();
        if(_plRegInfo!=null && !_plRegInfo.isEmpty()){
            for(CSContainerRegistration cr:_plRegInfo){
                if(cr.getName().equals(containerCanonicalName)){
                    for(CServiceRegistration service:cr.getServices()){
                        al.add(service.getRegistrationName());
                    }
                }
            }
        }
        return al;
    }

    /**
     * Returns the reference to the local
     * platform registration database.
     *
     * @return List of {@link CSContainerRegistration}
     * @see CDriver#_plRegInfo
     */
    protected List<CSContainerRegistration> getContainers(){
        return _plRegInfo;
    }


    /**
     * Returns te list containing the names of
     * all registered and active DPE names
     *
     * @return List of DPE names
     */
    protected List<String> getDpeNames(int timeout) throws CException{
        List<String> dpes = null;
        boolean willDelete = false;
        Object connection;

        // gateway service runs by default on the platform
        String dpHost = myConfig.getPlatformHost();
        // first get connection from the local map
        try {
            connection = getConnection(dpHost);
        } catch (CException e) {

            // create a new connection to the DPE.
            // flag it to remove afterwards.
            willDelete = true;
            connection = connect2Dpe(clientName,dpHost);
        }
        if(isConnected(connection)){

            // fill transport parameters
            CTrParameter p =new CTrParameter();
            p.setConnection(connection);
            p.setSubject(myConfig.getPlatformName());
            p.setType(CSISConstants.PlatformInfoRequestRegisteredDPEs);
            p.setTimeout(timeout);

            cMsgMessage res = syncSend(p);
            if (res != null) {
                cMsgPayloadItem dpesPayload = res.getPayloadItem("dpes");
                if (dpesPayload != null) {
                    try {
                        dpes = Arrays.asList(dpesPayload.getStringArray());
                    } catch (cMsgException e) {
                        throw new CException(e.getMessage());
                    }
                }
            }

            // remove connection if flag is set
            if(willDelete){
                disconnect(connection);
            }
        } else {
            throw new CException("connection failed to a DPE on the host = "+dpHost);
        }
        return dpes;
    }

    /**
     * Checks if the container is up and running
     *
     * @param containerName canonical name of the container
     * @return  true if it is up and running.
     */
    protected boolean isContainerRunning(String containerName){
        boolean stat = false;
        if(_plRegInfo!=null && !_plRegInfo.isEmpty()){
            if(getContainerNames().contains(containerName)){
                stat = true;
            }
        }
        return stat;
    }

    /**
     * Checks if the service is up and running
     *
     * @param serviceCanonicalName canonical name of the service
     * @return  true if service is up and running
     */
    protected boolean isServiceDeployed(String serviceCanonicalName){
        boolean stat = false;
        if(_plRegInfo!=null && !_plRegInfo.isEmpty()){
            for(String containerName:getContainerNames()){
                if(getServiceNames(containerName).contains(serviceCanonicalName)){
                    stat = true;
                    break;
                }
            }
        }
        return stat;
    }


    /**
     * Subscribe to a subject and a type.
     * Since Clara is composed of multiple servers we need to define also on what
     * host (pub-sub server) the source of this message is located.
     * After successful subscription the callback and the connection objects will be
     * stored in the local maps.
     * @see CDriver#_callBacks
     * @see CDriver#_connections
     *
     * Note: we can have only 1 callback for the same subject and a type.
     *
     * @param cln the name of a client.
     *            Note: client can be a service. In this case cln will be
     *            a canonical name of a service
     * @param dh the host of the service, i.e. pub-sub server
     * @param sb subject of the subscription, i.e. to what subject this client is subscribing
     * @param st type of the subscription, i.e. type that this client will listen
     * @param callBack of the subscription
     */
    void addCallBack(String cln,
                     String dh,
                     String sb,
                     String st,
                     CCallBack callBack) throws CException{

        String dpHost = dh.trim();
        String subject = sb.trim();
        String type = st.trim();
        Object connection;
        cMsgSubscriptionHandle csh;

        // key name of the subscription
        String name = cln + "_" + dpHost + "_" + subject + "_" + type;

        // get connection object
        // first get connection from the local map
        try {
            connection = getConnection(dpHost);
        } catch (CException e) {

            // create a new connection to the DPE.
            connection = connect2Dpe(cln,dpHost);
        }
        if(isConnected(connection)){
            if(connection instanceof cMsg){

             cMsg con = (cMsg)connection;

            // see if the callback is recorded in the _callBack container
            if (_callBacks.containsKey(name)) {
                csh = _callBacks.get(name).getSubscriptionHandle();
                // un-subscribe if exist
                try {
                    con.unsubscribe(csh);
                } catch (cMsgException e) {
                    throw new CException(e.getMessage());
                }
            }

            // subscribe
            try {
                csh = con.subscribe(subject, type, callBack, null);

                System.out.println("Subscribed to host: " + dpHost + "  subject: " + subject + "  type: " + type);

                // create and store the new subscription container object
                CCallBackContainer cbc = new CCallBackContainer();
                cbc.setCallBack(callBack);
                cbc.setSubscriptionHandle(csh);
                cbc.setServiceHost(dpHost);
                cbc.setSubscribingServiceCanonicalName(cln);
                _callBacks.put(name, cbc);
            } catch (cMsgException e) {
                throw new CException(e.getMessage());
            }
            if(!isConnectionSaved(dpHost)) {
                // add the connection to the connections map
                addConnection(dpHost,con);
            }
            }
        }
    }

    /**
     * Removes the subscription.
     * Using the stored connection object the method will un-subscribe
     * the subject and the type, before removing the callback object
     * from the local map.
     *
     * @param dh the host of the service, i.e. pub-sub server
     * @param sb subject of the subscription
     * @param st type of the subscription
     */
    void removeCallBack(String dh, String sb, String st) throws CException {
        String dpHost = dh.trim();
        String subject = sb.trim();
        String type = st.trim();
        Object connection;
        cMsgSubscriptionHandle csh;

        // key name of the subscription
        String name = clientName + "_" + dpHost + "_" + subject + "_" + type;

        // see if the callback is recorded in the _callBack container
        if (_callBacks.containsKey(name)) {
            CCallBackContainer cbc = _callBacks.get(name);
            csh = cbc.getSubscriptionHandle();
            // un-subscribe if exist
            try {
                connection = getConnection(dpHost);
                if(connection!=null && isConnected(connection)) {
                    if(connection instanceof cMsg){
                        cMsg con = (cMsg)connection;
                        con.unsubscribe(csh);
                    }
                    System.out.println("Un-subscribed from host: " + dpHost +
                            "  subject: " + subject + "  type: " + type);
                }

                // gat the name of a service that is sending
                // messages (source of a subscription)
                String subscribedServiceName = cbc.getSubscribingServiceCanonicalName();

                // tell the service not to send data to this client anymore
                serviceMonitorOff(subscribedServiceName,
                        cbc.getSubscriptionHandle().getSubject(),
                        cbc.getSubscriptionHandle().getType());

                // if this subscription is the only one on that host (i.e. dpHost)
                // then close the connection
                if (!dpHost.equals(myConfig.getLocalDpeHost())) {

                    // the host is not the local DPE host that this client has default connection
                    // iterate over the _callBacks map and see if this is the only subscription
                    // for the required host
                    int count = 0;
                    for (CCallBackContainer uc : _callBacks.values()) {
                        if (uc.getServiceHost().equals(dpHost)) count++;
                    }
                    if (count <= 1) removeConnection(dpHost);
                }

            } catch (cMsgException e) {
                throw new CException(e.getMessage());
            } catch (CException ee){
                //connection is not recorded in the local _connections map
                System.out.println(ee.getMessage());
            }

            // remove callback from the map
            _callBacks.remove(name,cbc);
        }
    }

    /**
     * Removes all registered callbacks and
     * closes connections to the DPE servers
     * @see CDriver#removeCallBack(String, String, String)
     */
    void removeAllCallBacks() throws CException{
        for (CCallBackContainer cbc : _callBacks.values()) {
            removeCallBack(cbc.getServiceHost(),
                    cbc.getSubscriptionHandle().getSubject(),
                    cbc.getSubscriptionHandle().getType());
        }
        _callBacks.clear();
    }

    /**
     * Subscribes the message that is originated by a service running on
     * the master DPE (platform)
     *
     * @param subject of the subscribe message
     * @param type of the subscribe message
     * @param callback cMsg callback adapter object
     * @throws CException
     */
    protected void subscribePlatform(String subject,
                           String type,
                           CCallBack callback) throws CException {
        addCallBack(clientName, myConfig.getPlatformHost(), subject, type, callback);
    }

    /**
     * un-subscribes the message that is originated by a service running on
     * the master DPE (platform)
     *
     * @param subject of the subscribe message
     * @param type of the subscribe message
     * @throws CException
     */
    protected void unsubscribePlatform(String subject,
                             String type) throws CException {
        removeCallBack(myConfig.getPlatformHost(), subject, type);
    }

    /**
     * Subscribe messages from the service and tells the service where,
     * i.e. to what subject and type to send the data.
     * It is important to mention that the service that is the source of
     * an information does not have to worry about the physical location
     * of a requester. Requester is the one who makes a server connection.
     * This method will also start and register a callback defined by the
     * requester service.
     *
     * @param scn  canonical name of the requested service,
     *             i.e. host/container/engine
     * @param subject to which the requesting service will subscribe
     * @param type  to which the requesting service will subscribe
     * @param callback requesting service callback object
     * @return status of the operation
     */
    protected boolean serviceMonitorOn(String scn,
                                       String subject,
                                       String type,
                                       CCallBack callback) throws CException{
        boolean stat;
        boolean willDelete = false;
        Object connection;

        // get the host name from the service from its canonical name
        String dpHost = CUtil.parse4DpeHostName(scn);

        // get the service container name from the service canonical name
        String container = CUtil.parse4ContainerCanonicalName(scn);

        // first we add a new callback
        addCallBack(scn, dpHost, subject, type, callback);

        // If this is a report subscription, do not send a registration message
        // to the service container
        if (type.equals(CSISConstants.EXCEPTION_REPORT) ||
                type.equals(CSISConstants.WARNING_REPORT) ||
                type.equals(CSISConstants.DONE_REPORT) ||
                type.equals(CSISConstants.DATA_REPORT)) {
            stat = true;
        } else {

            // Register itself as a listener of the service in the remote service container
            // (this will tell container to send the result data of each execution to each listener)
            // first get connection from the local map
            try {
                connection = getConnection(dpHost);
            } catch (CException e) {

                // create a new connection to the DPE.
                // flag it to remove afterwards.
                willDelete = true;
                connection = connect2Dpe(clientName,dpHost);
            }
            if(isConnected(connection)){

                ArrayList<cMsgPayloadItem> al = new ArrayList<cMsgPayloadItem>();
                try {
                    al.add(new cMsgPayloadItem(CSISConstants.REQUESTER_NAME,clientName.trim()));
                    al.add(new cMsgPayloadItem(CSISConstants.REQUESTER_SUBJECT,subject));
                    al.add(new cMsgPayloadItem(CSISConstants.REQUESTER_TYPE,type));
                } catch (cMsgException e){
                    throw new CException(e.getMessage());
                }

                // fill transport parameters
                CTrParameter p =new CTrParameter();
                p.setConnection(connection);
                p.setSubject(container);
                p.setType(CSISConstants.ServiceControlRequestSubscribe);
                p.setText(scn);
                p.setPayloadItems(al);

                stat = send(p);

                // remove connection if flag is set
                if(willDelete){
                    disconnect(connection);
                }
            } else {
                throw new CException("connection failed to a DPE on the host = "+dpHost);
            }
        }
        return stat;
    }

    /**
     * Subscribe messages from the service and tells the service where,
     * i.e. to what subject and type to send the data.
     * It is important to mention that the service that is the source of
     * an information does not have to worry about the physical location
     * of a requester. Requester in this case makes a connection to the
     * platform and sends the subscription request to the platform
     * gateway service.
     * This method will also start and register a callback defined by the
     * requester service.
     *
     * @param scn  canonical name of the requested service,
     *             i.e. host/container/engine
     * @param subject to which the requesting service will subscribe
     * @param type  to which the requesting service will subscribe
     * @param callback requesting service callback object
     * @return status of the operation
     */
    protected boolean serviceMonitorOnGW(String scn,
                                         String subject,
                                         String type,
                                         CCallBack callback) throws CException{
        boolean stat;
        boolean willDelete = false;
        Object connection;
        // gateway service runs by default on the platform
        String dpHost = myConfig.getPlatformHost();


        // first we add a new callback
        addCallBack("Clara_Gateway", dpHost, subject, type, callback);

        // If this is a report subscription, do not send a registration message
        // to the service container
        if (type.equals(CSISConstants.EXCEPTION_REPORT) ||
                type.equals(CSISConstants.WARNING_REPORT) ||
                type.equals(CSISConstants.DONE_REPORT) ||
                type.equals(CSISConstants.DATA_REPORT)) {
            stat = true;
        } else {

            // Register itself as a listener of the service in the remote service container
            // (this will tell container to send the result data of each execution to each listener)
            // first get connection from the local map
            try {
                connection = getConnection(dpHost);
            } catch (CException e) {

                // create a new connection to the DPE.
                // flag it to remove afterwards.
                willDelete = true;
                connection = connect2Dpe(clientName,dpHost);
            }
            if(isConnected(connection)){

                ArrayList<cMsgPayloadItem> al = new ArrayList<cMsgPayloadItem>();
                try {
                    al.add(new cMsgPayloadItem(CSISConstants.REQUESTER_NAME,clientName.trim()));
                    al.add(new cMsgPayloadItem(CSISConstants.REQUESTER_SUBJECT,subject));
                    al.add(new cMsgPayloadItem(CSISConstants.REQUESTER_TYPE,type));
                } catch (cMsgException e){
                    throw new CException(e.getMessage());
                }

                // fill transport parameters
                CTrParameter p =new CTrParameter();
                p.setConnection(connection);
                p.setSubject("Clara_Gateway");
                p.setType(CSISConstants.GatewayControlServiceMonitorOn);
                p.setText(scn);
                p.setPayloadItems(al);

                stat = send(p);

                // remove connection if flag is set
                if(willDelete){
                    disconnect(connection);
                }
            } else {
                throw new CException("connection failed to a DPE on the host = "+dpHost);
            }
        }
        return stat;
    }

    /**
     * Tells the remote service ( canonical name = host/container/engine)
     * to stop sending data to the subject and a type. This will also remove
     * an active local callback for this subscription.
     *
     * @param scn  canonical name of the requested service, i.e. host/container/engine
     * @param subject to which this local client will subscribe
     * @param type  to which this local client will subscribe
     * @return status of the operation
     */
    protected boolean serviceMonitorOff(String scn,
                                        String subject,
                                        String type) throws CException{
        boolean stat;
        boolean willDelete = false;
        Object connection;

        // get the host name from the service from its canonical name
        String dpHost = CUtil.parse4DpeHostName(scn);

        // get the service container name from the service canonical name
        String container = CUtil.parse4ContainerCanonicalName(scn);

        // first get connection from the local map
        try {
            connection = getConnection(dpHost);
        } catch (CException e) {

            // create a new connection to the DPE.
            // flag it to remove afterwards.
            willDelete = true;
            connection = connect2Dpe(clientName,dpHost);
        }
        if(isConnected(connection)){

            ArrayList<cMsgPayloadItem> al = new ArrayList<cMsgPayloadItem>();
            try {
                al.add(new cMsgPayloadItem(CSISConstants.REQUESTER_NAME,clientName.trim()));
                al.add(new cMsgPayloadItem(CSISConstants.REQUESTER_SUBJECT,subject));
                al.add(new cMsgPayloadItem(CSISConstants.REQUESTER_TYPE,type));
            } catch (cMsgException e){
                throw new CException(e.getMessage());
            }

            // fill transport parameters
            CTrParameter p =new CTrParameter();
            p.setConnection(connection);
            p.setSubject(container);
            p.setType(CSISConstants.ServiceControlRequestUnSubscribe);
            p.setText(scn);
            p.setPayloadItems(al);

            stat = send(p);

            // remove connection if flag is set
            if(willDelete){
                disconnect(connection);
            }
        } else {
            throw new CException("connection failed to a DPE on the host = "+dpHost);
        }
        return stat;
    }

    /**
     * Tells the remote service (canonical name = host/container/engine)
     * to stop sending data to the subject and a type. This will also remove
     * an active local callback for this subscription.
     * The request is sent to the platform gateway service, that will forward
     * it to the service in question.
     *
     * @param scn  canonical name of the requested service, i.e. host/container/engine
     * @param subject to which this local client will subscribe
     * @param type  to which this local client will subscribe
     * @return status of the operation
     */
    protected boolean serviceMonitorOffGW(String scn,
                                          String subject,
                                          String type) throws CException{
        boolean stat;
        boolean willDelete = false;
        Object connection;

        // gateway service runs by default on the platform
        String dpHost = myConfig.getPlatformHost();

        // first get connection from the local map
        try {
            connection = getConnection(dpHost);
        } catch (CException e) {

            // create a new connection to the DPE.
            // flag it to remove afterwards.
            willDelete = true;
            connection = connect2Dpe(clientName,dpHost);
        }
        if(isConnected(connection)){

            ArrayList<cMsgPayloadItem> al = new ArrayList<cMsgPayloadItem>();
            try {
                al.add(new cMsgPayloadItem(CSISConstants.REQUESTER_NAME,clientName.trim()));
                al.add(new cMsgPayloadItem(CSISConstants.REQUESTER_SUBJECT,subject));
                al.add(new cMsgPayloadItem(CSISConstants.REQUESTER_TYPE,type));
            } catch (cMsgException e){
                throw new CException(e.getMessage());
            }

            // fill transport parameters
            CTrParameter p =new CTrParameter();
            p.setConnection(connection);
            p.setSubject("Clara_Gateway");
            p.setType(CSISConstants.GatewayControlServiceMonitorOff);
            p.setText(scn);
            p.setPayloadItems(al);

            stat = send(p);

            // remove connection if flag is set
            if(willDelete){
                disconnect(connection);
            }
        } else {
            throw new CException("connection failed to a DPE on the host = "+dpHost);
        }
        return stat;
    }

    /**
     * Configures a service. Service can be on a remote node.
     *
     * @param scn canonical name of the service
     * @param data configuration data {@link JioSerial}
     * @return status of the operation
     */
    protected boolean configureService(String scn,
                                       JioSerial data) throws CException{
        boolean stat;
        boolean willDelete = false;
        Object connection;

        // get the host of the service
        String dpHost = CUtil.parse4DpeHostName(scn);

        // get the service container name
        String container = CUtil.parse4ContainerCanonicalName(scn);

        // see if we have a connection to that host pub-sub server
        // if not create one. Remember: if it is new created we have to close
        // it after this use. We will not close already existing connection since
        // it might be a subscription/ monitoring connection.
        // first get connection from the local map
        try {
            connection = getConnection(dpHost);
        } catch (CException e) {

            // create a new connection to the DPE.
            // flag it to remove afterwards.
            willDelete = true;
            connection = connect2Dpe(clientName,dpHost);
        }
        if(isConnected(connection)){

            // prepare and send the configuration message
            ArrayList<cMsgPayloadItem> al = new ArrayList<cMsgPayloadItem>();
            cMsgMessage msg = data.packEnvelope(al, new cMsgMessage());


            // fill transport parameters
            CTrParameter p =new CTrParameter();
            p.setConnection(connection);
            p.setMessage(msg);
            p.setText(scn);
            p.setSubject(container);
            p.setType(CSISConstants.ServiceControlRequestConfigure);
            p.setEndian(cMsgConstants.endianBig);

            stat = send(p);

            // remove connection if flag is set
            if(willDelete){
                disconnect(connection);
            }
        } else {
            throw new CException("connection failed to a DPE on the host = "+dpHost);
        }
        return stat;
    }

    /**
     * Configures a service.
     * Request is done through platform gateway service.
     *
     * @param scn canonical name of the service
     * @param data configuration data {@link JioSerial}
     * @return status of the operation
     */
    protected boolean configureServiceGW(String scn,
                                         JioSerial data) throws CException{
        boolean stat;
        boolean willDelete = false;
        Object connection;

        // gateway service runs by default on the platform
        String dpHost = myConfig.getPlatformHost();

        // first get connection from the local map
        try {
            connection = getConnection(dpHost);
        } catch (CException e) {

            // create a new connection to the DPE.
            // flag it to remove afterwards.
            willDelete = true;
            connection = connect2Dpe(clientName,dpHost);
        }
        if(isConnected(connection)){

            // prepare and send the configuration message
            ArrayList<cMsgPayloadItem> al = new ArrayList<cMsgPayloadItem>();
            cMsgMessage msg = data.packEnvelope(al, new cMsgMessage());

            // fill transport parameters
            CTrParameter p =new CTrParameter();
            p.setConnection(connection);
            p.setMessage(msg);
            p.setText(scn);
            p.setSubject("Clara_Gateway");
            p.setType(CSISConstants.GatewayControlConfigureService);

            stat = send(p);

            // remove connection if flag is set
            if(willDelete){
                disconnect(connection);
            }
        } else {
            throw new CException("connection failed to a DPE on the host = "+dpHost);
        }
        return stat;
    }

    /**
     * Sync request to a service container to report a service links.
     *
     * @param scn canonical name of the service
     * @param timeout of the sync request
     * @return a list with the names of linked services
     */
    protected List<String> getLinks(String scn, int timeout) throws CException{
        boolean willDelete = false;
        Object connection;
        List<String> o;

        // get the host of the service
        String dpHost = CUtil.parse4DpeHostName(scn);

        // get the service container name
        String container = CUtil.parse4ContainerCanonicalName(scn);

        // first get connection from the local map
        try {
            connection = getConnection(dpHost);
        } catch (CException e) {

            // create a new connection to the DPE.
            // flag it to remove afterwards.
            willDelete = true;
            connection = connect2Dpe(clientName,dpHost);
        }
        if(isConnected(connection)){

            // fill transport parameters
            CTrParameter p =new CTrParameter();
            p.setConnection(connection);
            p.setSubject(container);
            p.setType(CSISConstants.ServiceControlReportLinks);
            p.setText(scn);
            p.setTimeout(timeout);

            cMsgMessage msb = syncSend(p);
            if (msb != null) {
                if (msb.getPayloadItem("service-links") != null) {
                    try {
                        String[] links = msb.getPayloadItem("service-links").getStringArray();
                        o = Arrays.asList(links);
                    } catch (cMsgException e) {
                        throw new CException(e.getMessage());
                    }
                } else {
                    throw new CException("service-links payload is missing");
                }
            } else {
                throw new CException("null returned message");
            }

            // remove connection if flag is set
            if(willDelete){
                disconnect(connection);
            }
        } else {
            throw new CException("connection failed to a DPE on the host = "+dpHost);
        }
        return o;
    }

    /**
     * Links the output of the service_1 to the input of the service_2
     * i.e. tell the service_1 to send it's output data to the service_2
     *
     * @param service_1 canonical name of the service_1
     * @param service_2 canonical name of the service_2
     * @return false if failed
     */
    protected boolean chainServices(String service_1,
                          String service_2) throws CException{
        boolean stat;
        boolean willDelete = false;
        Object connection;

        String dpHost      = CUtil.parse4DpeHostName(service_1);
        String container_1 = CUtil.parse4ContainerCanonicalName(service_1);
        String container_2 = CUtil.parse4ContainerCanonicalName(service_2);
        ArrayList<cMsgPayloadItem> al = new ArrayList<cMsgPayloadItem>();
        try {
            al.add(new cMsgPayloadItem(CSISConstants.LOCAL_SERVICE,service_1));
            al.add(new cMsgPayloadItem(CSISConstants.REMOTE_CONTAINER,container_2));
            al.add(new cMsgPayloadItem(CSISConstants.REMOTE_SERVICE,service_2));
        } catch (cMsgException e1) {
            throw new CException(e1.getMessage());
        }

        // first get connection from the local map
        try {
            connection = getConnection(dpHost);
        } catch (CException e) {

            // create a new connection to the DPE.
            // flag it to remove afterwards.
            willDelete = true;
            connection = connect2Dpe(clientName,dpHost);
        }
        if(isConnected(connection)){

            // fill transport parameters
            CTrParameter p =new CTrParameter();
            p.setConnection(connection);
            p.setSubject(container_1);
            p.setType(CSISConstants.ServiceControlRequestLink);
            p.setText(service_1);
            p.setPayloadItems(al);

            stat = send(p);

            // remove connection if flag is set
            if(willDelete){
                disconnect(connection);
            }
        } else {
            throw new CException("connection failed to a DPE on the host = "+dpHost);
        }
        return stat;
    }

    /**
     * Links the output of the service_1 to the input of the service_2
     * i.e. tell the service_1 to send it's output data to the service_2
     * The request is sent to the platform gateway service that will
     * play a mediator role.
     *
     * @param service_1 canonical name of the service_1
     * @param service_2 canonical name of the service_2
     * @return false if failed
     */
    protected boolean chainServicesGW(String service_1,
                            String service_2) throws CException{
        boolean stat;
        boolean willDelete = false;
        Object connection;

        // gateway service runs by default on the platform
        String dpHost = myConfig.getPlatformHost();

        // first get connection from the local map
        try {
            connection = getConnection(dpHost);
        } catch (CException e) {

            // create a new connection to the DPE.
            // flag it to remove afterwards.
            willDelete = true;
            connection = connect2Dpe(clientName,dpHost);
        }
        if(isConnected(connection)){

            ArrayList<cMsgPayloadItem> al = new ArrayList<cMsgPayloadItem>();
            try {
                al.add(new cMsgPayloadItem(CSISConstants.SERVICE_NAME1,service_1));
                al.add(new cMsgPayloadItem(CSISConstants.SERVICE_NAME2,service_2));
            } catch (cMsgException e){
                throw new CException(e.getMessage());
            }

            // fill transport parameters
            CTrParameter p =new CTrParameter();
            p.setConnection(connection);
            p.setSubject("Clara_Gateway");
            p.setType(CSISConstants.GatewayControlLinkServices);
            p.setPayloadItems(al);

            stat = send(p);

            // remove connection if flag is set
            if(willDelete){
                disconnect(connection);
            }
        } else {
            throw new CException("connection failed to a DPE on the host = "+dpHost);
        }
        return stat;
    }

    /**
     * Removes the link between the output of the service_1 to the
     * input of the service_2, i.e. tell the service_1 to stop sending
     * it's output data to the service_2
     *
     * @param service_1 canonical name of the service_1
     * @param service_2 canonical name of the service_2
     * @return false if failed
     */
    protected boolean unChainServices(String service_1,
                            String service_2) throws CException{
        boolean stat;
        boolean willDelete = false;
        Object connection;

        String dpHost      = CUtil.parse4DpeHostName(service_1);
        String container_1 = CUtil.parse4ContainerCanonicalName(service_1);
        String container_2 = CUtil.parse4ContainerCanonicalName(service_2);
        ArrayList<cMsgPayloadItem> al = new ArrayList<cMsgPayloadItem>();
        try {
            al.add(new cMsgPayloadItem(CSISConstants.LOCAL_SERVICE,service_1));
            al.add(new cMsgPayloadItem(CSISConstants.REMOTE_CONTAINER,container_2));
            al.add(new cMsgPayloadItem(CSISConstants.REMOTE_SERVICE,service_2));
        } catch (cMsgException e1) {
            throw new CException(e1.getMessage());
        }

        // first get connection from the local map
        try {
            connection = getConnection(dpHost);
        } catch (CException e) {

            // create a new connection to the DPE.
            // flag it to remove afterwards.
            willDelete = true;
            connection = connect2Dpe(clientName,dpHost);
        }
        if(isConnected(connection)){

            // fill transport parameters
            CTrParameter p =new CTrParameter();
            p.setConnection(connection);
            p.setSubject(container_1);
            p.setType(CSISConstants.ServiceControlRequestUnLink);
            p.setText(service_1);
            p.setPayloadItems(al);

            stat = send(p);

            // remove connection if flag is set
            if(willDelete){
                disconnect(connection);
            }
        } else {
            throw new CException("connection failed to a DPE on the host = "+dpHost);
        }
        return stat;
    }

    /**
     * Removes the link between the output of the service_1 to the
     * input of the service_2, i.e. tell the service_1 to stop sending
     * it's output data to the service_2.
     * Request is sent to the platform gateway service.
     *
     * @param service_1 canonical name of the service_1
     * @param service_2 canonical name of the service_2
     * @return false if failed
     */
    protected boolean unChainServicesGW(String service_1,
                              String service_2) throws CException{
        boolean stat;
        boolean willDelete = false;
        Object connection;

        // gateway service runs by default on the platform
        String dpHost = myConfig.getPlatformHost();

        // first get connection from the local map
        try {
            connection = getConnection(dpHost);
        } catch (CException e) {

            // create a new connection to the DPE.
            // flag it to remove afterwards.
            willDelete = true;
            connection = connect2Dpe(clientName,dpHost);
        }
        if(isConnected(connection)){

            ArrayList<cMsgPayloadItem> al = new ArrayList<cMsgPayloadItem>();
            try {
                al.add(new cMsgPayloadItem(CSISConstants.SERVICE_NAME1,service_1));
                al.add(new cMsgPayloadItem(CSISConstants.SERVICE_NAME2,service_2));
            } catch (cMsgException e){
                throw new CException(e.getMessage());
            }

            // fill transport parameters
            CTrParameter p =new CTrParameter();
            p.setConnection(connection);
            p.setSubject("Clara_Gateway");
            p.setType(CSISConstants.GatewayControlUnLinkServices);
            p.setPayloadItems(al);

            stat = send(p);

            // remove connection if flag is set
            if(willDelete){
                disconnect(connection);
            }
        } else {
            throw new CException("connection failed to a DPE on the host = "+dpHost);
        }
        return stat;
    }

    /**
     * Requests service execution of a given service by sending the
     * CLARA transient data object to a service. This will trigger
     * service engine execution, followed by the transfer of the
     * service output data to linked services. In this case the
     * requester will not be notified.
     *
     * @param serviceCanonicalName requested service canonical name
     * @param data  CLARA transient data object {@link JioSerial}
     * @param requestId id of a request that is used for tagging
     *                  requests for synchronization purposes.
     * @return status of the operation
     * @throws CException
     */
    protected boolean runService(String serviceCanonicalName,
                                 JioSerial data,
                                 int requestId) throws CException{
        boolean stat;
        boolean willDelete = false;
        Object connection;

        // add request id to the data
        data.setRequestID(requestId);

        ArrayList<cMsgPayloadItem> al = new ArrayList<cMsgPayloadItem>();

        // get the host of the service
        String dpHost = CUtil.parse4DpeHostName(serviceCanonicalName);

        // get the service container name
        String container = CUtil.parse4ContainerCanonicalName(serviceCanonicalName);

        // add request ID and the requester name to the payload
        try {
            // tell the service who is requesting the service
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_NAME,clientName));
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_REQUEST_ID,requestId));
        } catch (Exception e) {
            throw new CException(e.getMessage());
        }

        // first get connection from the local map
        try {
            connection = getConnection(dpHost);
        } catch (CException e) {

            // create a new connection to the DPE.
            // flag it to remove afterwards.
            willDelete = true;
            connection = connect2Dpe(clientName,dpHost);
        }
        if(isConnected(connection)){

            // fill transport parameters
            CTrParameter p =new CTrParameter();
            p.setConnection(connection);
            p.setSubject(container);
            p.setText(serviceCanonicalName);
            if (CShareDataRep.isInJvm(serviceCanonicalName)) {
                // data through the shared memory
                CShareDataRep.putInputData(serviceCanonicalName, clientName, requestId, data);
                p.setType(CSISConstants.ServiceControlRequestStartServiceFSHM);
                p.setPayloadItems(al);
            } else {

                // data through a message
                // create a message from a JioSerial data object
                cMsgMessage msg = data.packEnvelope(al, new cMsgMessage());
                p.setMessage(msg);
                p.setType(CSISConstants.ServiceControlRequestStartService);
                p.setEndian(cMsgConstants.endianBig);
            }

            stat = send(p);

            // remove connection if flag is set
            if(willDelete){
                disconnect(connection);
            }
        } else {
            throw new CException("connection failed to a DPE on the host = "+dpHost);
        }
        return stat;
    }

    /**
     * Requests service execution of a given service by sending the
     * CLARA transient data object to a service. This will trigger
     * service engine execution, followed by the transfer of the
     * service output data to linked services. In this case the
     * requester will not be notified.
     * Request is done using gateway platform normative agent.
     *
     * @param serviceCanonicalName requested service canonical name
     * @param data  CLARA transient data object {@link JioSerial}
     * @param requestId id of a request that is used for tagging
     *                  requests for synchronization purposes.
     * @return status of the operation
     * @throws CException
     */
    protected boolean runServiceGW(String serviceCanonicalName,
                                   JioSerial data,
                                   int requestId) throws CException{
        boolean stat;
        boolean willDelete = false;
        Object connection;

        // gateway service runs by default on the platform
        String dpHost = myConfig.getPlatformHost();

        // first get connection from the local map
        try {
            connection = getConnection(dpHost);
        } catch (CException e) {

            // create a new connection to the DPE.
            // flag it to remove afterwards.
            willDelete = true;
            connection = connect2Dpe(clientName,dpHost);
        }
        if(isConnected(connection)){

            // add request id to the data
            data.setRequestID(requestId);

            ArrayList<cMsgPayloadItem> al = new ArrayList<cMsgPayloadItem>();
            // add request ID and the requester name to the payload
            try {
                // tell the service who is requesting the service
                al.add(new cMsgPayloadItem(CSISConstants.SERVICE_NAME,clientName));
                al.add(new cMsgPayloadItem(CSISConstants.SERVICE_REQUEST_ID,requestId));
            } catch (Exception e) {
                throw new CException(e.getMessage());
            }

            cMsgMessage msg = data.packEnvelope(al, new cMsgMessage());

            // fill transport parameters
            CTrParameter p =new CTrParameter();
            p.setConnection(connection);
            p.setMessage(msg);
            p.setText(serviceCanonicalName);
            p.setSubject("Clara_Gateway");
            p.setType(CSISConstants.GatewayControlRequestService);

            stat = send(p);

            // remove connection if flag is set
            if(willDelete){
                disconnect(connection);
            }
        } else {
            throw new CException("connection failed to a DPE on the host = "+dpHost);
        }
        return stat;
    }

    /**
     * Requests service execution of a given service by sending the
     * CLARA transient data object to a service. This will trigger
     * service engine execution. The output data of a service will
     * sent to the requester (i.e. to a CLARA client extending this
     * class).
     *
     * @param serviceCanonicalName Requesting service name,
     *                             constructed as:
     *                             hostName/containerName/engineName
     * @param data input data. see {@link JioSerial}
     * @param requestId service request ID for synchronization
     * @param timeout timeout of the sync request
     * @return output data. see {@link JioSerial}
     */
    protected JioSerial syncRunService(String serviceCanonicalName,
                                       JioSerial data,
                                       int requestId,
                                       int timeout) throws CException{
        JioSerial outData = null;
        boolean willDelete = false;
        Object connection;

        // add request id to the data
        data.setRequestID(requestId);

        ArrayList<cMsgPayloadItem> al = new ArrayList<cMsgPayloadItem>();

        // get the host of the service
        String dpHost = CUtil.parse4DpeHostName(serviceCanonicalName);

        // get the service container name
        String container = CUtil.parse4ContainerCanonicalName(serviceCanonicalName);

        // add request ID and the requester name to the payload
        try {
            // tell the service who is requesting the service
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_NAME,clientName));
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_REQUEST_ID,requestId));
        } catch (Exception e) {
            throw new CException(e.getMessage());
        }

        // first get connection from the local map
        try {
            connection = getConnection(dpHost);
        } catch (CException e) {

            // create a new connection to the DPE.
            // flag it to remove afterwards.
            willDelete = true;
            connection = connect2Dpe(clientName,dpHost);
        }
        if(isConnected(connection)){

            // fill transport parameters
            CTrParameter p =new CTrParameter();
            p.setConnection(connection);
            p.setSubject(container);
            p.setText(serviceCanonicalName);
            if (CShareDataRep.isInJvm(serviceCanonicalName)) {
                // data through the shared memory
                CShareDataRep.putInputData(serviceCanonicalName, clientName, requestId, data);
                p.setType(CSISConstants.ServiceControlRequestStartServiceFSHM);
                p.setPayloadItems(al);
            } else {

                // data through a message
                // create a message from a JioSerial data object
                cMsgMessage msg = data.packEnvelope(al, new cMsgMessage());
                p.setMessage(msg);
                p.setType(CSISConstants.ServiceControlRequestStartService);
                p.setEndian(cMsgConstants.endianBig);
                p.setTimeout(timeout);
            }

            cMsgMessage res = syncSend(p);
            if (res != null) {
                String text = res.getText();
                if (text != null && text.equals(CSISConstants.DATA_IN_SHARED_MEMORY)) {
                    outData = CShareDataRep.getInputData(clientName, serviceCanonicalName, requestId);
                } else {
                    outData = new JioSerial(res);
                }
            }

            // remove connection if flag is set
            if(willDelete){
                disconnect(connection);
            }
        } else {
            throw new CException("connection failed to a DPE on the host = "+dpHost);
        }

        return outData;
    }

    /**
     * Requests service execution of a given service by sending the
     * CLARA transient data object to a service, using platform gateway
     * service. This will trigger service engine execution. The output
     * data of a service will sent to the requester (i.e. to a CLARA
     * client extending this class) through the platform gateway service.
     *
     * @param serviceCanonicalName Requesting service name,
     *                             constructed as:
     *                             hostName/containerName/engineName
     * @param data input data. see {@link JioSerial}
     * @param requestId service request ID for synchronization
     * @param timeout timeout of the sync request
     * @return output data. see {@link JioSerial}
     */
    protected JioSerial syncRunServiceGW(String serviceCanonicalName,
                                         JioSerial data,
                                         int requestId,
                                         int timeout) throws CException{
        JioSerial outData = null;
        boolean willDelete = false;
        Object connection;

        // gateway service runs by default on the platform
        String dpHost = myConfig.getPlatformHost();

        // first get connection from the local map
        try {
            connection = getConnection(dpHost);
        } catch (CException e) {

            // create a new connection to the DPE.
            // flag it to remove afterwards.
            willDelete = true;
            connection = connect2Dpe(clientName,dpHost);
        }
        if(isConnected(connection)){

            // add request id to the data
            data.setRequestID(requestId);

            ArrayList<cMsgPayloadItem> al = new ArrayList<cMsgPayloadItem>();
            // add request ID and the requester name to the payload
            try {
                // tell the service who is requesting the service
                al.add(new cMsgPayloadItem(CSISConstants.SERVICE_NAME,clientName));
                al.add(new cMsgPayloadItem(CSISConstants.SERVICE_REQUEST_ID,requestId));
                al.add(new cMsgPayloadItem(CSISConstants.SERVICE_REQUEST_TIMEOUT,timeout));
            } catch (Exception e) {
                throw new CException(e.getMessage());
            }

            cMsgMessage msg = data.packEnvelope(al, new cMsgMessage());

            // fill transport parameters
            CTrParameter p =new CTrParameter();
            p.setMessage(msg);
            p.setText(serviceCanonicalName);
            p.setSubject("Clara_Gateway");
            p.setType(CSISConstants.GatewayControlSyncRequestService);
            p.setTimeout(timeout);

            cMsgMessage res = syncSend(p);
            if (res != null) {
                outData = new JioSerial(res);
            }

            // remove connection if flag is set
            if(willDelete){
                disconnect(connection);
            }
        } else {
            throw new CException("connection failed to a DPE on the host = "+dpHost);
        }
        return outData;
    }

    /**
     * Sends a request to a service, that will trigger
     * a service engine getVersion() method execution.
     * @see org.jlab.clara.system.ICService#getVersion()
     *
     * @param serviceCanonicalName Requesting service name,
     *                             constructed as:
     *                             hostName/containerName/engineName
     * @param timeout timeout of the sync request
     * @return the output string of the getVersion() method of the engine, or in case
     * of a failure string = "failed"
     */
    String syncPingService(String requester,
                           String serviceCanonicalName,
                           int timeout) throws CException{

        String version;
        boolean willDelete = false;
        Object connection;

        // get the host of the service
        String dpHost = CUtil.parse4DpeHostName(serviceCanonicalName);

        // get the service container name
        String container = CUtil.parse4ContainerCanonicalName(serviceCanonicalName);

        // add request ID and the requester name to the payload
        ArrayList<cMsgPayloadItem> al = new ArrayList<cMsgPayloadItem>();
        try {
            // tell the service who is requesting the service
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_NAME,requester));
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_REQUEST_ID,0));
        } catch (Exception e) {
            throw new CException(e.getMessage());
        }
        cMsgMessage msg = new cMsgMessage();
        for(cMsgPayloadItem p:al){
            msg.addPayloadItem(p);
        }

        // first get connection from the local map
        try {
            connection = getConnection(dpHost);
        } catch (CException e) {

            // create a new connection to the DPE.
            // flag it to remove afterwards.
            willDelete = true;
            connection = connect2Dpe(clientName,dpHost);
        }
        if(isConnected(connection)){

            // fill transport parameters
            CTrParameter p =new CTrParameter();
            p.setConnection(connection);
            p.setMessage(msg);
            p.setSubject(container);
            p.setType(CSISConstants.ServiceControlRequestVersion);
            p.setText(serviceCanonicalName);
            p.setTimeout(timeout);

            cMsgMessage res = syncSend(p);
            if (res != null) {
                version = res.getText();
            } else {
                version = "failed";
            }

            // remove connection if flag is set
            if(willDelete){
                disconnect(connection);
            }
        } else {
            throw new CException("connection failed to a DPE on the host = "+dpHost);
        }
        return version;
    }

    /**
     * Sends a request to a service, that will trigger
     * a service engine getVersion() method execution.
     * @see org.jlab.clara.system.ICService#getVersion()
     * communication is done using platform normative
     * gateway service that works as a broker.
     *
     * @param serviceCanonicalName Requesting service name,
     *                             constructed as:
     *                             hostName/containerName/engineName
     * @param timeOut timeout of the sync request
     * @return the output string of the getVersion() method of the engine, or incase
     * of a failure string = "failed"
     */
    String syncPingServiceGW(String serviceCanonicalName,
                             int timeOut) throws CException{
        String version;
        boolean willDelete = false;
        Object connection;

        // gateway service runs by default on the platform
        String dpHost = myConfig.getPlatformHost();

        // add request ID and the requester name to the payload
        ArrayList<cMsgPayloadItem> al = new ArrayList<cMsgPayloadItem>();
        try {
            // tell the service who is requesting the service
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_NAME,clientName));
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_REQUEST_ID,0));
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_REQUEST_TIMEOUT,timeOut));
        } catch (Exception e) {
           throw new CException(e.getMessage());
        }

        cMsgMessage msg = new cMsgMessage();
        for(cMsgPayloadItem p:al){
            msg.addPayloadItem(p);
        }
        // first get connection from the local map
        try {
            connection = getConnection(dpHost);
        } catch (CException e) {

            // create a new connection to the DPE.
            // flag it to remove afterwards.
            willDelete = true;
            connection = connect2Dpe(clientName,dpHost);
        }
        if(isConnected(connection)){

            // fill transport parameters
            CTrParameter p =new CTrParameter();
            p.setConnection(connection);
            p.setMessage(msg);
            p.setText(serviceCanonicalName);
            p.setSubject("Clara_Gateway");
            p.setType(CSISConstants.GatewayServiceControlRequestVersion);
            p.setTimeout(timeOut);

            cMsgMessage res = syncSend(p);
            if (res != null) {
                version = res.getText();
            } else {
                version = "timed out";
            }

            // remove connection if flag is set
            if(willDelete){
                disconnect(connection);
            }
        } else {
            throw new CException("connection failed to a DPE on the host = "+dpHost);
        }
        return version;
    }

    /**
     * Informs a service to report the results of the next service
     * request/execution (for e.g. next processed event)
     * The result of the service execution will be sent to:
     * subject = requester (the name given at the constructor),
     * type = @see CSISConstants#DATA_REPORT.
     * This assumes that this client should subscribe mentioned
     * above subject and type before requesting the next event
     * report.
     *
     * @param serviceCanonicalName canonical name of a service that
     *                             this client requests
     * @return status of the operation.
     * @throws CException
     */
    protected boolean reportNextEvent(String serviceCanonicalName) throws CException{
        boolean stat;
        boolean willDelete = false;
        Object connection;


        // get the host of the service
        String dpHost = CUtil.parse4DpeHostName(serviceCanonicalName);

        // get the service container name
        String container = CUtil.parse4ContainerCanonicalName(serviceCanonicalName);

        // add request ID and the requester name to the payload
        ArrayList<cMsgPayloadItem> al = new ArrayList<cMsgPayloadItem>();
        try {
            // tell the service who is requesting the service
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_NAME,clientName));
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_REQUEST_ID,0));
        } catch (Exception e) {
            throw new CException(e.getMessage());
        }
        cMsgMessage msg = new cMsgMessage();
        for(cMsgPayloadItem p:al){
            msg.addPayloadItem(p);
        }
        // first get connection from the local map
        try {
            connection = getConnection(dpHost);
        } catch (CException e) {

            // create a new connection to the DPE.
            // flag it to remove afterwards.
            willDelete = true;
            connection = connect2Dpe(clientName,dpHost);
        }
        if(isConnected(connection)){

            // fill transport parameters
            CTrParameter p =new CTrParameter();
            p.setConnection(connection);
            p.setMessage(msg);
            p.setSubject(container);
            p.setType(CSISConstants.ServiceControlRequestBroadcast);
            p.setText(serviceCanonicalName);

            stat = send(p);

            // remove connection if flag is set
            if(willDelete){
                disconnect(connection);
            }
        } else {
            throw new CException("connection failed to a DPE on the host = "+dpHost);
        }

        return stat;
    }

    /**
     * Informs a gateway service to ask service to report the results
     * of the next service request/execution (for e.g. next processed event)
     * The result of the service execution will be sent directly to the
     * gateway service that will forward it to the message:
     * subject = requester (the name given at the constructor),
     * type = @see CSISConstants#DATA_REPORT.
     * This assumes that this client should subscribe mentioned
     * above subject and type before requesting the next event
     * report.
     *
     * @param serviceCanonicalName canonical name of a service that
     *                             this client requests
     * @return status of the operation.
     * @throws CException
     */
    protected boolean reportNextEventGW(String serviceCanonicalName) throws CException{
        boolean stat;
        boolean willDelete = false;
        Object connection;

        // gateway service runs by default on the platform
        String dpHost = myConfig.getPlatformHost();

        // add request ID and the requester name to the payload
        ArrayList<cMsgPayloadItem> al = new ArrayList<cMsgPayloadItem>();
        try {
            // tell the service who is requesting the service
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_NAME,clientName));
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_REQUEST_ID,0));
        } catch (Exception e) {
            throw new CException(e.getMessage());
        }

        cMsgMessage msg = new cMsgMessage();
        for(cMsgPayloadItem p:al){
            msg.addPayloadItem(p);
        }
        // first get connection from the local map
        try {
            connection = getConnection(dpHost);
        } catch (CException e) {

            // create a new connection to the DPE.
            // flag it to remove afterwards.
            willDelete = true;
            connection = connect2Dpe(clientName,dpHost);
        }
        if(isConnected(connection)){

            // fill transport parameters
            CTrParameter p =new CTrParameter();
            p.setConnection(connection);
            p.setMessage(msg);
            p.setText(serviceCanonicalName);
            p.setSubject("Clara_Gateway");
            p.setType(CSISConstants.GatewayServiceControlRequestBroadcast);

            stat = send(p);

            // remove connection if flag is set
            if(willDelete){
                disconnect(connection);
            }
        } else {
            throw new CException("connection failed to a DPE on the host = "+dpHost);
        }

        return stat;
    }


    /**
     * Keeps active the main thread of this class
     * to be able to listen aSync messages from
     * the Clara platform
     */
    void start(){
        stop();
        isRunning = true;
        new KeepActive().start();
    }

    /**
     * Stops the keep active thread
     */
    private void stop(){
        isRunning = false;
    }





    /**
     * Takes ICService implementing object (service) and returns cMsg payload structure
     *
     * @param s implementing object
     * @return ArrayList of cMsgPayloadItem objects
     */
    ArrayList<cMsgPayloadItem> serviceAsPayload(ICService s) throws CException{
        String author      = CConstants.udf;
        String description = CConstants.udf;
        String language    = CConstants.udf;
        String version     = CConstants.udf;
        ArrayList<cMsgPayloadItem> al = new ArrayList<cMsgPayloadItem>();
        if(s.getName()==null) return null;
        if(s.getAuthor()!=null)author = s.getAuthor();
        if(s.getDescription()!=null)description = s.getDescription();
        if(s.getVersion()!=null)version = s.getVersion();
        if(s.getLanguage()!=null)language = s.getLanguage();
        try {
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_NAME,myConfig.getLocalDpeHost()+
                    "/"+clientName+"/"+s.getName()));
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_AUTHOR,author));
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_DESCRIPTION,description));
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_VERSION,version));
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_LANGUAGE,language));
        } catch (Exception e) {
            throw new CException(e.getMessage());
        }
        return al;
    }


    /**
     * Checks if the given JioSerial contains primitive data or an object.
     *
     * @param data
     * @return true if the data is an object
     */
    boolean isObject(JioSerial data)
    {
        int id = data.getMimeType().id();
        return id > 0 && id <= 202;
    }

    /**
     * Request id is used for establishing genetic/logical
     * association between service requests.
     * Returns service request id from the service
     * communication message
     *
     * @param msg message passed between service
     * @return  request id
     */
    int getRequestId(cMsgMessage msg) throws CException{
        int id = -1;
        if(msg.getPayloadItem(CSISConstants.SERVICE_REQUEST_ID)!=null) {
            try {
                id = msg.getPayloadItem(CSISConstants.SERVICE_REQUEST_ID).getInt();
            } catch (cMsgException e) {
                throw new CException(e.getMessage());
            }
        }
        return id;
    }

    /**
     * Takes the service engine execution result and
     * creates JioSerial object and with the appropriate
     * cMsgPayload items fills the cMSgMessage object,
     * which will be sent through the wire to the next
     * service in the chain.
     *
     * @throws CException
     */
    cMsgMessage createResponseAndPack(cMsgMessage msg,
                                      ICService service,
                                      JioSerial result) throws CException{

        // prepare payload structure for sending the response
        ArrayList<cMsgPayloadItem> al = serviceAsPayload(service);

        // prepare response message
        cMsgMessage mr;
        try {
            mr = msg.response();
        } catch (cMsgException e) {
            throw new CException(e.getMessage());
        }

        result.packEnvelope(al,mr);

        for(cMsgPayloadItem item:al){
            mr.addPayloadItem(item);
        }
        return mr;
    }


    /**
     * gracefully exit Clara client
     */
    protected void exit() throws CException{

        // un-subscribe all subscriptions  and remove all callbacks
        removeAllCallBacks();

        // close all connections
        for(Object c:_connections.values()){
            disconnect(c);
        }

        // clear maps
        _callBacks.clear();
        _connections.clear();
        stop();
    }


    void _logMsg(JioSerial data) throws CException{
        if(data.getStatus().equals(CConstants.info) ||
                data.getStatus().equals(CConstants.error) ||
                data.getStatus().equals(CConstants.warning) ){
            int severityID = CConstants.defineSeverityID(data.getStatus());
            String author = data.getExceptionSource();
            String message = data.getLogMessage();
            _logMsg(author,severityID,message);
        }
    }

    boolean _logMsg(String author,
                    int severity,
                    String msgText) throws CException{
        boolean stat;
        boolean willDelete = false;
        Object connection;

        // gateway service runs by default on the platform
        String dpHost = myConfig.getPlatformHost();
        // first get connection from the local map
        try {
            connection = getConnection(dpHost);
        } catch (CException e) {

            // create a new connection to the DPE.
            // flag it to remove afterwards.
            willDelete = true;
            connection = connect2Dpe(clientName,dpHost);
        }
        if(isConnected(connection)){

            // fill transport parameters
            CTrParameter p =new CTrParameter();
            p.setConnection(connection);
            p.setSubject(myConfig.getPlatformName()+"_spy");
            p.setType(CSISConstants.LOG_TYPE);

            cMsgMessage msg = new cMsgMessage();
            msg.setText(msgText);
            msg.setUserInt(severity);
            try {
                msg.addPayloadItem(new cMsgPayloadItem("author",author));
            } catch (cMsgException e) {
                throw new CException(e.getMessage());
            }
            p.setMessage(msg);

            stat = send(p);

            // remove connection if flag is set
            if(willDelete){
                disconnect(connection);
            }
        } else {
            throw new CException("connection failed to a DPE on the host = "+dpHost);
        }
        return stat;
    }


    @Override
    public String toString(){
        StringBuilder sb = new StringBuilder();
        sb.append("**************************************************\n");
        sb.append("*               CLARA 3 client = " + clientName + "    \n");
        sb.append("**************************************************\n");
        sb.append("- Name                  = " + clientName + "\n");
        sb.append("- Host                  = " + myConfig.getLocalDpeHost() + "\n");
        sb.append("- Start time            = " + CUtil.getCurrentTime() + "\n");
        sb.append("- UDL                   = " + getPlatformConnection().getCurrentUDL() + "\n");
        sb.append("- Platform              = "+ myConfig.getPlatformName()+"\n");
        sb.append("- Platform TCP port     = " + myConfig.getPlatformTcpPort() + "\n");
        sb.append("- Platform UDP port     = "+ myConfig.getPlatformUdpPort()+"\n");
        sb.append("\n");
        for(String h:_connections.keySet()){
            sb.append("-Connected to host  = "+h+"\n");
        }
        sb.append("**************************************************\n");

        return sb.toString();
    }

    //@todo check to see if I need this
    /**
     * private inner class to keep this client alive
     */
    private class KeepActive extends Thread{
        @Override
        public void run() {
            super.run();
            while(isRunning){
                CUtil.sleep(1000);
            }
        }
    }
}
