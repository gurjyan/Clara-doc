package org.jlab.clara.ui;

import com.martiansoftware.jsap.*;
import org.jlab.clara.frontend.JOrchestrator;
import org.jlab.clara.system.CException;
import org.jlab.clara.util.CUtil;

import java.util.Scanner;
import static org.jlab.clara.ui.EClaraCmd.valueOf;

/**
 * Command line Clara
 *
 * @author gurjyan
 *         Date: 3/25/14 Time: 10:28 AM
 * @version 3.x
 */
public class ClaraCmd extends JOrchestrator{
    private static final String ARG_HOST   = "host";
    private static final String ARG_EXPID  = "expid";
    private static final String ARG_INTER  = "inter";
    private static final String ARG_CMD    = "cmd";

    protected ClaraCmd() throws CException {
    }


    private static void setArguments(JSAP jsap) {

        FlaggedOption host = new FlaggedOption(ARG_HOST)
                .setStringParser(JSAP.STRING_PARSER)
                .setRequired(true)
                .setShortFlag('h')
                .setLongFlag("host");
        host.setHelp("Clara platfrom host");
        FlaggedOption name = new FlaggedOption(ARG_EXPID)
                .setStringParser(JSAP.STRING_PARSER)
                .setRequired(true)
                .setShortFlag('n')
                .setLongFlag("name");
        name.setHelp("Clara platfrom name");
        QualifiedSwitch inter = new QualifiedSwitch( ARG_INTER,
                JSAP.STRING_PARSER,
                JSAP.NO_DEFAULT,
                JSAP.NOT_REQUIRED,
                'i',
                "inter",
                "Program interactive mode" );
        try {
            jsap.registerParameter(host);
            jsap.registerParameter(name);
            jsap.registerParameter(inter);
        } catch (JSAPException e) {
            e.printStackTrace();
            System.exit(1);
        }
    }


    public static void main(String[] args) {
        /* Check the arguments */
        JSAP jsap = new JSAP();
        setArguments(jsap);
        JSAPResult config = jsap.parse(args);
        if (!config.success()) {
            System.err.println();
            System.err.println("Usage: clara " + jsap.getUsage());
            System.err.println();
            System.err.println(jsap.getHelp());
        } else {

            ClaraCmd api = null;
            try {
                api = new ClaraCmd();
            } catch (CException e) {
                e.printStackTrace();
            }

            if(config.getBoolean(ARG_INTER)){
                Scanner iScan = new Scanner(System.in);
                String cmd;
                EClaraCmd[] cmdList = EClaraCmd.values();
                while(true){
                    System.out.print("<" + CUtil.getCurrentTime("HH:mm:ss")+" clara >");
                    cmd = iScan.nextLine();
                    try{
                        switch (valueOf(cmd)){
                            case help: {
                                for(int i=0; i<=7; i++){
                                    System.out.println(cmdList[i].getHelp());
                                }
                                break;
                            }
                            case exit: {
                                System.exit(0);
                                break;
                            }
                            case ls: {
                                System.out.println("enter session...");
                                String v = iScan.nextLine();
                                break;
                            }
                            case lsl: {
                                break;
                            }
                        }
                    } catch (IllegalArgumentException e){
                        System.out.println("unknown command");
                    }
                }
            }
        }
    }
}
