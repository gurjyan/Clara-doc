package org.jlab.clara.util;

import java.io.File;
import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

/**
 * Logger Singleton
 *
 * @author gurjyan
 *         Date: 3/28/14 Time: 4:09 PM
 * @version 2
 */
public class CLogger {

        public static final Logger logger = Logger.getLogger("Clara");
        private static CLogger instance = null;

        public static CLogger getInstance() {
            if(instance == null) {
                initLogger();
                instance = new CLogger ();
            }
            return instance;
        }

        private static void initLogger() {
            FileHandler myFileHandler = null;
            try {
                myFileHandler = new FileHandler(System.getenv("CLARA_SERVICES")+ File.separator+
                        "log"+ File.separator+"clara.log");
            } catch (IOException e) {
                e.printStackTrace();
            }
            myFileHandler.setFormatter(new SimpleFormatter());
            logger.addHandler(myFileHandler);
            logger.setUseParentHandlers(false);
            logger.setLevel(Level.FINEST);
        }
    }


