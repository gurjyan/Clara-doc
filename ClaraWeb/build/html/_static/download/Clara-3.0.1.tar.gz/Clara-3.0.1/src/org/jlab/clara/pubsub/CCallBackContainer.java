/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */
package org.jlab.clara.pubsub;

import org.jlab.coda.cMsg.cMsgCallbackAdapter;
import org.jlab.coda.cMsg.cMsgSubscriptionHandle;

/**
 * This class plays the role of the container for cMsg callbacks.
 * It includes callback adapter object, subscription handler, the
 * canonical name of the subscribing service and the subscribing
 * service host name.
 *
 * @author gurjyan
 * @version 3.x
 */

public class CCallBackContainer {
    private cMsgCallbackAdapter    callBack;
    private cMsgSubscriptionHandle subscriptionHandle;
    private String                 serviceHost;
    private String                 subscribingServiceCanonicalName;

    public cMsgCallbackAdapter getCallBack() {
        return callBack;
    }

    public void setCallBack(cMsgCallbackAdapter callBack) {
        this.callBack = callBack;
    }

    public cMsgSubscriptionHandle getSubscriptionHandle() {
        return subscriptionHandle;
    }

    public void setSubscriptionHandle(cMsgSubscriptionHandle subscriptionHandle) {
        this.subscriptionHandle = subscriptionHandle;
    }

    public String getServiceHost() {
        return serviceHost;
    }

    public void setServiceHost(String serviceHost) {
        this.serviceHost = serviceHost;
    }

    public String getSubscribingServiceCanonicalName() {
        return subscribingServiceCanonicalName;
    }

    public void setSubscribingServiceCanonicalName(String subscribingServiceCanonicalName) {
        this.subscribingServiceCanonicalName = subscribingServiceCanonicalName;
    }
}
