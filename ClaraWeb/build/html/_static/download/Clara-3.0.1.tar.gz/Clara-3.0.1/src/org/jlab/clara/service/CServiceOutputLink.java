/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */


package org.jlab.clara.service;

/**
 *
 * @author gurjyan
 * @version 3.x
 */
public class CServiceOutputLink
{
    private final String containerName;
    private final String serviceName;
    private final String host;


    public CServiceOutputLink(String serviceName, String containerName, String host)
    {
        this.serviceName = serviceName;
        this.containerName = containerName;
        this.host = host;
    }


    public String getContainerName()
    {
        return containerName;
    }


    public String getServiceName()
    {
        return serviceName;
    }


    public String getHost()
    {
        return host;
    }


    @Override
    public int hashCode()
    {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((serviceName == null) ? 0 : serviceName.hashCode());
        return result;
    }


    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        CServiceOutputLink other = (CServiceOutputLink) obj;
        if (serviceName == null) {
            if (other.serviceName != null)
                return false;
        } else if (!serviceName.equals(other.serviceName))
            return false;
        return true;
    }
}
