/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */

package org.jlab.clas12.services.system;

import java.io.Serializable;
import java.util.List;

/**
 * date  Date: 9/19/13 Time: 9:24 AM
 *
 * @author gurjyan
 * @version 1.4
 */
public class TapeManagerConfig implements Serializable {

    private final String tapeLocation;
    private final String destination;
    private final List<String> dataFiles;


    public TapeManagerConfig(String tapeDir, String destDir, List<String> files) {
        tapeLocation = tapeDir;
        destination = destDir;
        dataFiles = files;
    }


    public String getTapeLocation() {
        return tapeLocation;
    }


    public String getDestination() {
        return destination;
    }


    public List<String> getDataFiles() {
        return dataFiles;
    }
}
