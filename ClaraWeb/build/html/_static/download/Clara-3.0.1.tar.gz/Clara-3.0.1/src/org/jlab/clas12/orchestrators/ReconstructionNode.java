/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */
package org.jlab.clas12.orchestrators;

import org.jlab.clara.constants.CConstants;
import org.jlab.clara.data.JioSerial;
import org.jlab.clas12.tools.MimeType;
import org.jlab.clas12.tools.property.JPropertyList;

import java.io.File;

/**
 * Provides the logic for managing the reconstruction of a file.
 * <p>
 * This class contains methods specific to CLAS12 handling of reconstruction
 * files.
 */
class ReconstructionNode {

    private ReconstructionOrchestrator orchestrator;

    final DpeInfo dpe;
    final String stageName;
    final String readerName;
    final String writerName;

    String currentInputFileName;
    String currentInputFile ;
    String currentOutputFile;

    int eventNumber;
    long startTime;


    public ReconstructionNode(ReconstructionOrchestrator orchestrator, DpeInfo dpe) {
        this.dpe = dpe;
        this.orchestrator = orchestrator;

        this.stageName = orchestrator.getStageServiceName(dpe);
        this.readerName = orchestrator.getReaderServiceName(dpe);
        this.writerName = orchestrator.getWriterServiceName(dpe);
    }


    void deploy() {
        orchestrator.deployInputOutputServices(dpe);
    }


    void deployChain(DpeInfo other) {
        orchestrator.deployReconstructionChain(other);
        orchestrator.linkReconstructionChain(other);
        orchestrator.linkInputOutputWithReconstructionChain(dpe, other);
        orchestrator.linkInputOutputServices(dpe);
    }


    void setPaths(String inputPath, String outputPath, String stagePath) {
        JPropertyList pl = new JPropertyList();
        pl.addTailProperty("input_path", inputPath);
        pl.addTailProperty("output_path", outputPath);
        pl.addTailProperty("stage_path", stagePath);
        orchestrator.configService(stageName, new JioSerial(pl),false);
    }


    boolean setFiles(String inputFileName) {
        currentInputFileName = inputFileName;
        currentInputFile = CConstants.udf;
        currentOutputFile = CConstants.udf;

        JPropertyList pl = new JPropertyList();
        pl.addHeadProperty("action","stage_input");
        pl.addTailProperty("file", currentInputFileName);
        System.out.printf("Staging file %s in %s%n", currentInputFileName, dpe.name);
        JioSerial r = orchestrator.syncExecuteService(stageName, new JioSerial(pl), 1, 300000,false);
        if (r == null) {
            currentInputFileName = CConstants.udf;
            return false;
        }

        if (!r.getStatus().equals(CConstants.error)) {
            JPropertyList rl = r.getPropertyList();
            currentInputFile = rl.getPropertyValue("input_file");
            currentOutputFile = rl.getPropertyValue("output_file");
            return true;
        } else {
            System.err.println(r.getDataDescription());
            currentInputFileName = CConstants.udf;
            return false;
        }
    }


    void setFiles(String inputFile, String outputFile) {
        currentInputFile = inputFile;
        currentOutputFile = outputFile;
        currentInputFileName = new File(inputFile).getName();
    }


    boolean saveOutputFile() {
        JPropertyList plr = new JPropertyList();
        plr.addHeadProperty("action","remove_input");
        plr.addTailProperty("file", currentInputFileName);
        JioSerial rr = orchestrator.syncExecuteService(stageName, new JioSerial(plr), 1, 60000,false);

        JPropertyList pls = new JPropertyList();
        pls.addHeadProperty("action","save_output");
        pls.addTailProperty("file", currentInputFileName);
        JioSerial rs = orchestrator.syncExecuteService(stageName, new JioSerial(pls), 1, 60000,false);

        currentInputFileName = CConstants.udf;
        currentInputFile = CConstants.udf;
        currentOutputFile = CConstants.udf;

        if (rr == null) {
            return false;
        }

        if (rs == null) {
            return false;
        }

        boolean status = true;
        if (rr.getStatus().equals(CConstants.error)) {
            System.err.println(rr.getDataDescription());
            status = false;
        }
        if (rs.getStatus().equals(CConstants.error)) {
            status = false;
            System.err.println(rs.getDataDescription());
        }

        return status;
    }


    void openFiles() {
        openFiles(0);

        // total number of events in the file
        JioSerial tr = new JioSerial("count", MimeType.STRING);
        JioSerial rtr = orchestrator.syncExecuteService(readerName, tr, 1, 600000,false);
        eventNumber = rtr.getIntObject();
    }


    void openFiles(int frequency) {
        startTime = 0;
        eventNumber = 0;

        // open input file
        JPropertyList pl = new JPropertyList();
        pl.addHeadProperty("action","open");
        pl.addTailProperty("file", currentInputFile);
        pl.addTailProperty("report_data", writerName);
        if (frequency > 0) {
            pl.addTailProperty("report_frequency", new Integer(frequency).toString());
        }
        System.out.printf("Opening file %s in %s%n", currentInputFileName, dpe.name);
        orchestrator.configService(readerName, new JioSerial(pl),false);

        // endiannes of the file
        JioSerial er = new JioSerial("order", MimeType.STRING);
        JioSerial rer = orchestrator.syncExecuteService(readerName, er, 1, 600000,false);

        // open output file
        pl = new JPropertyList();
        pl.addHeadProperty("action", "open");
        pl.addTailProperty("file", currentOutputFile);
        pl.addTailProperty("order", rer.getDataEndianness().toString());
        pl.addTailProperty("overwrite", "true");
        orchestrator.configService(writerName, new JioSerial(pl),false);
    }


    void closeFiles() {
        // close input file
        JPropertyList pl = new JPropertyList();
        pl.addHeadProperty("action","close");
        pl.addTailProperty("file", currentInputFile);
        orchestrator.configService(readerName, new JioSerial(pl),false);

        // close output file
        pl = new JPropertyList();
        pl.addHeadProperty("action","close");
        pl.addTailProperty("file", currentOutputFile);
        orchestrator.configService(writerName, new JioSerial(pl),false);
    }


    void sendEventsToDpe(String dpeHost, int dpeCores) {
        if (startTime == 0) {
            startTime = System.currentTimeMillis();
        }

        int requestId = 1;
        System.out.printf("Using %d cores in %s to reconstruct %s%n", dpeCores, dpeHost, currentInputFileName);
        for (int i = 0; i < dpeCores; i++) {
            requestEvent(dpeHost, requestId++, "next");
        }
    }


    void requestEvent(String dpeHost, int requestId, String type) {
        JioSerial data = new JioSerial(type);
        data.setDataDestination(dpeHost + "/*/*");
        orchestrator.executeService(readerName, data, requestId++,false);
    }


    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((dpe == null) ? 0 : dpe.hashCode());
        return result;
    }


    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof ReconstructionNode)) {
            return false;
        }
        ReconstructionNode other = (ReconstructionNode) obj;
        if (dpe == null) {
            if (other.dpe != null) {
                return false;
            }
        } else if (!dpe.equals(other.dpe)) {
            return false;
        }
        return true;
    }
}
