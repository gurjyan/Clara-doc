/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */


package org.jlab.clara.dpe;

import java.io.Serializable;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * @author gurjyan
 * @version 3.x
 */

public class CDPEnvironmentData implements Serializable {
    private CopyOnWriteArrayList<String> serviceContainers = new CopyOnWriteArrayList<String>();
    long currentReportingTime;
    long timeSinceLastReporting;

    public long getCurrentReportingTime() {
        return currentReportingTime;
    }

    public void setCurrentReportingTime(long currentReportingTime) {
        this.currentReportingTime = currentReportingTime;
    }

    public long getTimeSinceLastReporting() {
        return timeSinceLastReporting;
    }

    public void setTimeSinceLastReporting(long timeSinceLastReporting) {
        this.timeSinceLastReporting = timeSinceLastReporting;
    }

    public CopyOnWriteArrayList<String> getServiceContainers() {
        return serviceContainers;
    }

    public void setServiceContainers(CopyOnWriteArrayList<String> serviceContainers) {
        this.serviceContainers = serviceContainers;
    }

    public void addServiceContainer(String n){
        serviceContainers.add(n);
    }

    public void removeServiceContainer(String n){
        serviceContainers.remove(n);
    }
}
