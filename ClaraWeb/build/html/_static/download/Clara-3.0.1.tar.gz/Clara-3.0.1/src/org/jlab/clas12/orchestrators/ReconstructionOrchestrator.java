/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */
package org.jlab.clas12.orchestrators;

import org.jlab.clara.config.CConfig;
import org.jlab.clara.constants.CConstants;
import org.jlab.clara.data.JioSerial;
import org.jlab.clara.frontend.JOrchestrator;
import org.jlab.clas12.tools.property.JPropertyList;
import org.jlab.clara.pubsub.CCallBack;
import org.jlab.clara.system.CException;
import org.jlab.clara.util.CUtil;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Provides the main logic for the standard orchestrators.
 * <p>
 * This class extends {@link JOrchestrator} with several methods specific to
 * CLAS12 reconstruction.
 *
 * @see DefaultDeploy
 * @see ReconstructionNode
 * @see DefaultOrchestrator
 * @see FarmOrchestrator
 */
class ReconstructionOrchestrator extends JOrchestrator {

    private ServiceInfo stage;
    private ServiceInfo reader;
    private ServiceInfo writer;

    private List<ServiceInfo> reconstructionChain;

    // Clara configuration information
    public CConfig myConfig = CConfig.getInstance();


    ReconstructionOrchestrator(String platform, String name) throws CException {
        super(platform, name + "_" + CUtil.generateName());
        setInputOutputServices();
    }



    void setReconstructionChain(List<ServiceInfo> reconstructionChain) {
        if (reconstructionChain == null) {
            throw new IllegalArgumentException("null reconstruction chain");
        }
        if (reconstructionChain.isEmpty()) {
            throw new IllegalArgumentException("empty reconstruction chain");
        }
        this.reconstructionChain = reconstructionChain;
    }


    private void setInputOutputServices() {
        String readerClass = "examples.clas12.services.convertors.EvioToEvioReader";
        String readerContainer = ReconstructionConfigParser.getDefaultContainer();
        String readerName = "EvioToEvioReader";

        String stageClass = "examples.clas12.services.system.DataManager";
        String stageContainer = ReconstructionConfigParser.getDefaultContainer();
        String stageName = "StageFiles";

        String writerClass = "examples.clas12.services.convertors.EvioToEvioWriter";
        String writerContainer = ReconstructionConfigParser.getDefaultContainer();
        String writerName = "EvioToEvioWriter";

        stage = new ServiceInfo(stageClass, stageContainer, stageName);
        reader = new ServiceInfo(readerClass, readerContainer, readerName);
        writer = new ServiceInfo(writerClass, writerContainer, writerName);
    }


    void deployInputOutputServices(DpeInfo dpe) {
        try {
            deploy(dpe.name, stage.cont, stage.classpath, CConstants.LANG_JAVA,false);
        deploy(dpe.name, reader.cont, reader.classpath, CConstants.LANG_JAVA,false);
        deploy(dpe.name, writer.cont, writer.classpath, CConstants.LANG_JAVA,false);
        } catch (CException e) {
            System.out.println(e.getMessage());
        }
    }


    void deployReconstructionChain(DpeInfo dpe) {
        for (ServiceInfo service : reconstructionChain) {
            try {
                deploy(dpe.name, service.cont, service.classpath, CConstants.LANG_JAVA,false);
            } catch (CException e) {
                System.out.println(e.getMessage());
            }
        }
    }


    void linkReconstructionChain(DpeInfo dpe) {
        ServiceInfo service = reconstructionChain.get(0);
        String previous = getServiceName(dpe, service);
        for (int i = 1; i < reconstructionChain.size(); ++i) {
            service = reconstructionChain.get(i);
            String current = getServiceName(dpe, service);
            try {
                linkServices(previous, current,false);
            } catch (CException e) {
                System.out.println(e.getMessage());
            }
            previous = current;
        }
    }


    void linkInputOutputWithReconstructionChain(DpeInfo ioDpe, DpeInfo recDpe) {
        String nameReader = getServiceName(ioDpe, reader);
        String nameWriter = getServiceName(ioDpe, writer);

        ServiceInfo first = reconstructionChain.get(0);
        String nameFirst = getServiceName(recDpe, first);
        ServiceInfo last = reconstructionChain.get(reconstructionChain.size()-1);
        String nameLast = getServiceName(recDpe, last);

        try {
            linkServices(nameReader, nameFirst,false);
        linkServices(nameLast, nameWriter,false);
        } catch (CException e) {
            System.out.println(e.getMessage());
        }
    }


    void linkInputOutputServices(DpeInfo ioDpe) {
        String nameReader = getServiceName(ioDpe, reader);
        String nameWriter = getServiceName(ioDpe, writer);
        try {
            linkServices(nameWriter, nameReader,false);
        } catch (CException e) {
            System.out.println(e.getMessage());
        }
    }


    String getStageServiceName(DpeInfo ioDpe) {
        return getServiceName(ioDpe, stage);
    }


    String getReaderServiceName(DpeInfo ioDpe) {
        return getServiceName(ioDpe, reader);
    }


    String getWriterServiceName(DpeInfo ioDpe) {
        return getServiceName(ioDpe, writer);
    }


    List<String> getReconstructionServicesNames(DpeInfo recDpe) {
        List<String> servicesNames = new ArrayList<String>();
        for (ServiceInfo service : reconstructionChain) {
            String name = getServiceName(recDpe, service);
            servicesNames.add(name);
        }
        return servicesNames;
    }


    List<String> getRegisteredReconstructionServicesNames(DpeInfo recDpe) {
        List<String> servicesNames = new ArrayList<String>();

        String readerName = getServiceName(recDpe, reader);
        String writerName = getServiceName(recDpe, writer);

        boolean fullChain = false;
        String currentService = readerName;

        while (true) {
            List<String> links = null;
            try {
                links = getLinks(currentService, 1000);
            } catch (CException e) {
                System.out.println(e.getMessage());
            }

            if (links.isEmpty()) {
                System.err.println("Error: " + currentService + " has no linked services.");
                break;
            }

            // TODO: handle more than one service linked (like services outside the chain)
            currentService = links.get(0);

            if (currentService.equals(writerName)) {
                List<String> writerLinks = null;
                try {
                    writerLinks = getLinks(currentService, 1000);
                } catch (CException e) {
                    System.out.println(e.getMessage());
                }
                if (writerLinks.contains(readerName)) {
                    fullChain = true;
                } else {
                    System.err.println("Error: " + writerName + " is not linked to " + readerName);
                }
                break;
            }

            servicesNames.add(currentService);
        }

        if (!fullChain) {
            servicesNames.clear();
        }

        return servicesNames;
    }


    private String getServiceName(DpeInfo dpe, ServiceInfo service) {
        return dpe.name + "/" + service.cont + "/" + service.name;
    }


    void dpeMonitorOn(IDpeCallBack callback) {
        DpeCallbackWrapper dpeCallback = new DpeCallbackWrapper(callback);
        try {
            super.dpeMonitorOn(dpeCallback);
        } catch (CException e) {
            System.out.println(e.getMessage());
        }
    }


    boolean checkDpe(String dpeHost) {
        PrintStream out = System.out;
        PrintStream err = System.err;
        PrintStream temp = new PrintStream(new OutputStream() {
            @Override
            public void write(int b) throws IOException {
                // Nothing
            }
        });
        System.setOut(temp);
        System.setErr(temp);

        boolean isActive = false;
        try {
            isActive = isDpeActive(dpeHost, 1000);
        } catch (CException e) {
            System.out.println(e.getMessage());
        }

        System.setOut(out);
        System.setErr(err);

        return isActive;
    }


    interface IDpeCallBack {
        void monitorCallBack(DpeInfo dpe);
    }

    private class DpeCallbackWrapper extends CCallBack {

        final IDpeCallBack callback;


        public DpeCallbackWrapper(IDpeCallBack callback) {
            this.callback = callback;
        }

        @Override
        public void monitorCallBack(JioSerial data) {
            JPropertyList pl = data.getPropertyList();
            String host = pl.getPropertyValue("host");
            int cores = CUtil.isNumber(pl.getPropertyValue("cores"));
            String servicesPath = pl.getPropertyValue("clara-services");
            DpeInfo dpe = new DpeInfo(host, cores, servicesPath);
            callback.monitorCallBack(dpe);
        }
    }
}
