/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */


package org.jlab.clara.platform;

import org.jlab.clara.dpe.CDPEnvironmentInfo;
import org.jlab.coda.cMsg.cMsgException;
import org.jlab.coda.cMsg.cMsgMessage;
import org.jlab.coda.cMsg.cMsgPayloadItem;
import org.jlab.clara.constants.CConstants;
import org.jlab.clara.constants.CSISConstants;
import org.jlab.clara.container.CSContainerRegistration;
import org.jlab.clara.service.CServiceRegistration;
import org.jlab.clara.util.CLogger;
import org.jlab.clara.util.CUtil;

import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author gurjyan
 * @version 3.x
 */
public class CPlatformRegistrar {

    private ConcurrentHashMap<String, CDPEnvironmentInfo>
            ClaraDpeInfoMap            = new ConcurrentHashMap<String, CDPEnvironmentInfo>();

    private ConcurrentHashMap<String, CSContainerRegistration>
            ServiceContainerRepository = new ConcurrentHashMap<String, CSContainerRegistration>();

    // local instance of the logger object
    private static CLogger lg = CLogger.getInstance();


    /**
     * gets the map of registered service containers
     * @return map of CSContainerRegistration objects
     */
    public synchronized ConcurrentHashMap<String, CSContainerRegistration> getServiceContainerRepository() {
        return ServiceContainerRepository;
    }

    public synchronized ArrayList<cMsgPayloadItem> getServiceContainersPL(){

        ArrayList<cMsgPayloadItem> al = new ArrayList<cMsgPayloadItem>();

        // create cMsg messages for every service container and put it into the array
        cMsgMessage[] containers = new cMsgMessage[ServiceContainerRepository.size()];

        int i=0;
        for(CSContainerRegistration scr:ServiceContainerRepository.values()){
            containers[i] = scr.getAscMsgMessage();
            i++;
        }

        if(containers!=null && containers.length>0){
            try {
                al.add(new cMsgPayloadItem(CSISConstants.SERVICE_CONTAINERS,containers));
            } catch (cMsgException e) {
                lg.logger.severe(CUtil.stack2str(e));
            }
        }
        return al;
    }

    /**
     * Adds a service container to the map
     * @param a  CSContainerRegistration object
     */
    public synchronized void addServiceContainer(CSContainerRegistration a){
        if(!a.getName().equals(CConstants.udf)){
            ServiceContainerRepository.put(a.getName(),a);
        }
    }
    /**
     * Removes service container from the map
     * @param n the name of the agent
     */
    public synchronized void removeServiceContainer(String n){
        if(ServiceContainerRepository.containsKey(n)){
            ServiceContainerRepository.remove(n);
        }
    }

    /**
     * Removes service from the registration map
     * @param containerName service container name
     * @param serviceName service canonical name
     */
    public synchronized void removeService(String containerName, String serviceName){
        if(ServiceContainerRepository.containsKey(containerName)){
            CServiceRegistration sr = ServiceContainerRepository.get(containerName).getServiceRegistration(serviceName);

            if(sr!=null){
                ServiceContainerRepository.get(containerName).getServices().remove(sr);
            }
        }
    }

    /**
     * gets the map of registered agents
     * @return map of  CDPEnvironmentInfo objects
     */
    public synchronized ConcurrentHashMap<String, CDPEnvironmentInfo> getClaraDpeInfoMap() {
        return ClaraDpeInfoMap;
    }

    /**
     * Sets entire agent registration map
     * @param claraDpeInfoMap map (key = name of the agent,
     * value =  CDPEnvironmentInfo objects)
     */
    public synchronized void setClaraDpeInfoMap(ConcurrentHashMap<String, CDPEnvironmentInfo> claraDpeInfoMap) {
        ClaraDpeInfoMap = claraDpeInfoMap;
    }

    /**
     * gets the specific agent information form the map
     * @param n the name of the agent
     * @return AComponent object
     */
    public synchronized CDPEnvironmentInfo getClaraContainerInfo(String n){
        return ClaraDpeInfoMap.get(n);
    }
    /**
     * Adds an DPE to the DPEs map
     * @param a  CDPEnvironmentInfo object
     */
    public synchronized void addClaraDpe(CDPEnvironmentInfo a){
        ClaraDpeInfoMap.put(a.getName(),a);
    }
    /**
     * Removes DPE from the DPEs map
     * @param n the name of the agent
     */
    public synchronized void removeClaraDpe(String n){
        if(ClaraDpeInfoMap.containsKey(n)){
            ClaraDpeInfoMap.remove(n);
        }
    }

}
