/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */
package org.jlab.clara.system;

import org.jlab.clara.data.JioSerial;
import java.util.Random;

/**
 * Mat Clara interface
 * Note: service name must be unique.
 *
 * @author gurjyan
 * @version 3.x
 */

public interface ICService {

    public final int instanceId = new Random().nextInt(1000);

    public void      configure(JioSerial data);
    public JioSerial execute(JioSerial data);
    public JioSerial execute(JioSerial[] data);
    public void      destruct();
    public String     getName();
    public String     getAuthor();
    public String     getDescription();
    public String     getVersion();
    public String     getLanguage();
}
