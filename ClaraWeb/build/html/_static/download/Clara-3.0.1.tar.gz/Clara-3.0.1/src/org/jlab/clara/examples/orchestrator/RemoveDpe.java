/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */


package org.jlab.clara.examples.orchestrator;

import org.jlab.clara.frontend.JOrchestrator;
import org.jlab.clara.system.CException;

/**
 *
 * @author gurjyan
 *
 * @version 3.x
 */
public class RemoveDpe extends JOrchestrator {

    protected RemoveDpe() throws CException {
        super();
    }

    public static void main(String[] args) {
        if(args.length!=1){
            System.out.println("synopsis: accepts dpe hostname as a parameter.");
        } else {
            try {
                RemoveDpe rd =  new RemoveDpe();
                rd.exitDpe(args[0]);
                rd.exit();
            } catch (CException e) {
                System.out.println(e.getMessage());
            }
        }
    }
}
