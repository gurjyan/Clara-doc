/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */
package org.jlab.clas12.orchestrators;

import com.martiansoftware.jsap.*;
import org.jlab.clara.config.CConfig;
import org.jlab.clara.constants.CConstants;
import org.jlab.clara.data.JioSerial;
import org.jlab.clas12.tools.MimeType;
import org.jlab.clara.pubsub.CCallBack;
import org.jlab.clas12.orchestrators.ReconstructionOrchestrator.IDpeCallBack;
import org.jlab.clas12.services.system.TapeManagerConfig;
import org.jlab.clara.system.CException;
import org.jlab.clara.util.CUtil;

import java.io.File;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.concurrent.*;

/**
 * Runs production jobs, using each node for IO and local reconstruction.
 */
public class FarmOrchestrator {

    private ReconstructionOrchestrator orchestrator;

    private final FarmDirectories paths;

//    private int fileIndex;
    private int finishedFilesCounter;

    private int processingTimes = 1;
//    private int processingCounter = 0;

    private final Set<ReconstructionNode> nodes;
    private ExecutorService nodesSetup;
    private final Object lock = new Object();

    // list of input file names to be processed
    private final List<String> inputFiles;
    // active queue for processing data files
    private BlockingDeque<String> processingQueue = new LinkedBlockingDeque<String>();

    private static class FarmDirectories {

        final String tapeDirectory;
        final String inputDirectory;
        final String outputDirectory;
        final String stageDirectory;


        FarmDirectories(String tpDir, String inDir, String outDir, String tmpDir) {
            tapeDirectory = tpDir;
            inputDirectory = inDir;
            outputDirectory = outDir;
            stageDirectory = tmpDir;
        }
    }


    public static void main(String[] args) {
        /* Check the arguments */
        JSAP jsap = new JSAP();
        setArguments(jsap);
        JSAPResult config = jsap.parse(args);
        if (!config.success()) {
            System.err.printf("Usage:%n%n  farm-orchestrator %s%n%n%n", jsap.getUsage());
            System.err.println(jsap.getHelp());
            System.exit(1);
        }

        String platform = config.getString(ARG_PLATFORM);
        String services = config.getString(ARG_SERVICES_FILE);
        String files = config.getString(ARG_INPUT_FILES);

        String tpDir = config.getString(ARG_TAPE_DIR);
        String inDir = config.getString(ARG_INPUT_DIR);
        String outDir = config.getString(ARG_OUTPUT_DIR);
        String tmpDir = config.getString(ARG_STAGE_DIR);

        int processings = config.getInt(ARG_LOOPS);

        ReconstructionConfigParser parser = new ReconstructionConfigParser();
        List<ServiceInfo> recChain = parser.parseReconstructionChain(services);
        if (recChain.isEmpty()) {
            System.err.println("Could not configure reconstruction chain");
            System.exit(1);
        }

        List<String> inFiles = parser.readInputFiles(files);
        if (inFiles.isEmpty()) {
            System.err.println("Could not get list of input files");
            System.exit(1);
        }

        if (processings <= 0) {
            System.err.printf("Error: bad number of times to loop (%s)%n", args[5]);
            System.exit(1);
        }

        FarmDirectories paths = new FarmDirectories(tpDir, inDir, outDir, tmpDir);
        FarmOrchestrator fo = new FarmOrchestrator(platform, recChain, inFiles, paths, processings);
        fo.run();
    }


    private static final String ARG_PLATFORM      = "platform";
    private static final String ARG_LOOPS         = "loops";
    private static final String ARG_TAPE_DIR      = "tapeDir";
    private static final String ARG_INPUT_DIR     = "inputDir";
    private static final String ARG_OUTPUT_DIR    = "outputDir";
    private static final String ARG_STAGE_DIR     = "stageDir";
    private static final String ARG_SERVICES_FILE = "servicesFile";
    private static final String ARG_INPUT_FILES   = "inputFiles";

    private static void setArguments(JSAP jsap) {

        FlaggedOption platform = new FlaggedOption(ARG_PLATFORM)
                .setStringParser(JSAP.STRING_PARSER)
                .setRequired(false)
                .setShortFlag('p')
                .setDefault(CConfig.getInstance().getPlatformHost());
        platform.setHelp("The IP of the CLARA platform.");

        FlaggedOption nLoops = new FlaggedOption(ARG_LOOPS)
                .setStringParser(JSAP.INTEGER_PARSER)
                .setRequired(false)
                .setShortFlag('l')
                .setDefault("1");
        nLoops.setHelp("The number of times that the list of input files should be processed.");

        String claraServices = System.getenv("CLARA_SERVICES");
        String defaultTapeDir ="/mss/hallb/exp/raw";
        String defaultInputDir = claraServices + File.separator + "data" + File.separator + "in";
        String defaultOutputDir = claraServices + File.separator + "data" + File.separator + "out";
        String defaultStageDir = File.separator + "scratch";

        FlaggedOption tapeDir = new FlaggedOption(ARG_TAPE_DIR)
                .setStringParser(JSAP.STRING_PARSER)
                .setRequired(false)
                .setShortFlag('t')
                .setDefault(defaultTapeDir);
        tapeDir.setHelp("The tape directory where from files are cached.");

        FlaggedOption inputDir = new FlaggedOption(ARG_INPUT_DIR)
                .setStringParser(JSAP.STRING_PARSER)
                .setRequired(false)
                .setShortFlag('i')
                .setDefault(defaultInputDir);
        inputDir.setHelp("The input directory where the files to be reconstructed are located.");

        FlaggedOption outputDir = new FlaggedOption(ARG_OUTPUT_DIR)
                .setStringParser(JSAP.STRING_PARSER)
                .setRequired(false)
                .setShortFlag('o')
                .setDefault(defaultOutputDir);
        outputDir.setHelp("The output directory where reconstructed files will be saved.");

        FlaggedOption stageDir = new FlaggedOption(ARG_STAGE_DIR)
                .setStringParser(JSAP.STRING_PARSER)
                .setRequired(false)
                .setShortFlag('s')
                .setDefault(defaultStageDir);
        stageDir.setHelp("The stage directory where the local temporary files will be stored.");

        UnflaggedOption servicesFile = new UnflaggedOption(ARG_SERVICES_FILE)
                .setStringParser(JSAP.STRING_PARSER)
                .setRequired(true);
        servicesFile.setHelp("The YAML file with the reconstruction chain description.");

        UnflaggedOption inputFiles = new UnflaggedOption(ARG_INPUT_FILES)
                .setStringParser(JSAP.STRING_PARSER)
                .setRequired(true);
        inputFiles.setHelp("The file with the list of input files to be reconstructed (one name per line).");

        try {
            jsap.registerParameter(platform);
            jsap.registerParameter(tapeDir);
            jsap.registerParameter(inputDir);
            jsap.registerParameter(outputDir);
            jsap.registerParameter(stageDir);
            jsap.registerParameter(nLoops);
            jsap.registerParameter(servicesFile);
            jsap.registerParameter(inputFiles);
        } catch (JSAPException e) {
            e.printStackTrace();
            System.exit(1);
        }
    }


    /**
     * Constructor.
     *
     * @param platformHost
     *            host of the master DPE (called platform).
     * @param recChain
     *            list of service names in the composition (PDP application).
     * @param inputFiles
     *            list of data files to be processed.
     * @param paths
     *            paths to the several paths were reconstructed files should
     *            be/go.
     * @param loop
     *            the number indicates how many times the list of required data
     *            files will be processed.
     */
    FarmOrchestrator(String platformHost,
                     List<ServiceInfo> recChain,
                     List<String> inputFiles,
                     FarmDirectories paths,
                     int loop) {
        try {
            orchestrator = new ReconstructionOrchestrator(platformHost, "farm_orchestrator");
        } catch (CException e) {
            System.out.println(e.getMessage());
        }
        orchestrator.setReconstructionChain(recChain);

        this.inputFiles = inputFiles;
        this.paths = paths;
        this.processingTimes = loop;

        this.nodes = Collections.newSetFromMap(new ConcurrentHashMap<ReconstructionNode, Boolean>());

        this.nodesSetup = Executors.newSingleThreadExecutor();
    }


    void run() {
        if (orchestrator.isPlatformConnected()) {
            System.out.println("FarmOrchestrator started. Waiting for reconstruction nodes...");
            System.out.println();

            orchestrator.dpeMonitorOn(new DpeReportCB());

            configureTapeManager();
            startTapeManager();

            new Thread(new FileMonitoringWorker(), "file-monitoring-thread").start();
        }
    }


    private void start(ReconstructionNode node) {
        String container = ReconstructionConfigParser.getDefaultContainer();
        String subject = node.dpe.name + "/" + container + "/*";
        try {
            orchestrator.errorMonitorOn(subject, new ErrorHandlerCB(node),false);
        } catch (CException e) {
            System.out.println(e.getMessage());
        }
        System.out.println();
    }


    private void stop(ReconstructionNode node) {
        String container = ReconstructionConfigParser.getDefaultContainer();
        String subject = node.dpe.name + "/" + container + "/*";
        try {
            orchestrator.errorMonitorOff(subject,false);
        } catch (CException e) {
            System.out.println(e.getMessage());
        }
        System.out.println();
    }


    private void end() {
        System.out.println("Processing is complete...");
        clearInputCash();
        nodesSetup.shutdown();
        orchestrator.end();
    }



    /**
     * Callback to detect the birth of a new DPE
     */
    private class DpeReportCB implements IDpeCallBack {

        @Override
        public void monitorCallBack(DpeInfo dpe) {
            ReconstructionNode node = new ReconstructionNode(orchestrator, dpe);
            if (!nodes.contains(node)) {
                nodes.add(node);
                if (orchestrator.checkDpe(dpe.name)) {
                    nodesSetup.execute(new SpawnedNodeWorker(node));
                }
            }
        }
    }



    /**
     * Callback to detect the end of the data processing of an input file
     */
    private class ErrorHandlerCB extends CCallBack {

        private final ReconstructionNode node;

        public ErrorHandlerCB(ReconstructionNode node) {
            this.node = node;
        }


        @Override
        public void monitorCallBack(JioSerial data) {
            String source = data.getExceptionSource();
            String description = data.getDataDescription();
            String host = CUtil.parse4DpeHostName(source);
            int requestId = data.getRequestID();
            if (description.equalsIgnoreCase("End of file")) {
                if (data.getIntObject() == 1) {
                    printAverage();
                    processFinishedFile();
                }
            } else {
                System.err.printf("Error %n%s: %s%n", source, description);
                node.requestEvent(host, requestId, "next-rec");
            }
        }


        private void printAverage() {
            long endTime = System.currentTimeMillis();
            double timePerEvent = (endTime - node.startTime) / (double) node.eventNumber;
            System.out.printf("File %s reconstructed! Average event processing time = %.2f ms%n%n",
                    node.currentInputFileName, timePerEvent);
        }


        private void processFinishedFile() {
            synchronized (lock) {
                finishedFilesCounter++;
                node.closeFiles();
                node.saveOutputFile();
                if (!processingQueue.isEmpty()) {
                    String fileName = processingQueue.removeFirst();
                    processFile(node, fileName);
                } else {
                    stop(node);
                    if (finishedFilesCounter == (inputFiles.size() * processingTimes)) {
                        end();
                    }
                }
            }
        }
    }



    /**
     * Sets up a chain (or composition) of an application on a specified DPE.
     * <p>
     * When a new DPE alive report is received, the setup of that node is done
     * in a background thread by this worker, in order to keep the main
     * {@link DpeReportCB DPE callback} unblocked. Doing the setup directly in
     * the callback may collapse the message queue.
     */
    private class SpawnedNodeWorker implements Runnable {

        private final ReconstructionNode node;

        SpawnedNodeWorker(ReconstructionNode node) {
            this.node = node;
        }


        @Override
        public void run() {
            synchronized (lock) {
                System.out.println("Start processing on " + node.dpe.name + "...");
                node.deploy();
                node.deployChain(node.dpe);
                node.setPaths(paths.inputDirectory, paths.outputDirectory, paths.stageDirectory);
                if (!processingQueue.isEmpty()) {
                    String fileName = processingQueue.removeFirst();
                    start(node);
                    processFile(node, fileName);
                }
            }
        }
    }



    private class FileMonitoringWorker implements Runnable {

        private final BlockingDeque<String> requestedFiles;


        public FileMonitoringWorker() {
            requestedFiles = new LinkedBlockingDeque<String>();
            for (int i = 0; i < processingTimes; ++i) {
                for (String name : inputFiles) {
                    requestedFiles.add(paths.inputDirectory + File.separator + name);
                }
            }
        }


        @Override
        public void run() {
            while (!requestedFiles.isEmpty()) {
                String filePath = requestedFiles.getFirst();
                if (CUtil.fileExist(filePath)) {
                    String fileName = new File(filePath).getName();
                    processingQueue.add(fileName);
                    requestedFiles.removeFirst();
                    System.out.println(filePath + " is cached.");
                }
                CUtil.sleep(100);
            }
        }
    }



    private void processFile(ReconstructionNode node, String inputFile) {
        DpeInfo dpe = node.dpe;
        if (orchestrator.checkDpe(dpe.name)) {
            node.setFiles(inputFile);
            node.openFiles();

            JioSerial configData = new JioSerial(node.currentInputFile);
            for (String recService : orchestrator.getReconstructionServicesNames(node.dpe)) {
                orchestrator.configService(recService, configData,false);
            }

            node.sendEventsToDpe(dpe.name, dpe.cores);
        } else {
            System.out.println("Stop using dead node " + dpe.name + "...");
            stop(node);
            nodes.remove(node);
        }
        System.out.println();
    }


    /**
     * Configures the tape manager service.
     */
    void configureTapeManager() {
        String tm = orchestrator.getServiceNameByEngineName("TapeManager");
        if (!tm.equals(CConstants.udf)) {
            TapeManagerConfig cfg = new TapeManagerConfig(paths.tapeDirectory,
                                                          paths.inputDirectory,
                                                          inputFiles);
            orchestrator.configService(tm, new JioSerial(cfg, MimeType.JOBJECT),false);
        }
    }


    /**
     * Asks tape manager service to start cashing required files.
     */
    void startTapeManager() {
        String tm = orchestrator.getServiceNameByEngineName("TapeManager");
        if (!tm.equals(CConstants.udf)) {
            orchestrator.executeService(tm, new JioSerial(CConstants.COMMAND_START, MimeType.STRING), 1,false);
        }
    }


    /**
     * Asks tape manager service to remove cashed input files from the cash disk.
     */
    void clearInputCash() {
        String tm = orchestrator.getServiceNameByEngineName("TapeManager");
        if (!tm.equals(CConstants.udf)) {
            orchestrator.executeService(tm, new JioSerial(CConstants.COMMAND_CLEAR, MimeType.STRING), 1,false);
        }
    }
}
