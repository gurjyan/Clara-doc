/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */


package org.jlab.clara.examples.orchestrator.check;

import org.jlab.clara.frontend.JOrchestrator;
import org.jlab.clara.system.CException;
import org.jlab.clara.util.CUtil;

/**
 *
 * @author gurjyan
 * @version 3.x
 */

public class ServicesByHostAndContainer extends JOrchestrator {
    /**
     * Constructor
     * Connects to the Clara platform
     *
     */
    public ServicesByHostAndContainer() throws CException {
        super();
    }

    public static void main(String[] args){

        String host        = args[0];
        String container   = args[1];

        // an instance of this class
        ServicesByHostAndContainer dso;
        try {
            dso = new ServicesByHostAndContainer();
            String containerCanonicalName = CUtil.getConCanName(host,container);
            for(String s:dso.getServiceNames(containerCanonicalName)){
                System.out.println(s);
            }
            dso.exit();
        } catch (CException e) {
            System.out.println(e.getMessage());
        }

    }

}
