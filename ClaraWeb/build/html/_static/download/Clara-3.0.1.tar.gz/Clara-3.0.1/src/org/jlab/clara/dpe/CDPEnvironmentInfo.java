/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */
package org.jlab.clara.dpe;

import org.jlab.coda.cMsg.cMsgException;
import org.jlab.coda.cMsg.cMsgMessage;
import org.jlab.coda.cMsg.cMsgPayloadItem;
import org.jlab.clara.constants.CSISConstants;
import org.jlab.clara.util.CLogger;
import org.jlab.clara.util.CUtil;

import java.util.ArrayList;

/**
 * @author gurjyan
 * @version 3.x
 */
public class CDPEnvironmentInfo {

    private final String name;
    private final String host;
    private final String expid;
    private final String description;
    private final String startTime;
    // local instance of the logger object
    private CLogger lg = CLogger.getInstance();



    public CDPEnvironmentInfo(String name, String host, String expid, String description) {
        this.name = name;
        this.host = host;
        this.expid = expid;
        this.description = description;
        this.startTime = CUtil.getCurrentTime();
    }


    public CDPEnvironmentInfo(cMsgMessage msg) throws cMsgException {
        name = getPayloadItem(CSISConstants.CLARA_DPE_NAME, msg).getString();
        expid =getPayloadItem(CSISConstants.CLARA_DPE_EXPID, msg).getString();
        host = getPayloadItem(CSISConstants.CLARA_DPE_HOST, msg).getString();
        description = getPayloadItem(CSISConstants.CLARA_DPE_DESCRIPTION, msg).getString();
        startTime = getPayloadItem(CSISConstants.CLARA_DPE_STARTTIME, msg).getString();
    }


    public cMsgPayloadItem getPayloadItem(String name, cMsgMessage msg) throws cMsgException {
        cMsgPayloadItem item = msg.getPayloadItem(name);
        if (item == null)
            throw new cMsgException("Missing " + name + " payload");
        return item;
    }


    public String getName() {
        return name;
    }


    public String getExpid() {
        return expid;
    }


    public String getHost() {
        return host;
    }


    public String getDescription() {
        return description;
    }


    public String getStartTime() {
        return startTime;
    }


    public ArrayList<cMsgPayloadItem> toPayload(){
        ArrayList<cMsgPayloadItem> o = new ArrayList<cMsgPayloadItem>();
        try {
            o.add(new cMsgPayloadItem(CSISConstants.CLARA_DPE_NAME, name));
            o.add(new cMsgPayloadItem(CSISConstants.CLARA_DPE_HOST, host));
            o.add(new cMsgPayloadItem(CSISConstants.CLARA_DPE_EXPID, expid));
            o.add(new cMsgPayloadItem(CSISConstants.CLARA_DPE_DESCRIPTION, description));
            o.add(new cMsgPayloadItem(CSISConstants.CLARA_DPE_STARTTIME, startTime));
        } catch (cMsgException e) {
            lg.logger.severe(CUtil.stack2str(e));
        }
        return o;
    }
}
