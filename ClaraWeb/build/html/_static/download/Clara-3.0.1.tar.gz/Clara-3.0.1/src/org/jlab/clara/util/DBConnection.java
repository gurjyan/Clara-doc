package org.jlab.clara.util;

import org.jlab.clara.system.CException;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Describe...
 *
 * @author gurjyan
 * @version Clara-3.0.1
 * @date 3/27/14
 */
public class DBConnection {
    // Connection object to the database server.
    private static Connection connection;

    // The particular database to connect to.
    private static String url;

    // The particular database driver.
    private static String driver;

    // The particular database user name.
    private static String user = "dummy";

    // The particular database password.
    private static String password = "";

    // The single instance of this class. */
    private static DBConnection instance;

    // local instance of the logger object
    private static CLogger lg = CLogger.getInstance();

    /**
     * @return true if there is a connection to the database
     *
     */
    public static boolean isConnected() {
        return instance != null;
    }

    /**
     * This method returns the database connection object. There is
     * only one such object - a singleton.
     * @return Connection object
     *
     */
    synchronized public static Connection getConnection() {
        if(isConnected()) {
            return connection;
        } else {
            return null;
        }
    }

    /**
     * This method closes the database connection.
     */
    synchronized public static void closeConnection() {
        if(isConnected()){
            try {connection.close();}
            catch (SQLException ex) {
                lg.logger.severe(CUtil.stack2str(ex));
            }
            instance = null;
            url = null;
            driver = null;
            user = "dummy";
            password = "";
        }
    }

    /**
     * Create a connection to the database specified by the arguments.
     * Only allow this method to be run if the single instance of the
     * database connection has not been made yet. Once the connection
     * is made, it can be closed and later recreated.
     *
     * @param _url URL for the database, i.e. jdbc:msql://mizar.jlab.org:8101/ghexp
     * @param _driver jdbc driver suitable for associated URL, i.e. com.imaginary.sql.msql.MsqlDriver
     * @param _user user name for the database, i.e. any string for msql
     * @param _password password name for the database, i.e. blank string for msql
     * @return <code>true</code> if a new connection to the database was successfully made, or
     *         <code>false</code> if the database connection already exists
     */
    synchronized public static boolean createConnection(String _url, String _driver,
                                                        String _user, String _password)
            throws CException {

        if (isConnected()) {
            return false;
        }
        url    = _url;
        driver = _driver;
        user   = _user;
        password = _password;
        instance = new DBConnection();
        return true;
    }



    private DBConnection() throws CException {

        // Register the Driver
        try {
            Class.forName(driver).newInstance();
        }
        catch (InstantiationException e) {
            throw( new CException(e.getMessage()));
        }
        catch (IllegalAccessException e) {
            throw( new CException(e.getMessage()));
        }
        catch (ClassNotFoundException e) {
            throw( new CException(e.getMessage()));
        }
        // Make connections to the database
        try {
            connection = DriverManager.getConnection(url, user, password);
        }
        catch (SQLException e) {
            throw( new CException(e.getMessage()));
        }
    }

}

