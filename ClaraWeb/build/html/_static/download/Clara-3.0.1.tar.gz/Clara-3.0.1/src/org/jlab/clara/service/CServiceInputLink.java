/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */


package org.jlab.clara.service;

import org.jlab.clara.data.JioSerial;

import java.util.HashMap;
import java.util.Map;

/**
 * @author gurjyan
 * @version 3.x
 */
public class CServiceInputLink
        implements Comparable<CServiceInputLink>
{
    private final String serviceName;
    private final String containerName;
    private final String host;

    private final Map<Integer, JioSerial> receivedData = new HashMap<Integer, JioSerial>();


    public CServiceInputLink(String serviceName, String containerName, String host)
    {
        this.serviceName = serviceName;
        this.containerName = containerName;
        this.host = host;
    }


    public String getContainerName()
    {
        return containerName;
    }


    public String getEngineName()
    {
        return serviceName;
    }


    public String getHost()
    {
        return host;
    }


    public boolean hasData(int requestID)
    {
        return receivedData.containsKey(requestID);
    }


    public void addData(int requestID, JioSerial data)
    {
        receivedData.put(requestID, data);
    }


    public JioSerial getData(int requestId)
    {
        JioSerial data = receivedData.get(requestId);
        receivedData.remove(requestId);
        return data;
    }


    public void clearAllData()
    {
        receivedData.clear();
    }


    @Override
    public int compareTo(CServiceInputLink other)
    {
        return serviceName.compareTo(other.serviceName);
    }


    @Override
    public int hashCode()
    {
        final int prime = 31;
        int result = 1;
        result = prime * result + serviceName.hashCode();
        return result;
    }


    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        CServiceInputLink other = (CServiceInputLink) obj;
        if (serviceName == null) {
            if (other.serviceName != null)
                return false;
        } else if (!serviceName.equals(other.serviceName))
            return false;
        return true;
    }
}
