/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */
package org.jlab.clara.pubsub;

import org.jlab.clara.data.JioSerial;

/**
 * Monitor call back interface.
 * This is the interface that is used by the CCallBack class.
 *
 * @author gurjyan
 * @version 3.x
 */

public interface ICallBack {

    public void monitorCallBack(JioSerial data);
}
