package org.jlab.clara.frontend;

import org.jlab.clara.constants.CConstants;
import org.jlab.clara.constants.CSISConstants;
import org.jlab.clara.data.JioSerial;
import org.jlab.clara.system.CDriver;
import org.jlab.clara.system.CException;
import org.jlab.clara.pubsub.CCallBack;
import org.jlab.clara.service.CServiceRegistration;
import org.jlab.clara.util.CUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Clara user basic API
 *
 * @author gurjyan
 *         Date: 3/17/14 Time: 3:43 PM
 * @version 3.x
 */
public class BaseApi extends CDriver{

    public BaseApi(){
        super();
    }

    public BaseApi(String name){
        super(name);
    }


    /**
     * Returns all registered service canonical names that have
     * a required description keyword in their descriptions.
     * This assumes pub-sub connection/communication to the
     * particular DPE admin service.
     *
     * @param d description keyword
     * @return list of service canonical names
     */
    public ArrayList<String> getServiceNamesByDescription(String d){
        ArrayList<String> al = new ArrayList<String>();
        for(CServiceRegistration sre: getServiceByDescription(d)){
            al.add(sre.getRegistrationName());
        }
        return al;
    }

    /**
     * Returns the name of a service that has a described description keyword
     * in its description.
     * The first service name that matches with the requirement, and is running
     * on a local host will be returned.
     * Otherwise it will return the name of a service that has a minimum load.
     * This assumes pub-sub connection/communication to the
     * particular DPE admin service.
     *
     * @param d description keyword
     * @return  the canonical name of the service
     */
    public String getServiceNameByDescription(String d){
        String n = CConstants.udf;
        double load = Double.MAX_VALUE;
        List<CServiceRegistration> sr = getServiceByDescription(d);
        if(sr!=null && !sr.isEmpty()){
            for(CServiceRegistration sre: sr){
                String tsn = sre.getRegistrationName();
                if(CUtil.parse4DpeHostName(tsn).equals(myConfig.getLocalDpeHost())){
                    return tsn;
                } else {
                    double tl = getServiceLoad(tsn);
                    if(tl < load) {
                        load = tl;
                        n = tsn;
                    }
                }
            }
        }
        return n;
    }

    /**
     * Returns all registered service canonical names that have
     * the required service engine name.
     * This assumes pub-sub connection/communication to the
     * particular DPE admin service.
     *
     * @param e service engine name. This is the name that was given
     * at the interface <code>ICService</coda> implementation.
     * @return the canonical name of the service
     */
    public List<String> getServiceNamesByEngineName(String e){
        List<String> al = new ArrayList<String>();
        for(CServiceRegistration sre: getServiceByEngineName(e)){
            al.add(sre.getRegistrationName());
        }
        return al;
    }

    /**
     * Returns all registered service canonical names that run on
     * the required DPE and container.
     *
     * @param dpeHost host of the DPE
     * @param container service container name
     * @return  List of service names ( canonical names).
     */
    public List<String> getServiceNamesByDpeContainer(String dpeHost, String container){
        List<String> result = new ArrayList<String>();
        List<CServiceRegistration> tmp =  getServiceByHostContainer(dpeHost, container);
        for(CServiceRegistration sr:tmp){
            result.add(sr.getRegistrationName());
        }
        return result;
    }

    /**
     * Returns the name of a service that has a required service engine name.
     * The first service name that matches with the requirement, and is running
     * on a local host will be returned.
     * Otherwise it will return the name of a service that has a minimum load.
     * This assumes pub-sub connection/communication to the
     * particular DPE admin service.
     *
     * @param e service engine name. This is the name that was given
     * at the interface <code>ICService</coda> implementation.
     * @return  the canonical name of the service
     */
    public String getServiceNameByEngineName(String e){
        String n = CConstants.udf;
        double load = Double.MAX_VALUE;
        for(CServiceRegistration sre: getServiceByEngineName(e)){
            String tsn = sre.getRegistrationName();
            if(CUtil.parse4DpeHostName(tsn).equals(myConfig.getLocalDpeHost())){
                return tsn;
            } else {
                double tl = getServiceLoad(tsn);
                if(tl < load) {
                    load = tl;
                    n = tsn;
                }
            }
        }
        return n;
    }

    public boolean configService(String scn, JioSerial data, boolean isGW){
        boolean b = false;
        try {
            if(isGW){
                b = configureServiceGW(scn,data);
            } else {
                b = configureService(scn,data);
            }
        } catch (CException e) {
            System.out.println(e.getMessage());
        }
        return b;
    }

    public void end(){
        try {
            exit();
        } catch (CException e) {
            System.out.println(e.getMessage());
        }
    }

    public boolean executeService(String serviceCanonicalName,
                                  JioSerial data,
                                  int requestId,
                                  boolean isGW){
        boolean b = false;
        try {
            if(isGW){
                b = runServiceGW(serviceCanonicalName, data, requestId);
            } else {
                b = runService(serviceCanonicalName, data, requestId);
            }
        } catch (CException e) {
            System.out.println(e.getMessage());
        }
        return b;
    }

    public JioSerial syncExecuteService(String serviceCanonicalName,
                                        JioSerial data,
                                        int requestId,
                                        int timeout,
                                        boolean isGW) {
        JioSerial res = null;
        try {
            if(isGW){
                res =  syncRunServiceGW(serviceCanonicalName, data, requestId,timeout);
            } else {
                res =  syncRunService(serviceCanonicalName, data, requestId,timeout);
            }
        } catch (CException e) {
            System.out.println(e.getMessage());
        }
        return res;
    }

    public String getPlatformHost(){
        return myConfig.getPlatformHost();
    }

    public String getLocalHost(){
        return myConfig.getLocalDpeHost();
    }

    /**
     * @return the name of a platform (i.e. cloud administration)
     */
    public String getPlatformName(){
        return myConfig.getPlatformName();
    }

}
