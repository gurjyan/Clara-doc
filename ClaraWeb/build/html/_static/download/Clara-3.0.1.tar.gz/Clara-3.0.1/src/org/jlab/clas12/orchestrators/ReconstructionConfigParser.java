/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */
package org.jlab.clas12.orchestrators;

import com.martiansoftware.jsap.*;
import org.jlab.clara.config.CConfig;
import org.jlab.clara.constants.CConstants;
import org.jlab.clara.util.CUtil;
import org.yaml.snakeyaml.Yaml;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * Helper class to read configuration for the standard orchestrators.
 * <p>
 * Currently, the user can set:
 * <ul>
 * <li>The list of services in the reconstruction chain
 * <li>The name of the container for the services
 * <li>The list of I/O and reconstruction nodes
 * <li>The list of input files
 * </ul>
 *
 * The <i>reconstruction services</i> description is provided in a YAML file,
 * which format is the following:
 * <pre>
 * container: my-default # Optional: change default container, otherwise it is $USER
 * services:
 *   - class: org.jlab.clas12.ana.serviceA
 *     name: serviceA
 *   - class: org.jlab.clas12.rec.serviceB
 *     name: serviceB
 *     container: containerB # Optional: change container for this service
 * </pre>
 * By default, all reconstruction and I/O services will be deployed in a
 * container named as the {@code $USER} running the orchestrator. This can be
 * changed by including a {@code container} key with the desired container name.
 * The container can be overwritten for individual services too. There is no
 * need to include I/O services in this file. They are controlled by the
 * orchestrators.
 * <p>
 *
 * The <i>nodes</i> description is also provided as a YAML file, with the
 * following format:
 * <pre>
 * clara-services: /home/user/services # Optional: set value of $CLARA_SERVICES for all nodes
 * input-output:
 *   - name: io-node
 * reconstruction:
 *   - name: rec-node-1
 *     clara-services: /home/u/user/services # Optional: $CLARA_SERVICES in this node
 *     cores: 12
 *   - name: rec-node-2
 *     cores: 32
 *   - name: rec-node-3
 * </pre>
 * Note that the {@code clara-services} and {@code cores} support is experimental.
 *
 * The <i>input files</i> description is just a simple text file with the list
 * of all the input files, one per line:
 * <pre>
 * input-file1.ev
 * input-file2.ev
 * input-file3.ev
 * input-file4.ev
 * </pre>
 *
 * This class also provides a command line interface, to output several parsing
 * and listing cases.
 */
public class ReconstructionConfigParser {

    private static final String defaultContainer = System.getenv("USER");

    public static void main(String[] args) {
        ReconstructionConfigParser parser = new ReconstructionConfigParser();
        if (args.length >= 1) {
            String action = args[0];
            if (action.equals("parse-nodes")) {
                JSAP jsap = new JSAP();
                setNodesArguments(jsap);
                String parseArgs[] = Arrays.copyOfRange(args, 1, args.length);
                JSAPResult config = jsap.parse(parseArgs);
                if (!config.success()) {
                    System.err.println();
                    System.err.println("Usage:  parse-nodes " + jsap.getUsage());
                    System.exit(1);
                }
                boolean printCores = config.getBoolean("print-cores");
                boolean printClaraServices = config.getBoolean("print-clara-services");
                String nodesType = config.getString("nodes-type");
                String configFile = config.getString("config-file");
                List<DpeInfo> dpes = new ArrayList<DpeInfo>();
                if (nodesType.equals("input-output")) {
                    dpes = parser.parseInputOutputNodes(configFile);
                } else {
                    dpes = parser.parseReconstructionNodes(configFile);
                }
                for (DpeInfo dpe : dpes) {
                    System.out.print(dpe.name);
                    if (printCores) System.out.println(" " + dpe.cores);
                    if (printClaraServices) System.out.println(" " + dpe.servicesDir);
                    System.out.println();
                }
            } else if (action.equals("validate-nodes")) {
                if (args.length == 2) {
                    String nodesConfig = args[1];
                    List<DpeInfo> ioDpes = parser.parseInputOutputNodes(nodesConfig);
                    List<DpeInfo> recDpes = parser.parseReconstructionNodes(nodesConfig);
                    if (ioDpes.size() == 0 || recDpes.size() == 0) {
                        System.exit(1);
                    }
                } else {
                    System.err.println("Usage:  validate-nodes <config-file>");
                    System.exit(1);
                }
            } else if (action.equals("platform-host")) {
                System.out.println(CConfig.getInstance().getPlatformHost());
            } else {
                System.err.println("Usage:  parse-nodes | valide-nodes <...>");
                System.exit(1);
            }
        } else {
            System.err.println("Usage:  parse-nodes | valide-nodes <...>");
            System.exit(1);
        }
    }


    public static String getDefaultContainer() {
        return defaultContainer;
    }


    public List<ServiceInfo> parseReconstructionChain(String configFile) {
        List<ServiceInfo> services = new ArrayList<ServiceInfo>();
        try {
            InputStream input = new FileInputStream(new File(configFile));
            Yaml yaml = new Yaml();
            @SuppressWarnings("unchecked")
            Map<String, Object> config = (Map<String, Object>) yaml.load(input);
            @SuppressWarnings("unchecked")
            List<Map<String, String>> sl = (List<Map<String, String>>) config.get("services");
            if (sl == null) {
                throw new RuntimeException("missing list of services");
            }
            for (Map<String, String> s : sl) {
                String serviceName = s.get("class");
                String serviceClass = s.get("name");
                if (serviceName == null || serviceClass == null) {
                    throw new RuntimeException("missing name or class of service");
                }
                services.add(new ServiceInfo(serviceName, defaultContainer, serviceClass));
            }
        } catch (FileNotFoundException e) {
            System.err.println("Error opening services configuration: " + e.getMessage());
        } catch (RuntimeException e) {
            System.err.println("Error parsing services: " + e.getMessage());
            services.clear();
        }
        return services;
    }


    public List<DpeInfo> parseReconstructionNodes(String configFile) {
        return parseNodes(configFile, "reconstruction");
    }


    public List<DpeInfo> parseInputOutputNodes(String configFile) {
        return parseNodes(configFile, "input-output");
    }


    private List<DpeInfo> parseNodes(String configFile, String nodeType) {
        List<DpeInfo> dpes = new ArrayList<DpeInfo>();
        try {
            InputStream input = new FileInputStream(new File(configFile));
            Yaml yaml = new Yaml();
            @SuppressWarnings("unchecked")
            Map<String, Object> config = (Map<String, Object>) yaml.load(input);
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> sl = (List<Map<String, Object>>) config.get(nodeType);
            if (sl == null) {
                throw new RuntimeException("missing list of " + nodeType + " nodes");
            }
            String defaultClaraServices = (String) config.get("clara-services");
            if (defaultClaraServices == null) {
                defaultClaraServices = DpeInfo.defaultClaraServices;
            }
            for (Map<String, Object> s : sl) {
                String dpeName = (String) s.get("name");
                if (dpeName == null) {
                    throw new RuntimeException("missing name of " + nodeType + " node");
                }
                Integer dpeCores = (Integer) s.get("cores");
                if (dpeCores == null) {
                    dpeCores = 0;
                }
                String claraServices = (String) s.get("clara-services");
                if (claraServices == null) {
                    claraServices = defaultClaraServices;
                }
                String dpeIp = CUtil.getIPAddress(dpeName);
                if (dpeIp.equals(CConstants.udf)) {
                    throw new RuntimeException("node name not known");
                }
                dpes.add(new DpeInfo(dpeIp, dpeCores, claraServices));
            }
        } catch (FileNotFoundException e) {
            System.err.println("Error opening nodes configuration: " + e.getMessage());
        } catch (RuntimeException e) {
            System.err.println("Error parsing nodes: " + e.getMessage());
            dpes.clear();
        }
        return dpes;
    }


    public List<String> readInputFiles(String inputFilesList) {
        List<String> files = new ArrayList<String>();
        File file = new File(inputFilesList);
        BufferedReader reader = null;
        Pattern pattern = Pattern.compile("^\\s*#.*$");
        try {
            reader = new BufferedReader(new FileReader(file));
            while (true) {
                String line = reader.readLine();
                if (line == null) // no more lines
                    break;
                line = line.trim();
                if (line.length() == 0) // empty line
                    continue;
                if (pattern.matcher(line).matches()) // commented line
                    continue;
                files.add(line);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            System.err.println("Could not read file " + inputFilesList);
            files.clear();
        } finally {
            try {
                if (reader != null) reader.close();
            } catch (IOException e) {
                System.err.println("Could not close config file.");
            }
        }
        return files;
    }


    private static void setNodesArguments(JSAP jsap) {
        Switch cores = new Switch("print-cores")
                .setLongFlag("with-cores");

        Switch servicesDir = new Switch("print-clara-services")
                .setLongFlag("with-clara-services");

        class DataTypeParser extends com.martiansoftware.jsap.StringParser
        {
            @Override
            public String parse(String arg) throws com.martiansoftware.jsap.ParseException
            {
                if (!arg.equalsIgnoreCase("reconstruction") && !arg.equalsIgnoreCase("input-output"))
                    throw new com.martiansoftware.jsap.ParseException();
                return arg;
            }
        }

        UnflaggedOption nodesType = new UnflaggedOption("nodes-type")
                .setStringParser(new DataTypeParser())
                .setRequired(true);

        UnflaggedOption configFile = new UnflaggedOption("config-file")
                .setStringParser(JSAP.STRING_PARSER)
                .setRequired(true);

        try {
            jsap.registerParameter(cores);
            jsap.registerParameter(servicesDir);
            jsap.registerParameter(nodesType);
            jsap.registerParameter(configFile);
        } catch (JSAPException e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
}
