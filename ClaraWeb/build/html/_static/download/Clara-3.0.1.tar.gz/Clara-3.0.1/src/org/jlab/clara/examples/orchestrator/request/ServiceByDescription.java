/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */


package org.jlab.clara.examples.orchestrator.request;

import org.jlab.clara.constants.CConstants;
import org.jlab.clara.data.JioSerial;
import org.jlab.clara.frontend.JOrchestrator;
import org.jlab.clas12.tools.MimeType;
import org.jlab.clara.system.CException;

/**
 *
 * Finds a service that has a required description keyword in it s description.
 * It returns a service that is local to this orchestrator or
 * the remote service that has the smallest load.
 *
 * @author gurjyan
 * @version 3.x
 */

public class ServiceByDescription extends JOrchestrator {

    /**
     * Constructor
     * Connects to the Clara platform
     *
     */
    public ServiceByDescription() throws CException {
        super();
    }

    public static void main(String[] args) {
        String descKey     = args[0];

        String data;
        if (args.length == 2)
            data = args[1];
        else
            data = "none";

        // an instance of this class
        ServiceByDescription rso = null;
        try {
            rso = new ServiceByDescription();

            // get registration information form the platform normative clas12.services
            rso.requestRegistrationData(1000);

            // get the service canonical name that has a required description keyword
            // in the description.
            String serviceName = rso.getServiceNameByDescription(descKey);
            if(!serviceName.equals(CConstants.udf)){

                System.out.println("Found a service = "+serviceName+"\n");

                // list service information
                System.out.println(rso.getServiceInformation(serviceName));

                // create a request transient data
                JioSerial dataRequest = new JioSerial();
                dataRequest.setData(data, MimeType.STRING);

                // send the request
                System.out.println("\nRequesting the service\n");
                JioSerial dataResponse = rso.syncRunService(serviceName, dataRequest,1,1000);

                // print the response
                System.out.println(dataResponse);

            } else {
                System.out.println("Can not find a service with the " +
                        "specified description keyword.");
            }
            rso.exit();
        } catch (CException e) {
            System.out.println(e.getMessage());
        }
    }
}
