/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */


package org.jlab.clara.system;

import org.jlab.clara.dpe.CDPEnvironmentData;
import org.jlab.clara.dpe.CDPEnvironmentInfo;
import org.jlab.coda.cMsg.*;
import org.jlab.coda.cMsg.cMsgDomain.server.cMsgNameServer;
import org.jlab.clara.platform.CPlatformRegistrar;
import org.jlab.clara.platform.CServiceSpy;
import org.jlab.clara.constants.CConstants;
import org.jlab.clara.constants.CSISConstants;
import org.jlab.clara.container.CSContainerRegistration;
import org.jlab.clara.pubsub.CTrParameter;
import org.jlab.clara.service.CServiceRegistration;
import org.jlab.clara.util.CLogger;
import org.jlab.clara.util.CUtil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author gurjyan
 * @version 3.x
 */
public class CPlatform extends CcMsgDrive {

    // platform registrar object
    public static CPlatformRegistrar registrar;

    private final String startTime;

    private String myName;

    // Map to hold the names and last reported info for every data processing containers
    private ConcurrentHashMap<String, CDPEnvironmentData> myDpeData = new ConcurrentHashMap<String, CDPEnvironmentData>();

    private static boolean isLogging = false;
    public static int severity = 0;

    public static boolean DEBUG;

    // local instance of the logger object
    private static CLogger lg = CLogger.getInstance();

    public static void main(String[] args){
        if(args.length>0 && args[0].equalsIgnoreCase("-debug")){
            DEBUG = true;
        } else if(args.length>0 && args[0].equalsIgnoreCase("-log")){
            if(args.length==2){
                if(args[1].equalsIgnoreCase("error")) severity = 2;
                else if(args[1].equalsIgnoreCase("warning")) severity = 1;
            }
            isLogging = true;
        }
        new CPlatform();
    }

    /**
     * Constructor
     */
    public CPlatform(){
        super();
        myName = myConfig.getPlatformName();

        // start platform registrar service
        registrar = new CPlatformRegistrar();

        // Start platform global pub-sub server
        startPlatformServer();

        // Connect to the platform pub-sub server
        try {
            connect2Platform(myName);
        } catch (CException e) {
            lg.logger.severe(CUtil.stack2str(e));
       }

        if(getPlatformConnection() !=null){
            // Complete platform specific subscriptions
            doSubscriptions();
        } else {
            System.out.println("Severe Error: Platform admin connection exception. Exiting ...");
            System.exit(1);
        }

        startTime = CUtil.getCurrentTime();

        System.out.println("**************************************************");
        System.out.println("*             Clara-3 Platform                 *");
        System.out.println("**************************************************");
        System.out.println("- Name         = "+ myConfig.getPlatformName());
        System.out.println("- Host         = "+ myConfig.getPlatformHost());
        System.out.println("- TCP port     = "+ myConfig.getPlatformTcpPort());
        System.out.println("- UDP port     = "+ myConfig.getPlatformUdpPort());
        System.out.println("- Start time   = "+ startTime);
        System.out.println("**************************************************");

        // start platform administration environment
        new CDPEnvironment(isLogging);

        // start normative gateway service
        new ClGateway();

        // accept heart bits from DPEs
        new WatchDPEReporting().start();

        // periodically broadcast information about all registered service containers
        new ServiceContainerInfoBroadcastT().start();

        // start service communication logging service
        if(isLogging) new CServiceSpy();
    }

    /**
     * Starts Clara platform cMsg server
     */
    private void startPlatformServer(){
        cMsgNameServer platformServer = new cMsgNameServer(
                myConfig.getPlatformTcpPort(),
                myConfig.getPlatformTcpDomainPort(),
                myConfig.getPlatformUdpPort(),
                true,
                true,
                null,
                null,
                null,
                cMsgConstants.debugNone,
                10);
//        platformServer.setName(myConfig.getPlatformDpeName().replace(".", ""));
        platformServer.startServer();

    }

    /**
     * Platform Registration system basic subscriptions
     * @return status of the method execution.
     */
    private boolean doSubscriptions(){
        boolean status = true;
        try {

            // subscribe PlatformRegistration messages from the platform agents
            getPlatformConnection().subscribe(myConfig.getPlatformName(), CSISConstants.PlatformRegistrationRequest, new ServiceRegistrationCB(), null);

            // subscribe messages asking information about the platform
            getPlatformConnection().subscribe(myConfig.getPlatformName(), CSISConstants.PlatformInfoRequest, new PlatformInfoRequestCB(), null);

            // subscribe messages from the data processing environment
            getPlatformConnection().subscribe(myConfig.getPlatformName(), CSISConstants.DPEInfoResponse, new DPEStateCB(), null);


        } catch (cMsgException e) {
            lg.logger.severe(CUtil.stack2str(e));
            status = false;
        }
        return status;
    }



    /************************************************************************
     * Private inner class for responding to messages from clara platform service
     */
    private class ServiceRegistrationCB extends cMsgCallbackAdapter {
        @Override
        public void callback(cMsgMessage msg, Object userObject){
            String type = msg.getType();
            // text is the name of the service container
            String txt = msg.getText();

            // ---- Clara service java container
            if(type.equals(CSISConstants.PlatformRegistrationRequestAddServiceContainer)){
                if(msg.getByteArray()!=null){
                    try {
                        CSContainerRegistration ar = (CSContainerRegistration)CUtil.B2O(msg.getByteArray());

                        if(ar!=null){
//                            System.out.println("CPlatform:Info Registration request from "+ar.getName()+" service container.");
                            registrar.removeServiceContainer(ar.getName());
                            registrar.addServiceContainer(ar);
                        }
                    } catch (IOException e) {
                        lg.logger.severe(CUtil.stack2str(e));
                    } catch (ClassNotFoundException e) {
                        lg.logger.severe(CUtil.stack2str(e));
                    }
                } else {
                    // non java container
                    CSContainerRegistration sc = new CSContainerRegistration();

                    try{
                        // container
                        if(msg.getPayloadItem(CSISConstants.SERVICE_CONTAINER_NAME)!=null){
                            sc.setName(msg.getPayloadItem(CSISConstants.SERVICE_CONTAINER_NAME).getString());
                        }
                        if(msg.getPayloadItem(CSISConstants.SERVICE_CONTAINER_HOST)!=null){
                            sc.setHost(msg.getPayloadItem(CSISConstants.SERVICE_CONTAINER_HOST).getString());
                        }
                        if(msg.getPayloadItem(CSISConstants.SERVICE_CONTAINER_TYPE)!=null){
                            sc.setType(msg.getPayloadItem(CSISConstants.SERVICE_CONTAINER_TYPE).getString());
                        }
                        if(msg.getPayloadItem(CSISConstants.SERVICE_CONTAINER_STARTTIME)!=null){
                            sc.setStartTime(msg.getPayloadItem(CSISConstants.SERVICE_CONTAINER_STARTTIME).getString());
                        }
                        if(msg.getPayloadItem(CSISConstants.SERVICE_CONTAINER_LOAD)!=null){
                            sc.setLoad(msg.getPayloadItem(CSISConstants.SERVICE_CONTAINER_LOAD).getDouble());
                        }
                        if(msg.getPayloadItem(CSISConstants.SERVICE_CONTAINER_STATUS)!=null){
                            sc.setLoad(msg.getPayloadItem(CSISConstants.SERVICE_CONTAINER_STATUS).getInt());
                        }

                        // service
                        String[] sNames        = null;
                        String[] sDescriptions = null;
                        String[] sAuthors      =null;
                        String[] sVersions     = null;
                        String[] sLanguages    = null;
                        if(msg.getPayloadItem(CSISConstants.SERVICE_NAMES)!=null){
                            sNames = msg.getPayloadItem(CSISConstants.SERVICE_NAMES).getStringArray();
                        }
                        if(msg.getPayloadItem(CSISConstants.SERVICE_DESCRIPTIONS)!=null){
                            sDescriptions = msg.getPayloadItem(CSISConstants.SERVICE_DESCRIPTIONS).getStringArray();
                        }
                        if(msg.getPayloadItem(CSISConstants.SERVICE_AUTHORS)!=null){
                            sAuthors = msg.getPayloadItem(CSISConstants.SERVICE_AUTHORS).getStringArray();
                        }
                        if(msg.getPayloadItem(CSISConstants.SERVICE_VERSIONS)!=null){
                            sVersions = msg.getPayloadItem(CSISConstants.SERVICE_VERSIONS).getStringArray();
                        }
                        if(msg.getPayloadItem(CSISConstants.SERVICE_LANGUAGES)!=null){
                            sLanguages = msg.getPayloadItem(CSISConstants.SERVICE_LANGUAGES).getStringArray();
                        }

                        if(sNames!=null && sDescriptions!=null && sAuthors!=null && sVersions!=null && sLanguages!=null &&
                                (sNames.length + sDescriptions.length + sAuthors.length + sVersions.length + sLanguages.length)/4 == sNames.length ){
                            for (int i = 0; i<sNames.length;i++){
                                CServiceRegistration sr = new CServiceRegistration();
                                sr.setRegistrationName(sNames[i]);
                                sr.setAuthor(sAuthors[i]);
                                sr.setDescription(sDescriptions[i]);
                                sr.setLanguage(sLanguages[i]);
                                sr.setVersion(sVersions[i]);
                                // add service to the container
                                sc.addService(sr);
                            }
                        }
                        registrar.addServiceContainer(sc);
                    } catch (cMsgException e) {
                        lg.logger.severe(CUtil.stack2str(e));
                    }
                }
            } else if(type.trim().equals(CSISConstants.PlatformRegistrationRequestServiceContainerLoadUpdate)){
                if(registrar.getServiceContainerRepository().containsKey(txt)){
                    if(msg.getPayloadItem(CSISConstants.SERVICE_CONTAINER_LOAD)!=null){
                        try {
                            registrar.getServiceContainerRepository().get(txt).setLoad(msg.getPayloadItem(CSISConstants.SERVICE_CONTAINER_LOAD).getDouble());
                        } catch (cMsgException e) {
                            lg.logger.severe(CUtil.stack2str(e));
                        }
                    }
                    if(msg.getPayloadItem(CSISConstants.SERVICE_CONTAINER_STATUS)!=null){
                        try {
                            registrar.getServiceContainerRepository().get(txt).setStatus(msg.getPayloadItem(CSISConstants.SERVICE_CONTAINER_STATUS).getInt());
                        } catch (cMsgException e) {
                            lg.logger.severe(CUtil.stack2str(e));
                        }
                    }
                }
            } else if(type.equals(CSISConstants.PlatformRegistrationRequestRemoveServiceContainer)){
//                System.out.println("CPlatform:Info Request to remove "+txt+" service container.");
                registrar.removeServiceContainer(txt);
            } else if(type.equals(CSISConstants.PlatformRegistrationRequestAddClaraDPE)){
                try {

                    CDPEnvironmentInfo dpeInfo = new CDPEnvironmentInfo(msg);
                    String dpeName = dpeInfo.getName();
                    CDPEnvironmentData dpeData = myDpeData.get(dpeName);
                    if (dpeData != null) {
                        clearDpeRegistration(dpeName, dpeData);
                    }
                    registrar.addClaraDpe(dpeInfo);
                } catch (cMsgException e) {
                    lg.logger.severe(CUtil.stack2str(e));
                }
            } else if(type.equals(CSISConstants.PlatformRegistrationRequestUpdateClaraDPE)){
                try {
                    registrar.addClaraDpe(new CDPEnvironmentInfo(msg));
                } catch (cMsgException e) {
                    lg.logger.severe(CUtil.stack2str(e));
                }
            } else if(type.equals(CSISConstants.PlatformRegistrationRequestRemoveDPE)){
                registrar.removeClaraDpe(txt);
            }
        }
    }


    /***********************************************************************
     * Private inner class for accepting state messages from containers
     */
    private class DPEStateCB extends cMsgCallbackAdapter {
        @Override
        public void callback(cMsgMessage msg, Object userObject){
            String type = msg.getType();
            String cName = msg.getSender();
            CDPEnvironmentData cd = null;
            if (type.equals(CSISConstants.DPEInfoResponseStatus)){
                try {
                    cd = (CDPEnvironmentData)CUtil.B2O(msg.getByteArray());
                } catch (IOException e) {
                    lg.logger.severe(CUtil.stack2str(e));
                } catch (ClassNotFoundException e) {
                    lg.logger.severe(CUtil.stack2str(e));
                }
                if(cd!=null){
                    if(myDpeData.containsKey(cName)){
                        myDpeData.get(cName).setCurrentReportingTime(new Date().getTime());
                        myDpeData.get(cName).setServiceContainers(cd.getServiceContainers());
                    }else {
                        myDpeData.put(cName,cd);
                        System.out.println("Info-"+CUtil.getCurrentTime()+
                                ": DPE = "+cName+" is up on the host = "+msg.getSenderHost());
                    }
                }
            }
        }
    }

    /***********************************************************************
     * Private inner class for responding to the platform info request messages
     */
    private class PlatformInfoRequestCB extends cMsgCallbackAdapter {
        @Override
        public void callback(cMsgMessage msg, Object userObject){
            String type = msg.getType();
            String requester = msg.getSender();

            // agent name in question is passed through text field
            if(type.equals(CSISConstants.PlatformInfoRequestName)){
                CTrParameter p = new CTrParameter();
                p.setConnection(getPlatformConnection());
                p.setSubject(requester);
                p.setType(CSISConstants.PlatformInfoResponseName);
                p.setText(myConfig.getPlatformName());
                try {
                    send(p);
                } catch (CException e) {
                    lg.logger.severe(CUtil.stack2str(e));
                }
            } else if (type.equals(CSISConstants.PlatformInfoRequestHost)){
                CTrParameter p = new CTrParameter();
                p.setConnection(getPlatformConnection());
                p.setSubject(requester);
                p.setType(CSISConstants.PlatformInfoResponseHost);
                p.setText(myConfig.getPlatformName());
                try {
                    send(p);
                } catch (CException e) {
                    lg.logger.severe(CUtil.stack2str(e));
                }

            }  else if (type.equals(CSISConstants.PlatformInfoRequestPort)){
                CTrParameter p = new CTrParameter();
                p.setConnection(getPlatformConnection());
                p.setSubject(requester);
                p.setType(CSISConstants.PlatformInfoResponsePort);
                p.setText(myConfig.getPlatformName());
                try {
                    send(p);
                } catch (CException e) {
                    lg.logger.severe(CUtil.stack2str(e));
                }

            } else if (type.equals(CSISConstants.PlatformInfoRequestStartTime)){
                CTrParameter p = new CTrParameter();
                p.setConnection(getPlatformConnection());
                p.setSubject(requester);
                p.setType(CSISConstants.PlatformInfoResponseStartTime);
                p.setText(startTime);
                try {
                    send(p);
                } catch (CException e) {
                    lg.logger.severe(CUtil.stack2str(e));
                }

            }  else if (type.equals(CSISConstants.PlatformInfoRequestIsRegistered)){
                if(msg.isGetRequest()){
                    try {
                        cMsgMessage mr = msg.response();
                        mr.setSubject(CConstants.udf);
                        mr.setType(CConstants.udf);
                        if(msg.getText()!=null){
                            String n = msg.getText();
                            if(registrar.getClaraDpeInfoMap().containsKey(n)){
                                mr.setText(CConstants.yes);
                            } else {
                                mr.setText(CConstants.no);
                            }
                        }
                        getPlatformConnection().send(mr);
                    } catch (cMsgException e) {
                        lg.logger.severe(CUtil.stack2str(e));
                    }
                }

            } else if (type.equals(CSISConstants.PlatformInfoRequestRegisteredDPEs)){
                if(msg.isGetRequest()){
                    try {
                        cMsgMessage mr = msg.response();
                        mr.setSubject(CConstants.udf);
                        mr.setType(CConstants.udf);
                        ArrayList<String> serList = new ArrayList<String>();
                        for(String name:registrar.getClaraDpeInfoMap().keySet()){
                            serList.add(name);
                        }
                        cMsgPayloadItem pi = new cMsgPayloadItem("dpes",serList.toArray(new String[serList.size()]));
                        mr.addPayloadItem(pi);
                        getPlatformConnection().send(mr);
                    } catch (cMsgException e) {
                        lg.logger.severe(CUtil.stack2str(e));
                    }
                }
            } else if (type.equals(CSISConstants.PlatformInfoRequestRegisteredServices)){
                if(msg.isGetRequest()){
                    try {
                        cMsgMessage mr = msg.response();
                        mr.setSubject(CConstants.udf);
                        mr.setType(CConstants.udf);
                        ArrayList<String> serList = new ArrayList<String>();
                        for(String name:registrar.getServiceContainerRepository().keySet()){
                            serList.add(name);
                        }
                        cMsgPayloadItem pi = new cMsgPayloadItem("services",serList.toArray(new String[serList.size()]));
                        mr.addPayloadItem(pi);
                        getPlatformConnection().send(mr);
                    } catch (cMsgException e) {
                        lg.logger.severe(CUtil.stack2str(e));
                    }
                }
            } else if (type.equals(CSISConstants.PlatformInfoRequestServiceInfo)){
                if(msg.isGetRequest()){
                    try {
                        cMsgMessage mr = msg.response();
                        mr.setSubject(CConstants.udf);
                        mr.setType(CConstants.udf);
                        String containerName = msg.getPayloadItem("containerName").getString();
                        String serviceName = msg.getPayloadItem("serviceName").getString();
                        if(containerName!=null && serviceName!=null){
                            for(String s:registrar.getServiceContainerRepository().keySet())System.out.println(s);
                            if(registrar.getServiceContainerRepository().containsKey(containerName)){
                                CSContainerRegistration cr = registrar.getServiceContainerRepository().get(containerName);
                                if(cr.getServices()!=null){
                                    for(CServiceRegistration sr: cr.getServices()){
                                        if(sr.getRegistrationName().equals(serviceName)){
                                            cMsgPayloadItem de = new cMsgPayloadItem("description",sr.getDescription());
                                            // here because container and service is the same for C++ service
                                            cMsgPayloadItem st = new cMsgPayloadItem("status",cr.getStatus());
                                            mr.addPayloadItem(de);
                                            mr.addPayloadItem(st);
                                        }
                                    }
                                }
                            }
                        }
                        getPlatformConnection().send(mr);
                    } catch (cMsgException e) {
                        lg.logger.severe(CUtil.stack2str(e));
                    }
                }
            }

        }
    }


    private void clearDpeRegistration(String dpeName, CDPEnvironmentData dpeData) {
        ConcurrentHashMap<String, CSContainerRegistration> containerRepository = registrar.getServiceContainerRepository();

        for (String containerName: dpeData.getServiceContainers()) {
            if(containerName!=null){
                CSContainerRegistration containerRegistration = containerRepository.get(containerName);
                if(containerRegistration!=null){
                    for (CServiceRegistration serviceRegistration : containerRegistration.getServices()) {
                        String serviceName = serviceRegistration.getRegistrationName();
                        System.out.println("CPlatform Warning: Removing service "+ serviceName);
                        registrar.removeService(containerName, serviceName);

                    }
                } else {
                    System.out.println("Warning: incomplete service registration detected.");
                }
                System.out.println("CPlatform Warning: Removing container " + containerName);
                if(containerRegistration!=null){
                    registrar.removeServiceContainer(containerRegistration.getName());
                }
            } else {
                System.out.println("Warning: incomplete container registration detected.");
            }
        }

        registrar.removeClaraDpe(dpeName);
        myDpeData.remove(dpeName);
    }


    /**
     * Periodically report information about all registered service containers
     */
    private class ServiceContainerInfoBroadcastT extends Thread{
        public boolean isRunning = true;
        @Override
        public void run(){
            while(isRunning){
                CTrParameter p = new CTrParameter();
                p.setConnection(getPlatformConnection());
                p.setSubject(myName);
                p.setType(CSISConstants.PlatformInfoServiceContainers);
                p.setData(registrar.getServiceContainerRepository());
                p.setPayloadItems(registrar.getServiceContainersPL());
                try {
                    send(p);
                } catch (CException e) {
                    lg.logger.severe(CUtil.stack2str(e));
                }
                CUtil.sleep(1000);
            }
        }
    }

    /***************************************************************
     * DPE health watching thread.
     */
    private class WatchDPEReporting extends Thread {
        public boolean isRunning = true;

        private final int w = 3000; // in msec.
        private final int e = 10000;

        @Override
        public void run() {
            super.run();
            do{
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    lg.logger.severe(CUtil.stack2str(e));
                }
                long checkTime = new Date().getTime();
                for(String dpeName: myDpeData.keySet()){
                    CDPEnvironmentData dpeData = myDpeData.get(dpeName);
                    long crt = dpeData.getCurrentReportingTime();
                    if(crt>0){
                        long rt = checkTime - crt;

                        // store time since last reporting into the map
                        dpeData.setTimeSinceLastReporting(rt);

                        if(rt > w){
                            // Warning
                            System.out.println("CPlatform:WARNING No response from the DPE "+dpeName+" "+rt/1000 +" sec.");
                        }
                        if (rt > e){
                            // Ask explicit container state
                            CTrParameter p = new CTrParameter();
                            p.setConnection(getPlatformConnection());
                            p.setSubject(dpeName);
                            p.setType(CSISConstants.DPEInfoRequestState);
                            p.setTimeout(3000);
                            cMsgMessage mSgc = null;
                            try {
                                mSgc = syncSend(p);
                            } catch (CException e1) {
                                lg.logger.severe(CUtil.stack2str(e1));
                            }
                            if(mSgc==null || mSgc.getText()==null || mSgc.getText().startsWith("failed")){

                                // DPE is dead
                                System.out.println("CPlatform:ERROR DPE "+dpeName+" is dead!");

                                clearDpeRegistration(dpeName, dpeData);
                            }
                        }
                    }
                }
            } while(isRunning);
            isRunning = false;
        }
    }

}
