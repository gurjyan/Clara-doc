package org.jlab.clara.util;

/**
 * Describe...
 *
 * @author gurjyan
 * @version Clara-3.0.1
 * @date 3/27/14
 */
public class StdIO {
    private String stdio = "";
    private String stderr = "";
    private int exitValue = 0;

    public String getStdio() {
        return stdio;
    }

    public void setStdio(String stdio) {
        this.stdio = stdio;
    }

    public String getStderr() {
        return stderr;
    }

    public void setStderr(String stderr) {
        this.stderr = stderr;
    }

    public int getExitValue() {
        return exitValue;
    }

    public void setExitValue(int exitValue) {
        this.exitValue = exitValue;
    }
}
