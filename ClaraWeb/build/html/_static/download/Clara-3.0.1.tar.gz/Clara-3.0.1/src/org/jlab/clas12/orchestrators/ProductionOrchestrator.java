/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */
package org.jlab.clas12.orchestrators;

import com.martiansoftware.jsap.*;
import org.jlab.clara.config.CConfig;
import org.jlab.clara.data.JioSerial;
import org.jlab.clara.pubsub.CCallBack;
import org.jlab.clas12.orchestrators.ReconstructionOrchestrator.IDpeCallBack;
import org.jlab.clara.system.CException;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

/**
 * Runs production jobs.
 */
public class ProductionOrchestrator {

    private ReconstructionOrchestrator orchestrator;
    private final ReconstructionNode ioNode;

    /* List of DPEs processing the reconstruction chain */
    private final Set<DpeInfo> reconstructionDpes;

    /* Input and output files */
    private final String inputFileName;
    private final String outputFileName;

    /* How many times the input file will be processed */
    private int processingTimes = 1;
    private int processingCounter = 1;

    private int frequency = 1000;


    private final Object lock = new Object();


    public static void main(String[] args) {
        /* Check the arguments */
        JSAP jsap = new JSAP();
        setArguments(jsap);
        JSAPResult config = jsap.parse(args);
        if (!config.success()) {
            System.err.printf("Usage:%n%n  production-orchestrator %s%n%n%n", jsap.getUsage());
            System.err.println(jsap.getHelp());
            System.exit(1);
        }

        String platform = config.getString(ARG_PLATFORM);
        String configFile = config.getString(ARG_SERVICES_FILE);
        String input = config.getString(ARG_INPUT_FILE);
        String output = config.getString(ARG_OUTPUT_FILE);
        int processings = config.getInt(ARG_LOOPS);

        ReconstructionConfigParser parser = new ReconstructionConfigParser();
        List<ServiceInfo> recChain = parser.parseReconstructionChain(configFile);
        if (recChain.isEmpty()) {
            System.err.println("Could not configure reconstruction chain");
            System.exit(1);
        }

        if (processings <= 0) {
            System.err.printf("Error: bad number of times to loop (%s)%n", args[3]);
            System.exit(1);
        }

        ProductionOrchestrator po = new ProductionOrchestrator(platform, recChain, input, output, processings);
        po.run();
    }


    private static final String ARG_PLATFORM = "platform";
    private static final String ARG_LOOPS = "loops";
    private static final String ARG_SERVICES_FILE = "servicesFile";
    private static final String ARG_INPUT_FILE = "inputFile";
    private static final String ARG_OUTPUT_FILE = "outputFile";

    private static void setArguments(JSAP jsap) {

        FlaggedOption platform = new FlaggedOption(ARG_PLATFORM)
                .setStringParser(JSAP.STRING_PARSER)
                .setRequired(false)
                .setShortFlag('p')
                .setDefault(CConfig.getInstance().getPlatformHost());
        platform.setHelp("The IP of the CLARA platform.");

        FlaggedOption nLoops = new FlaggedOption(ARG_LOOPS)
                .setStringParser(JSAP.INTEGER_PARSER)
                .setRequired(false)
                .setShortFlag('l')
                .setDefault("1");
        nLoops.setHelp("The number of times that the EVIO input file should be processed.");

        UnflaggedOption servicesFile = new UnflaggedOption(ARG_SERVICES_FILE)
                .setStringParser(JSAP.STRING_PARSER)
                .setRequired(true);
        servicesFile.setHelp("The YAML file with the reconstruction chain description.");

        UnflaggedOption inputFile = new UnflaggedOption(ARG_INPUT_FILE)
                .setStringParser(JSAP.STRING_PARSER)
                .setRequired(true);
        inputFile.setHelp("The EVIO input file to be reconstructed.");

        UnflaggedOption outputFile = new UnflaggedOption(ARG_OUTPUT_FILE)
                .setStringParser(JSAP.STRING_PARSER)
                .setRequired(true);
        outputFile.setHelp("The EVIO output file where reconstructed events will be saved.");

        try {
            jsap.registerParameter(platform);
            jsap.registerParameter(nLoops);
            jsap.registerParameter(servicesFile);
            jsap.registerParameter(inputFile);
            jsap.registerParameter(outputFile);
        } catch (JSAPException e) {
            e.printStackTrace();
            System.exit(1);
        }
    }


    ProductionOrchestrator(String platformHost,
                           List<ServiceInfo> services,
                           String inputFile,
                           String outputFile,
                           int processings) {
        try {
            orchestrator = new ReconstructionOrchestrator(platformHost, "prod_orchestrator");
        } catch (CException e) {
            System.out.println(e.getMessage());
        }
        orchestrator.setReconstructionChain(services);

        inputFileName = inputFile;
        outputFileName = outputFile;
        processingTimes = processings;

        DpeInfo ioDpe = new DpeInfo(orchestrator.getPlatformHost(), 0, DpeInfo.defaultClaraServices);
        ioNode = new ReconstructionNode(orchestrator, ioDpe);

        reconstructionDpes = new HashSet<DpeInfo>();
    }


    void run() {
        if (check()) {
            setup();
            start();
            orchestrator.dpeMonitorOn(new DpeReportCB());
        }
    }


    private boolean check() {
        if (!orchestrator.isPlatformConnected()) {
            System.err.println("Error: could not connect to CLARA cloud.");
            return false;
        }
        boolean status = true;
        if (!orchestrator.checkDpe(ioNode.dpe.name)) {
            System.err.println("Error: local DPE is not alive (needed for I/O).");
            status = false;
        }
        if (status == false) {
            orchestrator.end();
        }
        return status;
    }


    private void setup() {
        ioNode.deploy();
        ioNode.setFiles(inputFileName, outputFileName);
        ioNode.openFiles(frequency);
    }


    private void start() {
        try {
            orchestrator.errorMonitorOn(ioNode.readerName, new ErrorHandlerCB(),false);
            orchestrator.dataMonitorOn(ioNode.writerName, new DataHandlerCB(),false);
        } catch (CException e) {
            System.out.println(e.getMessage());
        }

        System.out.println();
    }


    private void stop() {
        try {
            orchestrator.errorMonitorOff(ioNode.readerName,false);
            orchestrator.dataMonitorOff(ioNode.writerName,false);
        } catch (CException e) {
            System.out.println(e.getMessage());
        }
    }


    private void end() {
        System.out.println("Processing is complete...");
        orchestrator.end();
    }


    private void processFile() {
        Iterator<DpeInfo> i = reconstructionDpes.iterator();
        while (i.hasNext()) {
            DpeInfo dpe = i.next();
            if (orchestrator.checkDpe(dpe.name)) {
                ioNode.sendEventsToDpe(dpe.name, dpe.cores);
            } else {
                System.out.println("Stop using dead node " + dpe.name + "...");
                i.remove();
            }
        }
    }



    private class DpeReportCB implements IDpeCallBack {

        @Override
        public void monitorCallBack(DpeInfo dpe) {
            synchronized (lock) {
                if (!reconstructionDpes.contains(dpe)) {
                    reconstructionDpes.add(dpe);
                    System.out.println("Start processing on " + dpe.name + "...");
                    ioNode.deployChain(dpe);
                    ioNode.sendEventsToDpe(dpe.name, dpe.cores);
                }
            }
        }
    }



    private class DataHandlerCB extends CCallBack {

        @Override
        public void monitorCallBack(JioSerial data) {
            long endTime = System.currentTimeMillis();
            ioNode.eventNumber += frequency;
            double timePerEvent = (endTime - ioNode.startTime) / (double) ioNode.eventNumber;
            System.out.printf("Average event processing time = %.2f ms%n", timePerEvent);
        }
    }



    private class ErrorHandlerCB extends CCallBack {

        @Override
        public void monitorCallBack(JioSerial data) {
            String source = data.getExceptionSource();
            String description = data.getDataDescription();
            if (description.equalsIgnoreCase("End of file")) {
                synchronized (lock) {
                    if (data.getIntObject() == 1) {
                        if (processingCounter < processingTimes) {
                            processingCounter++;
                            ioNode.openFiles(frequency);
                            processFile();
                        } else {
                            ioNode.closeFiles();
                            stop();
                            end();
                        }
                    }
                }
            } else {
                System.err.printf("Error %n%s: %s%n", source, description);
            }
        }
    }
}
