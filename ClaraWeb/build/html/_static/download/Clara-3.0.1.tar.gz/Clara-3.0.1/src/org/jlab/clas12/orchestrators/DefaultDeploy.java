/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */
package org.jlab.clas12.orchestrators;

import com.martiansoftware.jsap.*;
import org.jlab.clara.config.CConfig;
import org.jlab.clara.system.CException;
import org.jlab.clara.util.CUtil;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Deploys and links the I/O and reconstruction services in the specified nodes.
 * The services and nodes are described in YAML files provided by the user. The
 * {@link ReconstructionConfigParser} class takes cares of parsing those files.
 * <p>
 * This orchestrator is called by the {@code setup-chain} command of the
 * {@code default-orchestrator} script distributed with Clara. Check the
 * {@link #setArguments} method for a full description of the input
 * parameters.
 * <p>
 * In the simple usage, the user pass a {@code services.yaml} file with the
 * reconstruction chain description. A {@code nodes.yaml} file is created
 * automatically, with localhost used for both I/O and reconstruction.
 * In the advanced usage, the user passes his own {@code nodes.yaml} file with
 * the list of I/O and reconstruction nodes. Note that there is no support for
 * more than one I/O node.
 * <p>
 * In both cases, the reconstruction services will be linked in the same order
 * they appear in the configuration file. When setting multiple reconstruction
 * nodes, the I/O services will be linked to all those nodes.
 */
public class DefaultDeploy {

    private ReconstructionOrchestrator orchestrator = null;

    private final List<DpeInfo> reconstructionNodes;
    private final List<DpeInfo> inputOutputNodes;


    public static void main(String[] args) {
        /* Check the arguments */
        JSAP jsap = new JSAP();
        setArguments(jsap);
        JSAPResult config = jsap.parse(args);
        if (!config.success()) {
            System.err.printf("Usage:%n%n  default-orchestrator setup-chain %s%n%n%n", jsap.getUsage());
            System.err.print(jsap.getHelp());
            System.exit(1);
        }

        String platform = config.getString(ARG_PLATFORM);
        String nodesConfig = config.getString(ARG_NODES_FILE);
        String servicesConfig = config.getString(ARG_SERVICES_FILE);

        if (nodesConfig == null) {
            try {
                String node = "localhost";
                if (config.getBoolean(ARG_REMOTE_IO)) {
                    node = platform;
                }
                nodesConfig = getDefaultNodesFile(node);
            } catch (IOException e) {
                System.err.println(e.getMessage());
                System.exit(1);
            }
        }

        ReconstructionConfigParser parser = new ReconstructionConfigParser();
        List<DpeInfo> ioNodes = parser.parseInputOutputNodes(nodesConfig);
        List<DpeInfo> recNodes = parser.parseReconstructionNodes(nodesConfig);

        if (ioNodes.isEmpty() || recNodes.isEmpty()) {
            System.err.println("Could not configure nodes");
            System.exit(1);
        }

        List<ServiceInfo> recChain = parser.parseReconstructionChain(servicesConfig);
        if (recChain.isEmpty()) {
            System.err.println("Could not configure reconstruction chain");
            System.exit(1);
        }

        DefaultDeploy deploy = new DefaultDeploy(platform, ioNodes, recNodes, recChain);
        deploy.run();
    }


    private static final String ARG_PLATFORM = "platform";
    private static final String ARG_NODES_FILE = "nodesFile";
    private static final String ARG_REMOTE_IO = "remote";
    private static final String ARG_SERVICES_FILE = "servicesFile";

    private static void setArguments(JSAP jsap) {

        FlaggedOption platform = new FlaggedOption(ARG_PLATFORM)
                .setStringParser(JSAP.STRING_PARSER)
                .setRequired(false)
                .setShortFlag('p')
                .setDefault(CConfig.getInstance().getPlatformHost());
        platform.setHelp("The IP of the CLARA platform.");

        Switch remoteIO = new Switch(ARG_REMOTE_IO)
                .setShortFlag('r');
        remoteIO.setHelp("Use the remote platform for I/O and reconstruction.");

        FlaggedOption nodesFile = new FlaggedOption(ARG_NODES_FILE)
                .setStringParser(JSAP.STRING_PARSER)
                .setRequired(false)
                .setShortFlag('n');
        nodesFile.setHelp("The YAML file with the nodes description.");

        UnflaggedOption servicesFile = new UnflaggedOption(ARG_SERVICES_FILE)
                .setStringParser(JSAP.STRING_PARSER)
                .setRequired(true);
        servicesFile.setHelp("The YAML file with the reconstruction chain description.");

        try {
            jsap.registerParameter(platform);
            jsap.registerParameter(remoteIO);
            jsap.registerParameter(nodesFile);
            jsap.registerParameter(servicesFile);
        } catch (JSAPException e) {
            e.printStackTrace();
            System.exit(1);
        }
    }


    DefaultDeploy(String platformHost,
                  List<DpeInfo> ioNodes,
                  List<DpeInfo> recNodes,
                  List<ServiceInfo> recChain) {
        try {
            orchestrator = new ReconstructionOrchestrator(platformHost, "default_deployer");
        } catch (CException e) {
            System.out.println(e.getMessage());
        }
        orchestrator.setReconstructionChain(recChain);
        inputOutputNodes = ioNodes;
        reconstructionNodes = recNodes;
    }


    void run() {
        if (check()) {
            deploy();
            link();
            orchestrator.end();
        }
    }


    private boolean check() {
        if (!orchestrator.isPlatformConnected()) {
            System.err.println("Error: could not connect to CLARA cloud.");
                orchestrator.end();
            return false;
        }
        boolean status = true;
        Set<DpeInfo> allNodes = new HashSet<DpeInfo>();
        allNodes.addAll(inputOutputNodes);
        allNodes.addAll(reconstructionNodes);
        for (DpeInfo dpe : allNodes) {
            if (!orchestrator.checkDpe(dpe.name)) {
                System.err.printf("Error: DPE %s is not alive%n", dpe.name);
                status = false;
            }
        }
        if (status == false) {
                orchestrator.end();
        }
        return status;
    }


    private void deploy() {
        for (DpeInfo dpe : inputOutputNodes) {
            System.out.println("Deploying I/O services in " + dpe.name);
            orchestrator.deployInputOutputServices(dpe);
        }
        for (DpeInfo dpe : reconstructionNodes) {
            System.out.println("Deploying reconstruction chain in " + dpe.name);
            orchestrator.deployReconstructionChain(dpe);
        }
        CUtil.sleep(1000);
    }


    private void link() {
        for (DpeInfo dpe : reconstructionNodes) {
            System.out.println("Linking reconstruction chain in " + dpe.name);
            orchestrator.linkReconstructionChain(dpe);
            CUtil.sleep(500);
        }
        for (DpeInfo ioDpe : inputOutputNodes) {
            for (DpeInfo recDpe : reconstructionNodes) {
                System.out.println("Linking I/O in " + ioDpe.name + " to reconstruction chain in " + recDpe.name);
                orchestrator.linkInputOutputWithReconstructionChain(ioDpe, recDpe);
            }
            System.out.println("Closing I/O loop in " + ioDpe.name);
            orchestrator.linkInputOutputServices(ioDpe);
            CUtil.sleep(500);
        }
    }


    private static String getDefaultNodesFile(String node) throws IOException {
        File temp = File.createTempFile("tempfile", ".tmp");
        temp.deleteOnExit();
        BufferedWriter bw = new BufferedWriter(new FileWriter(temp));
        bw.write("---\n");
        bw.write("reconstruction:\n");
        bw.write("  - name: " + node + "\n");
        bw.write("input-output:\n");
        bw.write("  - name: " + node + "\n");
        bw.close();
        return temp.getAbsolutePath();
    }
}
