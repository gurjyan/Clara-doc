/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */

package org.jlab.clara.frontend;

import org.jlab.clara.constants.CSISConstants;
import org.jlab.clara.pubsub.CCallBack;
import org.jlab.clara.system.CException;
import org.jlab.clara.data.JioSerial;
import org.jlab.clas12.tools.property.JPropertyList;
import org.jlab.coda.cMsg.*;
import org.jlab.clara.pubsub.ICallBack;
import org.jlab.clara.util.CLogger;
import org.jlab.clara.util.CUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * @author gurjyan
 * @version 3.x
 */
public class JOrchestrator extends BaseApi {

    private cMsgSubscriptionHandle dpeBirthM;

    private String myName;
    // local instance of the logger object
    private static CLogger lg = CLogger.getInstance();

    /**
     * Constructor
     * Connects to the CLARA platform specifying it's name for registration.
     * The name is used by the platform registration and administrative services
     * to assign priority to an application (i.e. orchestrator).
     * Attempts to connect first to the local DPE.
     * It will print warning message in case local DPE is not active.
     */
    protected JOrchestrator() throws CException {
        super();
        myName = getClientName();
        connect2Platform(myName);
    }

    /**
     * Constructor
     * Connects to the CLARA platform specifying it's name for registration.
     * The name is used by the platform registration and administrative services
     * to assign priority to an application (i.e. orchestrator).
     * Attempts to connect first to the local DPE.
     * It will print warning message in case local DPE is not active.
     * @param name of this orchestrator
     */
    protected JOrchestrator(String name) throws CException {
        super(name);
        myName = name;
        connect2Platform(myName);
    }

    /**
     * Constructor
     * Connects to the CLARA platform on a specified host.
     * Attempts to connect first to the local DPE.
     * It will print warning message in case local DPE is not active.
     *
     * @param platformHost  host name of the platform
     * @param name of this orchestrator
     */
    protected JOrchestrator(String platformHost, String name) throws CException {
        super(name);
        myName = name;
        connect2Dpe(myName, platformHost);
    }

    /**
     * Subscribes error messages of the particular service
     * This assumes pub-sub connection/communication to the
     * particular DPE admin service.
     *
     * @param serviceName canonical name of a service
     * @param callBack class extending {@link CCallBack}
     *                 where data from the monitored service will be available.
     * @param isGW     if true request is sent to the gateway service of the DPE
     * @return status of the operation
     */
    public boolean errorMonitorOn(String serviceName, CCallBack callBack, boolean isGW) throws CException {
        if(isGW){
            return serviceMonitorOnGW(serviceName, serviceName, CSISConstants.EXCEPTION_REPORT, callBack);
        } else {
            return serviceMonitorOn(serviceName, serviceName, CSISConstants.EXCEPTION_REPORT, callBack);
        }
    }

    /**
     * Stops receiving error messages of the particular service.
     * This assumes pub-sub connection/communication to the
     * particular DPE admin service.
     *
     * @param serviceName canonical name of a service
     * @param isGW     if true request is sent to the gateway service of the DPE
     * @return status of the operation
     */
    public boolean errorMonitorOff(String serviceName, boolean isGW) throws CException {
        if(isGW){
            return serviceMonitorOffGW(serviceName, serviceName, CSISConstants.EXCEPTION_REPORT);
        } else {
            return serviceMonitorOff(serviceName, serviceName, CSISConstants.EXCEPTION_REPORT);
        }
    }

    /**
     * Subscribes warning messages of the particular service
     * This assumes pub-sub connection/communication to the
     * particular DPE admin service.
     *
     * @param serviceName canonical name of a service
     * @param callBack class extending {@link CCallBack}
     *                 where data from the monitored service will be available.
     * @param isGW     if true request is sent to the gateway service of the DPE
     * @return status of the operation
     */
    public boolean warningMonitorOn(String serviceName, CCallBack callBack, boolean isGW) throws CException {
        if(isGW){
            return serviceMonitorOnGW(serviceName, serviceName, CSISConstants.WARNING_REPORT, callBack);
        } else {
            return serviceMonitorOn(serviceName, serviceName, CSISConstants.WARNING_REPORT, callBack);
        }
    }

    /**
     * Stops receiving warning messages of the particular service.
     * This assumes pub-sub connection/communication to the
     * particular DPE admin service.
     *
     * @param serviceName canonical name of a service
     * @param isGW     if true request is sent to the gateway service of the DPE
     * @return status of the operation
     */
    public boolean warningMonitorOff(String serviceName, boolean isGW) throws CException {
        if(isGW){
            return serviceMonitorOffGW(serviceName, serviceName, CSISConstants.WARNING_REPORT);
        } else {
            return serviceMonitorOff(serviceName, serviceName, CSISConstants.WARNING_REPORT);
        }
    }

    /**
     * Subscribes done messages of the particular service
     * This assumes pub-sub connection/communication to the
     * particular DPE admin service.
     *
     * @param serviceName canonical name of a service
     * @param callBack class extending {@link CCallBack}
     *                 where data from the monitored service will be available.
     * @param isGW     if true request is sent to the gateway service of the DPE
     * @return status of the operation
     */
    public boolean infoMonitorOn(String serviceName, CCallBack callBack, boolean isGW) throws CException {
        if(isGW){
            return serviceMonitorOnGW(serviceName, serviceName, CSISConstants.DONE_REPORT, callBack);
        } else {
            return serviceMonitorOn(serviceName, serviceName, CSISConstants.DONE_REPORT, callBack);
        }
    }

    /**
     * Stops receiving done messages of the particular service.
     * This assumes pub-sub connection/communication to the
     * particular DPE admin service.
     *
     * @param serviceName canonical name of a service
     * @param isGW     if true request is sent to the gateway service of the DPE
     * @return status of the operation
     */
    public boolean infoMonitorOff(String serviceName, boolean isGW) throws CException {
        if(isGW){
            return serviceMonitorOffGW(serviceName, serviceName, CSISConstants.DONE_REPORT);
        } else {
            return serviceMonitorOff(serviceName, serviceName, CSISConstants.DONE_REPORT);
        }
    }

    /**
     * Subscribes output data of the particular service
     * This assumes pub-sub connection/communication to the
     * particular DPE admin service.
     *
     * @param serviceName canonical name of a service
     * @param callBack class extending {@link CCallBack}
     *                 where data from the monitored service will be available.
     * @param isGW     if true request is sent to the gateway service of the DPE
     * @return status of the operation
     */
    public boolean dataMonitorOn(String serviceName, CCallBack callBack, boolean isGW) throws CException {
        if(isGW){
            return serviceMonitorOnGW(serviceName, serviceName, CSISConstants.DATA_REPORT, callBack);
        } else {
            return serviceMonitorOn(serviceName, serviceName, CSISConstants.DATA_REPORT, callBack);
        }
    }

    /**
     * Stops receiving output data of the particular service.
     * This assumes pub-sub connection/communication to the
     * particular DPE admin service.
     *
     * @param serviceName canonical name of a service
     * @param isGW     if true request is sent to the gateway service of the DPE
     * @return status of the operation
     */
    public boolean dataMonitorOff(String serviceName, boolean isGW) throws CException {
        if(isGW){
            return serviceMonitorOffGW(serviceName, serviceName, CSISConstants.DATA_REPORT);
        } else {
            return serviceMonitorOff(serviceName, serviceName, CSISConstants.DATA_REPORT);
        }
    }

    /**
     * Subscribes to error messages generated by all services, anywhere in the platform.
     * This assumes pub-sub communication/connection to the platform master DPE.

     * @param callBack class extending {@link org.jlab.coda.cMsg.cMsgCallbackAdapter}
     *                 where data from the monitored service will be available.
     */
    public void errorAllMonitorOn(CCallBack callBack) throws CException {
        subscribePlatform("*", CSISConstants.EXCEPTION_REPORT, callBack);
    }

    /**
     * Stops receiving error messages from services
     */
    public void errorAllMonitorOff() throws CException {
        unsubscribePlatform("*", CSISConstants.EXCEPTION_REPORT);
    }

    /**
     * Subscribes to warning messages generated by all services, anywhere in the platform.
     * This assumes pub-sub communication/connection to the platform master DPE.

     * @param callBack class extending {@link org.jlab.coda.cMsg.cMsgCallbackAdapter}
     *                 where data from the monitored service will be available.
     */
    public void warningAllMonitorOn(CCallBack callBack) throws CException {
        subscribePlatform("*", CSISConstants.WARNING_REPORT, callBack);
    }

    /**
     * Stops receiving warning messages from services
     */
    public void warningAllMonitorOff() throws CException {
        unsubscribePlatform("*", CSISConstants.WARNING_REPORT);
    }


    /**
     * Monitor the periodic "alive" report of the DPEs.
     * The report data consists of a property-list with the following values:
     * <ul>
     * <li>"host": the IP of the node where the DPE is running.</li>
     * <li>"cores": the number of cores in the node.</li>
     * <li>"clara-services": the {@code $CLARA_SERVICES} variable used by the DPE.<li>
     * </ul>
     * @param callback the user callback object
     */
    public void dpeMonitorOn(ICallBack callback) throws CException{
        try {
            DpeCallbackAdapter dpeCallback = new DpeCallbackAdapter(callback);
            dpeBirthM = getPlatformConnection().subscribe("dpe", "report", dpeCallback, null);

            //@todo this is for CPlatformScheduler communications
//            dpeBirthM = platformConnection.subscribe("dpe_forwarded", "report", dpeCallback, null);
//            dpeBirthM = platformConnection.subscribe(getMyName(), "dpeReport", dpeCallback, null);

        } catch (cMsgException e) {
            throw new CException(e.getMessage());
        }
    }

    /**
     * Stops monitoring cloud DPEs
     */
    public void dpeMonitorOff() throws CException{
        try {
            getPlatformConnection().unsubscribe(dpeBirthM);
        } catch (cMsgException e) {
            throw new CException(e.getMessage());
        }
    }


    /**
     * Returns the list of IP of active DPEs of the platform.
     * This is the result of sync request to (pulling) platform registry service
     *
     * @return list containing DPE host IP names
     */
    public List<String> getDpeHosts(int timeout) throws CException {
        List<String> result = new ArrayList<String>();
        List<String> dpn = getDpeNames(timeout);
        if(dpn!=null && dpn.size()>0){
            for(String s:dpn){
                result.add(s.substring(0,s.lastIndexOf("_admin")));
            }
        } else {
            throw new CException("No registered DPE's were found.");
        }
        return result;
    }


    /**
     * Tells a particular DPE to gracefully exit
     * This is a sync request to a particular DPE with 1sec. timeout
     *
     * @param host of a DPE
     */
    public void exitDpe(String host) throws CException {
        if(isDpeActive(host, 3000)){
            removeDpe(host);
        }
    }


    /**
     * Remove all established links of a specified service.
     * This assumes pub-sub connection/communication to the
     * particular DPE admin service.
     *
     * @param serviceCanonicalName canonical name of the service
     * @param isGW request is sent to the gateway service of a DPE
     */
    public boolean unLinkAll(String serviceCanonicalName, boolean isGW) throws CException {
        boolean b = false;
        for(String s:getLinks(serviceCanonicalName,3000)){
            if(isGW){
                b = unChainServicesGW(serviceCanonicalName, s);
            } else {
                b = unChainServices(serviceCanonicalName, s);
            }
        }
        return b;
    }

    public boolean linkServices(String service1, String service2, boolean isGW) throws CException {
        boolean b;
        if(isGW){
            b = chainServicesGW(service1, service2);
        } else {
            b = chainServices(service1, service2);
        }
        return b;
    }

    public boolean unLinkServices(String service1, String service2, boolean isGW) throws CException {
        boolean b;
        if(isGW){
            b = unChainServicesGW(service1, service2);
        } else {
            b = unChainServices(service1, service2);
        }
        return b;
    }

    /**
     * Deploys a service engine as a service on a specified
     * container and a DPE. This assumes pub-sub
     * connection/communication to the particular DPE admin service.
     * prints message with information about the status of the operation.
     *
     *
     * @param host
     *            the host of a DPE where the service will be deployed
     * @param container
     *            the container name where the service will be deployed
     * @param engineClass
     *            the service class name in the Java case
     *            (e.g. <code>examples.clas12.services.EvioFileReaderService</code>),
     *            or the service name in the C++ case
     *            (e.g. <code>EvioFileReaderService</code> if the library name is
     *            <code>libEvioFileReaderService.so</code>)
     * @param type
     *            the type of the service, "java" or "cpp"
     */
    public void deploy(String host,
                       String container,
                       String engineClass,
                       String type,
                       boolean isGW) throws CException {

        // get textual representation of the host IP address
        String hostIP = CUtil.getIPAddress(host);

        // container canonical name
        String conCanName = CUtil.getConCanName(host,container);

        // get registration information form the platform normative clas12.services
        requestRegistrationData(3000);

        // request starting a container synchronously
        if (!syncCreateContainer(hostIP, container, type,3000)) {
            throw new CException("Failed to create a service container on the host = "+host);
        }

        // get registration information form the platform normative clas12.services
        requestRegistrationData(3000);

        if(isContainerRunning(conCanName)){
            // start a service on the specified container if it is not already deployed

            if(isGW){
                if (!createContainerGW(hostIP, container, type)) {
                    throw new CException("Failed to create a service container on the host = "+host);
                }
            } else {
                if(!addService(hostIP, container, engineClass)){
                    throw new CException("Failed to create a service on the container = "+conCanName);
                }
            }
        } else {
            throw new CException ("Container = "+conCanName+" is not registered");
        }
    }



    private static class DpeCallbackAdapter extends cMsgCallbackAdapter {

        final ICallBack callback;


        public DpeCallbackAdapter(ICallBack callback) {
            this.callback = callback;
        }


        @Override
        public void callback(cMsgMessage msg, Object userObject) {
            try {
                String dpeHost = msg.getPayloadItem("host").getString();
                Integer dpeCores = msg.getPayloadItem("cores").getInt();

                // XXX: temporary workaround for old DPEs
                String dpeServices = "";
                cMsgPayloadItem dpeServicesItem = msg.getPayloadItem("clara-services");
                if (dpeServicesItem != null) {
                    dpeServices = dpeServicesItem.getString();
                }

                JPropertyList pl = new JPropertyList();
                pl.addTailProperty("host", dpeHost);
                pl.addTailProperty("cores", dpeCores.toString());
                pl.addTailProperty("clara-services", dpeServices);
                JioSerial data = new JioSerial(pl);

                callback.monitorCallBack(data);
            } catch (cMsgException e) {
                lg.logger.severe(CUtil.stack2str(e));
            }
        }
    }
}
