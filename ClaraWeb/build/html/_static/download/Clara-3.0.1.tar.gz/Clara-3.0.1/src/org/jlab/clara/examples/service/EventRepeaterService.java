/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */


package org.jlab.clara.examples.service;


import org.jlab.clara.constants.CConstants;
import org.jlab.clara.data.JioSerial;
import org.jlab.clara.frontend.JService;
import org.jlab.coda.jevio.EvioEvent;
import org.jlab.coda.jevio.EvioException;
import org.jlab.coda.jevio.EvioReader;
import org.jlab.clara.util.CUtil;

import java.io.IOException;

public class EventRepeaterService extends JService {

    private EvioEvent event;

    // stores file IO error. no error = null
    private String openingError;

    protected EventRepeaterService(String name) {
        super(name);
    }

    @Override
    public void configure(JioSerial data) {
        try {
            String filename = CUtil.getFileName(data.getStringObject());
            EvioReader reader = new EvioReader(filename);
            event = reader.parseNextEvent();
            openingError = "no error";
        } catch (IOException e) {
            openingError = e.toString();
            e.printStackTrace();
        } catch (EvioException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    @Override
    public JioSerial execute(JioSerial data) {
        if(event == null){
            JioSerial out = new JioSerial(CConstants.REJECT);
            out.setStatus(CConstants.error);
            out.setLanguage(CConstants.LANG_JAVA);
            if(openingError == null){
                out.setDataDescription("file not specified");
            } else {
                out.setDataDescription(openingError);
            }
            return out;
        }

        if(data.getStringObject().equals("get-events-remaining")){
            JioSerial out = new JioSerial(10000);
            out.setDataDescription("number-of-events-remaining");
            out.setLanguage(CConstants.LANG_JAVA);

            return out;

        }

        JioSerial out = new JioSerial(event.clone()); //clone to avoid reusing the same object (avoid concurrent modification!)
        out.setLanguage(CConstants.LANG_JAVA);
        return out;

    }

    @Override
    public JioSerial execute(JioSerial[] data) {
        return null;
    }

    @Override
    public void destruct() {
        event = null;
    }

    @Override
    public String getName() {
        return "RepeatEvio";
    }

    @Override
    public String getAuthor() {
        return "Sebouh Paul";
    }

    @Override
    public String getDescription() {
        return "Reads evio events from file and returns them";
    }

    @Override
    public String getVersion() {
        return "4.0";
    }

    @Override
    public String getLanguage() {
        return CConstants.LANG_JAVA;
    }

}
