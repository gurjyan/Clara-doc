/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */


package org.jlab.clara.system;

import org.jlab.clara.container.CSContainerRegistration;
import org.jlab.clara.data.CShareDataRep;
import org.jlab.clara.data.JioSerial;
import org.jlab.clas12.tools.MimeType;
import org.jlab.coda.cMsg.*;
import org.jlab.clara.service.*;
import org.jlab.clara.constants.CConstants;
import org.jlab.clara.constants.CSISConstants;
import org.jlab.clara.pubsub.CTrParameter;
import org.jlab.clara.util.CClassLoader;
import org.jlab.clara.util.CLogger;
import org.jlab.clara.util.CUtil;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.*;

/**
 * @author gurjyan
 * @version 2
 */

public class CServiceContainer extends CDriver {

    // registration information of this component
    private CSContainerRegistration myRegistrationInfo = new CSContainerRegistration();

    // the map holds the information of the service running in this container
    private ConcurrentHashMap<String, CServiceInfo> myServices = new ConcurrentHashMap<String, CServiceInfo>();

    // holds the number of cMsg requests to this agent
    private volatile int cMsgRequests;

    // indicates the number of requests to this container
    private double myLoad;

    // subscription handler that handles control requests to this container
    private cMsgSubscriptionHandle controlCbHandler;

    // thread that periodically reports to the platform
    private ReportLoadThread reportLoadThread;

    // directory where service engines are located
    private String serviceEngineLocation = CConstants.udf;

    // service worker thread pool
    private ThreadPoolExecutor serviceWorkerThreadPool;

    // platform reporting interval (5sec)
    private int loadReportingInterval = 5000;

    //stores the name of the service that is required to broadcast service result
    private String nextEventBroadcast = "undefined";

    // the canonical name of this container
    private String myName;

    // local instance of the logger object
    private static CLogger lg = CLogger.getInstance();

    // cMsg specific connections
    private cMsg myPlatformConnection;
    private cMsg myLocalDPEConnection;


    /**
     * Constructor does cMsg connect to the DPE (local) pub-sub server
     * @param name of the service
     * @param threadPoolInitialSize number of pre-created threads in the thread pool
     */
    public CServiceContainer(String name, int threadPoolInitialSize) throws CException {
        super(name);

        // service container name is constructed as host/container_given_name
        myName = name;

        // connect to platform
        Object con = connect2Platform(myName);
        if(con instanceof cMsg) myPlatformConnection = (cMsg)con;
        addConnection(myConfig.getPlatformHost(),myPlatformConnection);

        // connect to local DPE
        Object con1 = connect2LocalDpe(myName);
        if(con instanceof cMsg) myLocalDPEConnection = (cMsg)con;

        addConnection(myConfig.getLocalDpeHost(),myLocalDPEConnection);

        // get user service engine directory
        serviceEngineLocation = System.getenv("CLARA_SERVICES");
        if(serviceEngineLocation ==null) {
            System.out.println("ERROR: ServiceEngine dir is not defined.");
        }

        // fill my registration information
        myRegistrationInfo.setName(myName);
        myRegistrationInfo.setHost(myConfig.getLocalDpeHost());
        myRegistrationInfo.setType(CSISConstants.CONTAINER_TYPE_JAVA);
        myRegistrationInfo.setStartTime(CUtil.getCurrentTime());

        // send registration request to the platform
        CTrParameter p = new CTrParameter();
        p.setConnection(myPlatformConnection);
        p.setType(CSISConstants.PlatformRegistrationRequestAddServiceContainer);
        p.setData(myRegistrationInfo);

        if(isLocalDpeConnected()){

            // subscribe container control messages
            subscribe();

            // start load reporting thread
            reportLoadThread = new ReportLoadThread(loadReportingInterval);
            reportLoadThread.start();

            // Create thread pool. Wait 1 min before terminating
            // extra (more than 1) unused threads. Overflow tasks spawn independent
            // threads.
            serviceWorkerThreadPool =
                    new ThreadPoolExecutor(threadPoolInitialSize, 700, 10L, TimeUnit.SECONDS,
                            new SynchronousQueue<Runnable>(),
                            new RejectHandler());


            // send to platform
            if(send(p)){
                System.out.println(myName+ " registered with the platform at "+CUtil.getCurrentTime());
            }

        } else {
            String em = "Error: Problem starting service container = "+myName+"." +
                    " Cannot connect to the DPE pub-sub server.";
            System.err.println(em);
            throw new CException(em);
        }
    }

    /**
     * Exits gracefully this service container
     */
    public void scExit() throws CException{
        // stop reporting thread
        if(reportLoadThread!=null) {
            reportLoadThread.isRunning=false;
        }

        // clear all internal maps
        myServices.clear();

        // ask platform to remove the service container registration
        CTrParameter p = new CTrParameter();
        p.setConnection(myPlatformConnection);
        p.setType(CSISConstants.PlatformRegistrationRequestRemoveServiceContainer);
        p.setText(myName);

        send(p);

        if(controlCbHandler!=null){
            unsubscribePlatform(controlCbHandler.getSubject(),controlCbHandler.getType());
        }

        // disconnect from a local pub-sub server
        localDpeDisconnect();

        // disconnect from the platform
        platformDisconnect();

        myRegistrationInfo = null;
        myServices         = null;
        controlCbHandler   = null;
        reportLoadThread   = null;

        serviceWorkerThreadPool.shutdownNow();

        // parent exit
        exit();
        System.gc();
    }

    /**
     * Gets the load of the service container.
     * Note this is sum over all service in the container
     * @return int load
     */
    public double getLoad(){
        return myLoad;
    }

    /**
     * Service subscription for control messages
     */
    private void subscribe() throws CException{
        if(myLocalDPEConnection instanceof cMsg){

            try {
            controlCbHandler = myLocalDPEConnection.subscribe(
                    myName,
                    CSISConstants.ServiceControlRequest,
                    new ServiceControlCB(), null);
        } catch (cMsgException e) {
            throw new CException(e.getMessage());
        }
        }
    }

    /**
     * Method adds service to this container.
     * ClaraServiceContainer can have multiple service.
     * N.B. the name of the service will be constructed as
     * dpe_host_name/service_container_name/service_engine_name
     *
     * @param engine        implementing object
     * @return              status of service registration with the platform service.
     */
    private synchronized boolean addService(ICService engine) throws CException {
        boolean stat = false;
        boolean found = false;
        String author      = CConstants.udf;
        String description = CConstants.udf;
        String version     = CConstants.udf;
        if(engine!=null && engine.getName()!=null){
            if(engine.getAuthor()!=null)author = engine.getAuthor();
            if(engine.getDescription()!=null)description = engine.getDescription();
            if(engine.getVersion()!=null)version = engine.getVersion();


            // define the name of the service
            String sName = myName+"/"+engine.getName();

            // create service registration object
            CServiceRegistration ser = new CServiceRegistration();
            ser.setRegistrationName(sName);
            ser.setDescription(description);
            ser.setAuthor(author);
            ser.setVersion(version);
            ser.setLanguage(CConstants.LANG_JAVA);

            // remove previous (local) registration information for this service (if any)
            for(CServiceRegistration c: myRegistrationInfo.getServices()){
                if(c.getRegistrationName().equals(sName)){
                    myRegistrationInfo.removeService(c);
                    myServices.remove(sName);
                    found = true;
                    break;
                }
            }

            // add this service name as a shared memory receiver
            // (i.e. indicates that this service is in the same JVM as this container)
            CShareDataRep.addReceiver(sName);
            myRegistrationInfo.addService(ser);
            CServiceInfo sInfo = new CServiceInfo(engine);
            myServices.put(sName, sInfo);

            // update container registration information
            // (we have a new service in this container) with the platform
            // registrar service
            CTrParameter p = new CTrParameter();
            p.setConnection(myPlatformConnection);
            p.setType(CSISConstants.PlatformRegistrationRequestAddServiceContainer);
            p.setData(myRegistrationInfo);

            stat = send(p);

            if(stat && !found){
                System.out.println(sName+ " registered with the platform at "+CUtil.getCurrentTime());
            } else if(stat && found){
                System.out.println(sName+ " re-registered with the platform at "+CUtil.getCurrentTime());
            }
        }
        return stat;
    }

    /**
     * Removes the service from the container as well as updates container
     * registration info with the platform registration service
     *
     * @param    name canonical name of the service to be removed
     * @return   status of the operation
     */
    private synchronized boolean removeMyService(String name) throws CException {

        // locate this service in the local registration
        for(CServiceRegistration ser: myRegistrationInfo.getServices()){
            if(ser.getRegistrationName().equals(name)){

                // call the destruct method of the user engine
                ICService localServiceEngine = myServices.get(name).getEngine();
                localServiceEngine.destruct();

                // remove it from the local registry
                myRegistrationInfo.removeService(ser);
                myServices.remove(name);
                break;
            }
        }

        // update container registration information
        // (we have a new service in this container) on the platform
        CTrParameter p = new CTrParameter();
        p.setConnection(myPlatformConnection);
        p.setType(CSISConstants.PlatformRegistrationRequestAddServiceContainer);
        p.setData(myRegistrationInfo);

        // send the message
        return send(p);
    }

    /**
     * This method adds inputs to the service. This means that the service will be executed only
     * after getting data from all registered input services.
     *
     * @param localServiceName the name of the local service
     * @param remoteServiceName  remote service name
     */
    private synchronized void addInput(String localServiceName,
                                       String remoteServiceName){

        CServiceInfo localServiceInfo = myServices.get(localServiceName);
        if (localServiceInfo != null) {
            CServiceInputLink input = new CServiceInputLink(
                    remoteServiceName,
                    CUtil.parse4ContainerName(remoteServiceName),
                    CUtil.parse4DpeHostName(remoteServiceName));
            if (localServiceInfo.addInput(input)) {
                System.out.println(myName + " INFO: " +
                        remoteServiceName + " added to the inputs of " +
                        localServiceName);
            }
        }
    }

    /**
     * This method removes inputs from the service.
     *
     * @param localServiceName the name of the local service
     * @param remoteServiceName  remote service name
     */
    private synchronized void removeInput(String localServiceName, String remoteServiceName){

        CServiceInfo localServiceInfo = myServices.get(localServiceName);
        if (localServiceInfo != null) {
            CServiceInputLink input = new CServiceInputLink(
                    remoteServiceName,
                    CUtil.parse4ContainerName(remoteServiceName),
                    CUtil.parse4DpeHostName(remoteServiceName));
            if (localServiceInfo.removeInput(input)) {
                System.out.println(myName + " INFO: " +
                        remoteServiceName + " removed from the inputs of " +
                        localServiceName);
            }
        }
    }

    /**
     * This method is called after a request to daisy chain with other service
     *
     * @param localServiceName the name of the local service
     * @param remoteServiceName  remote service name
     */
    private synchronized void _linkService(String localServiceName,
                                           String remoteServiceName) throws CException {

        CServiceInfo localServiceInfo = myServices.get(localServiceName);
        if (localServiceInfo != null) {
            String remoteContainerName = CUtil.parse4ContainerName(remoteServiceName);
            String remoteHost = CUtil.parse4DpeHostName(remoteServiceName);

            CServiceOutputLink output = new CServiceOutputLink(remoteServiceName,
                    remoteContainerName,
                    remoteHost);
            if (localServiceInfo.addOutput(output)) {
                if(remoteHost.equals(myConfig.getPlatformHost())) {
                    addConnection(remoteHost,myPlatformConnection);
                } else if (getConnection(remoteHost) == null) {
                    addConnection(remoteHost,getConnection(remoteHost));
                }
                System.out.println(myName + " INFO: created link " +
                        localServiceName + " -> " + remoteServiceName);
            }
        }
    }

    /**
     * This method is called after a request to break
     * association between two service (brake the link)
     *
     * @param localServiceName the name of the local service
     * @param remoteServiceName  remote service name
     */
    private synchronized void _unLinkService(String localServiceName,
                                             String remoteServiceName) throws CException {

        CServiceInfo localServiceInfo = myServices.get(localServiceName);
        if (localServiceInfo != null) {
            String remoteContainerName = CUtil.parse4ContainerName(remoteServiceName);
            String remoteHost = CUtil.parse4DpeHostName(remoteServiceName);

            CServiceOutputLink output = new CServiceOutputLink(remoteServiceName,
                    remoteContainerName,
                    remoteHost);
            if (localServiceInfo.removeOutput(output)) {
                if (!remoteHost.equals(myConfig.getLocalDpeHost())) {
                    int count = 0;
                    for(CServiceOutputLink ssl: localServiceInfo.getOutputs()){
                        if(ssl.getHost().equals(remoteHost)){
                            count++;
                        }
                    }
                    if (count == 0) {
                        removeConnection(remoteHost);
                    }
                }
                System.out.println(myName + " INFO: removed link " +
                        localServiceName + " -> " + remoteServiceName);
            }
        }
    }

    /**
     * Execute requested local service and send the
     * result as an input to all services described
     * in the link schema.
     * This is what works in a callback initiated thread...
     *
     * @param    serviceName local service canonical name
     * @param    msg input to the local service
     * @param    inShared shows that the input data is in the shared memory
     */
    private void _executeService(String serviceName, cMsgMessage msg, boolean inShared){
        String dataDestination;
        String dataBroadcast;
        boolean isDataBroadcasted = false;
        String doneBroadcast;
        String requestingServiceName           = null;
        int    requestingServiceRequestId      = 0;
        JioSerial data;

        // find the local service by name
        CServiceInfo serviceInfo = myServices.get(serviceName);
        if (serviceInfo != null) {

            // get requested service interface details
            // this is used to create payload items describing the sender
            ICService localService = serviceInfo.getEngine();

            // get the requesting (input) service information from the message
            try {
                if(msg.getPayloadItem(CSISConstants.SERVICE_NAME)!=null){
                    requestingServiceName           = msg.getPayloadItem(CSISConstants.SERVICE_NAME).getString();
                }
                if(msg.getPayloadItem(CSISConstants.SERVICE_REQUEST_ID)!=null){
                    requestingServiceRequestId      = msg.getPayloadItem(CSISConstants.SERVICE_REQUEST_ID).getInt();
                }
            } catch (cMsgException e) {
                lg.logger.severe(CUtil.stack2str(e));
            }

            System.out.println(myName+ " INFO: executing " + serviceName +
                    " by the request from "+ requestingServiceName +
                    ", id = "+ requestingServiceRequestId +", shared = "+inShared+"\n");

            if(requestingServiceName!=null && requestingServiceRequestId>0) {

                if (inShared) {
                    // get data from the shared memory
                    data = CShareDataRep.getInputData(serviceName, requestingServiceName, requestingServiceRequestId);
                } else {
                    // data is in the message.
                    data = new JioSerial(msg);
                }

                // here is the input data
                if(data!=null){

                    //*** get data destination specification in case service has multiple links
                    //*** to other services
                    dataDestination  = data.getDataDestination();
                    doneBroadcast    = data.getDoneBroadcast();
                    dataBroadcast    = data.getDataBroadcast();

                    // service execution result data object
                    JioSerial result = null;

                    // find all services that are linked to the input to this requested local service
                    Set<CServiceInputLink> inputs =  serviceInfo.getInputs();

                    // synchronized multi-input case, when service needs all inputs to execute it's service engine.
                    if(inputs.size() > 0){
                        // create requesting service link object
                        CServiceInputLink sl = new CServiceInputLink(
                                requestingServiceName,
                                CUtil.parse4ContainerName(requestingServiceName),
                                CUtil.parse4DpeHostName(requestingServiceName));
                        int r = 0;
                        synchronized(this){

                            // look all registered input service registered for the requested
                            // local service and see if they already reported with this request ID
                            for(CServiceInputLink si:inputs){

                                // increment count of reports in the case ID matches
                                if(si.hasData(requestingServiceRequestId)) {
                                    r++;
                                } else {

                                    // store the data and the request id for this input service
                                    if(si.equals(sl)){
                                        si.addData(requestingServiceRequestId, data);
                                        r++;
                                    }
                                }
                            }
                        }

                        // if number of reports is equal to the registered number of input service
                        if(r>=inputs.size()){

                            // this builds an array of data to be sent for execution by this local service
                            JioSerial[] inData = new JioSerial[inputs.size()];
                            int i = 0;
                            for (CServiceInputLink s : inputs) {
                                inData[i++] = s.getData(requestingServiceRequestId);
                            }

                            // execute multiple input local service
                            try{
                                result = localService.execute(inData);
                            } catch (RuntimeException e){
                                result = new JioSerial();
                                result.setDataDescription(CUtil.reportException(e));
                                result.setStatus(CConstants.error);
                                broadcastError(serviceName,result);
                            }
                        }


                    } else {
                        // service does not have a multiple synchronized inputs
                        // so, execute single input localService;
                        try{

                            //*** execute the service engine
                            result = localService.execute(data);

                        } catch (Throwable e){
                            String exceptionMsg = "THE SERVICE HAS THROWN AN EXCEPTION:\n" + CUtil.reportException(e);
                            result = new JioSerial();
                            result.setDataSource(serviceName);
                            result.setDataDescription(exceptionMsg);
                            result.setStatus(CConstants.error);
                            lg.logger.severe(myName+": "+
                                    " service: "+ serviceName+
                                    " requester: "+ requestingServiceName+
                                    " request id: "+ requestingServiceRequestId+
                                    " exceptionMsg "+ exceptionMsg
                            );
                        }
                    }
                    if(result!=null){
                        result.setDataSource(serviceName);

                        // see if service engine needs to log something into the database
                        if(!result.getLogMessage().equals(CConstants.udf)){
                            try {
                                _logMsg(result);
                            } catch (CException e) {
                                lg.logger.severe(CUtil.stack2str(e));
                            }
                        }

                        if (result.getRequestID() == -1) {
                            // save same request ID as the requester
                            result.setRequestID(requestingServiceRequestId);
                        } else {
                            // service set a new request ID, use it in report and result messages
                            requestingServiceRequestId = result.getRequestID();
                        }

                        // engine sets the data status = error,
                        // i.e service engine returns an error
                        if(result.getStatus().equals(CConstants.error)){
                            // set the name of this service as being the author of this exception
                            broadcastError(serviceName,result);

                        } else {
                            // engine has a warning message
                            if(result.getStatus().equals(CConstants.warning)){
                                broadcastWarning(serviceName,result);

                                // engine has a normal data
                            } else {


                                // broadcast done/data.
                                // If doneBroadcast/dataBroadcast
                                // is equal to true broadcast
                                // and pass it to all services in the chain.
                                // Otherwise if it is the name of the service,
                                // broadcast and reset it to false. All other
                                // cases pass it to the service along the chain
                                if(doneBroadcast.equals("true")){
                                    broadcastDone(serviceName,done(serviceName));
                                    result.setDoneBroadcast("false");
                                } else if(doneBroadcast.equals(serviceName)){
                                    broadcastDone(serviceName,done(serviceName));
                                    result.setDoneBroadcast("false");
                                } else if(!doneBroadcast.equals("false")){
                                    result.setDoneBroadcast(doneBroadcast);
                                }

                                // broadcast data
                                if(dataBroadcast.equals("true")){
                                    broadcastData(serviceName,result);
                                    isDataBroadcasted = true;
                                    result.setDataBroadcast("false");
                                } else if(dataBroadcast.equals(serviceName)){
                                    broadcastData(serviceName,result);
                                    isDataBroadcasted = true;
                                    result.setDataBroadcast("false");
                                } else if(!dataBroadcast.equals("false")){
                                    result.setDataBroadcast(dataBroadcast);
                                }

                                if(nextEventBroadcast.equals(serviceName)&& !isDataBroadcasted){
                                    broadcastData(serviceName,result);
                                    nextEventBroadcast = "undefined";
                                }

                                // report the result to all outside listeners
                                try {
                                    _reportRegisteredListeners(serviceName,
                                            localService,
                                            result,
                                            requestingServiceRequestId);
                                } catch (CException e) {
                                    lg.logger.severe(CUtil.stack2str(e));
                                }
                            }

                            // now execute linked service
                            // report the result to all linked services
                            // (outputs)
                            _startLinked(serviceName,
                                    dataDestination,
                                    result,
                                    requestingServiceRequestId);
                        }

                        // result is null
                    } else {
                        result = reject("null output data", CConstants.error);

                        // execution results in error. Inform this exception to exception listeners
                        broadcastError(serviceName, result);

                        System.err.printf("%s ERROR: null result of service %s.%n", myName, serviceName);
                    }
                } else {
                    broadcastError(serviceName,reject("null input data", CConstants.error));

                    System.err.printf("%s ERROR: null input data for service %s (requester: %s, requestID: %d).%n",
                            myName, serviceName, requestingServiceName, requestingServiceRequestId);
                }
            } else {
                System.err.printf("%s ERROR: missing requesting service %s " +
                        "information (name and/or request ID).%n", myName, serviceName);
            }
        } else {
            System.err.printf("%s ERROR: requested service %s not registered.%n", myName, serviceName);
        }
    }

    /**
     * Broadcast error locally in the DPE and entire platform.
     * @param subject to broadcast
     * @param td transient data
     */
    private void broadcastError(String subject, JioSerial td){
        td.setExceptionSource(subject);
        broadcast(subject, CSISConstants.EXCEPTION_REPORT, td);
        // broadcast to entire platform
        platformBroadcast(subject, CSISConstants.EXCEPTION_REPORT, td);

    }

    /**
     * Broadcast warning.
     * @param subject to broadcast
     * @param td transient data
     */
    private void broadcastWarning(String subject, JioSerial td){
        td.setExceptionSource(subject);
        broadcast(subject, CSISConstants.WARNING_REPORT, td);

        // broadcast to entire platform
        platformBroadcast(subject, CSISConstants.WARNING_REPORT, td);
    }

    /**
     * Broadcast error.
     * @param subject to broadcast
     * @param td transient data
     */
    private void broadcastData(String subject, JioSerial td){
        td.setDataSource(subject);
        broadcast(subject, CSISConstants.DATA_REPORT, td);
    }

    /**
     * Broadcast done
     * @param subject to broadcast
     * @param td transient data
     */
    private void broadcastDone(String subject, JioSerial td){
        td.setDataSource(subject);
        broadcast(subject, CSISConstants.DONE_REPORT, td);
    }


    /**
     * Broadcast.
     * @param subject to broadcast
     * @param type to broadcast
     * @param data transient data
     */
    private void broadcast(String subject, String type, JioSerial data){
        CTrParameter p = new CTrParameter();
        p.setSubject(subject);
        p.setType(type);
        p.setText(data.getDataDescription());
        try {
            p.setMessage(data.packEnvelope(new ArrayList<cMsgPayloadItem>(), new cMsgMessage()));
            p.setConnection(myLocalDPEConnection);
            send(p);
        } catch (CException e) {
            lg.logger.severe(CUtil.stack2str(e));
        }
    }



    /**
     * Broadcast to platform.
     * @param subject to broadcast
     * @param type to broadcast
     * @param data transient data
     */
    private void platformBroadcast(String subject, String type, JioSerial data){
        if(isPlatformConnected() && (!myConfig.getPlatformHost().equalsIgnoreCase(myConfig.getLocalDpeHost())) ){
            CTrParameter p = new CTrParameter();
            p.setConnection(myPlatformConnection);
            p.setSubject(subject);
            p.setType(type);
            p.setText(data.getDataDescription());
            try {
                p.setMessage(data.packEnvelope(new ArrayList<cMsgPayloadItem>(), new cMsgMessage()));
                p.setConnection(myPlatformConnection);
                send(p);
            } catch (CException e) {
                lg.logger.severe(CUtil.stack2str(e));
            }
        }
    }


    /**
     * Creates a transient data, describing the cause for rejecting the service request.
     * @param msg description of the rejection
     * @param severity of the exception
     * @return  {@link JioSerial} transient data object
     */
    private JioSerial reject(String msg, String severity){
        JioSerial td = new JioSerial();
        td.setData(msg, MimeType.STRING);
        td.setStatus(severity);
        td.setDataDescription(msg);
        return td;
    }

    /**
     * Creates a transient data, informing the completion of the service execution.
     * @param msg description of the rejection
     * @return  {@link JioSerial} transient data object
     */
    private JioSerial done(String msg){
        JioSerial td = new JioSerial();
        td.setData(msg, MimeType.STRING);
        td.setStatus(CConstants.info);
        td.setDataDescription("service executed");
        return td;
    }

    /**
     * Calls requested local service engine getVersion method and send the result
     * sync to the sendAndGEt requester.
     * @param serviceName local service canonical name
     * @param msg input to the local service
     */
    private String _syncGetVersionService(String serviceName, cMsgMessage msg){
        String version = "failed";

        // find the local service by name
        CServiceInfo serviceInfo = myServices.get(serviceName);
        if (serviceInfo != null) {

            // find a service by name
            ICService localService = serviceInfo.getEngine();

            // execute service engine getVersion method
            version = localService.getVersion();

            // now create and send a the message
            try {
                cMsgMessage mr = msg.response();
                mr.setText(version);
                myLocalDPEConnection.send(mr);
            } catch (cMsgException e) {
                lg.logger.severe(CUtil.stack2str(e));
                version = e.getMessage();
            }
        }
        return version;
    }


    /**
     * Execute requested local service engine and send the result sync to the sendAndGEt requester.
     * @param serviceName local service canonical name
     * @param msg input to the local service
     * @param inShared indicating that the transient data object is in the shared memory
     */
    private void _syncExecuteService(String serviceName, cMsgMessage msg, boolean inShared){
        // find the local service by name
        CServiceInfo serviceInfo = myServices.get(serviceName);
        if (serviceInfo != null) {

            // find a service by name
            ICService localService = serviceInfo.getEngine();

            if(inShared){
                int requestingServiceRequestId = -1;
                if (msg.getPayloadItem(CSISConstants.SERVICE_REQUEST_ID) != null) {
                    try {
                        requestingServiceRequestId = msg.getPayloadItem(CSISConstants.SERVICE_REQUEST_ID).getInt();
                    } catch (cMsgException e) {
                        lg.logger.severe(CUtil.stack2str(e));
                    }
                }
                if(requestingServiceRequestId>0) {

                    // sender is a ClaraUser component (service/orchestrator)
                    String sender = msg.getSender();

                    // get data from the shared memory
                    JioSerial data = CShareDataRep.getInputData(serviceName, sender, requestingServiceRequestId);

                    // execute the service
                    JioSerial o = localService.execute(data);

                    // see if service engine needs to log something into the database
                    if(!o.getLogMessage().equals(CConstants.udf)){
                        try {
                            _logMsg(o);
                        } catch (CException e) {
                            lg.logger.severe(CUtil.stack2str(e));
                        }
                    }

                    // put back into the shared memory since the requester
                    // has its data stored in the shared memory
                    CShareDataRep.putInputData(sender, serviceName, requestingServiceRequestId, o);

                    // now create and send a control message informing that the service
                    // is executed and the data is in the shared memory
                    try {
                        cMsgMessage mr = msg.response();
                        mr.setText(CSISConstants.DATA_IN_SHARED_MEMORY);
                        myLocalDPEConnection.send(mr);
                    } catch (cMsgException e) {
                        lg.logger.severe(CUtil.stack2str(e));
                    }
                } else {
                    System.err.println("Null request id");
                }

                // in case the input data is not in the shared memory,
                // meaning that the requester is a remote service or
                // is not a java service
            } else {

                // get the input transient data object from the message
                JioSerial data = new JioSerial(msg);

                // execute the message
                JioSerial o = localService.execute(data);

                // see if service engine needs to log something into the database
                if(!o.getLogMessage().equals(CConstants.udf)){
                    try {
                        _logMsg(o);
                    } catch (CException e) {
                        lg.logger.severe(CUtil.stack2str(e));
                    }
                }

                // create a response message and pack the resulting data in it
                try {
                    cMsgMessage mr = createResponseAndPack(msg, localService, o);
                    mr.setText(CSISConstants.DATA_IN_MESSAGE);

                    // send a message informing in the text field that the
                    // data is in the message, not in the shared memory
                    myLocalDPEConnection.send(mr);
                } catch (cMsgException e) {
                    lg.logger.severe(CUtil.stack2str(e));
                } catch (CException e) {
                    lg.logger.severe(CUtil.stack2str(e));
                }
            }
        }
    }

    /**
     * Start the next service in the chain, by sending the output of this service as an input to the next service
     * @param serviceName local service name
     * @param dataDestination  canonical name of the destination service (can have wildcard in it)
     * @param data data object going to be sent to the service in the chain
     * @param requestId service request id
     */
    private void _startLinked(String serviceName, String dataDestination, JioSerial data, int requestId){
        String dd = dataDestination;
        String dh;
        String dsc;
        String de;
        CServiceInfo serviceInfo = myServices.get(serviceName);
        if (serviceInfo != null) {
            data.setDataSource(serviceName);
            try {

                if(!dd.equals(CConstants.udf)){
                    // dpe host name
                    dh = CUtil.parse4DpeHostName(dd);
                    // service container name
                    dsc = CUtil.parse4ContainerName(dd);
                    // engine name
                    de = CUtil.parse4EngineName(dd);

                    // sending to the linked specific service
                    if(!dd.contains("*")){
                        for (CServiceOutputLink output : serviceInfo.getOutputs()) {
                            if(dd.equals(output.getServiceName())){

                                runService(output.getServiceName(), data, requestId);
                                // send data to platform CServiceSpy service for communication logging
                                _logMsg(data);
                                break;
                            }
                        }
                        // sending to all linked services with a specific engine name
                    } else if(dh.equals("*") && dsc.equals("*")){
                        for (CServiceOutputLink output : serviceInfo.getOutputs()) {
                            if(de.equals(CUtil.parse4EngineName(output.getServiceName()))){
                                runService(output.getServiceName(), data, requestId);
                                _logMsg(data);
                                break;
                            }
                        }
                        // sending to all linked services with a specific service container name
                    } else if (dh.equals("*")){
                        for (CServiceOutputLink output : serviceInfo.getOutputs()) {
                            if(dsc.equals(CUtil.parse4ContainerName(output.getServiceName()))){
                                runService(output.getServiceName(), data, requestId);
                                _logMsg(data);
                                break;
                            }
                        }
                        // sending to all linked services running on a specific host ( dpe )
                    } else if (dsc.equals("*")){
                        for (CServiceOutputLink output : serviceInfo.getOutputs()) {
                            if(dh.equals(CUtil.parse4DpeHostName(output.getServiceName()))){
                                runService(output.getServiceName(), data, requestId);
//                            System.out.println("DDD: sent event to service = "+output.getServiceName()+" id = "+requestId);
                                _logMsg(data);
                                break;
                            }
                        }
                    }
                    // destination service is not defined send to all linked services
                } else {
                    //  request services that are linked to this local
                    // service and send transient data as an input
                    for (CServiceOutputLink output : serviceInfo.getOutputs()) {
                        runService(output.getServiceName(), data, requestId);
                        // send data platform CServiceSpy service for communication logging
                        _logMsg(data);

                    }
                }
            } catch(CException e){
                lg.logger.severe(CUtil.stack2str(e));
            }
        }
    }

    private void _reportLinkedNames(String serviceName, cMsgMessage msg){

        CServiceInfo serviceInfo = myServices.get(serviceName);
        if (serviceInfo != null) {
            try {
                cMsgMessage respMsg = msg.response();
                List<String> outputsList = new ArrayList<String>();
                for (CServiceOutputLink output : serviceInfo.getOutputs())
                    outputsList.add(output.getServiceName());
                if (outputsList.size() > 0) {
                    String[] ouputsArray = outputsList.toArray(new String[outputsList.size()]);
                    cMsgPayloadItem outputsItem = new cMsgPayloadItem("service-links", ouputsArray);
                    respMsg.addPayloadItem(outputsItem);
                }
                myLocalDPEConnection.send(respMsg);
            } catch (cMsgException e) {
                lg.logger.severe(CUtil.stack2str(e));
            }
        }
    }

    /**
     * Broadcast the result to everyone listening, for e.g. complex event processors, etc.
     * @param localServiceName local service canonical name
     * @param localService ICService object
     * @param data data object going to be sent to the service in the chain
     * @param requestId service request id
     */
    private void _reportRegisteredListeners(String localServiceName, ICService localService, JioSerial data, int requestId) throws CException {

        CServiceInfo localServiceInfo = myServices.get(localServiceName);
        if (localServiceInfo != null && !localServiceInfo.getListeners().isEmpty()) {

            // create service standard payload structure
            ArrayList<cMsgPayloadItem> al = serviceAsPayload(localService);
            try {
                al.add(new cMsgPayloadItem(CSISConstants.SERVICE_REQUEST_ID,requestId));
            } catch (Exception e) {
                lg.logger.severe(CUtil.stack2str(e));
            }

            for(CServiceListener receiver: localServiceInfo.getListeners()) {

                data.setDataSource(localServiceName);

                // create transport parameter object
                CTrParameter p = new CTrParameter();
                p.setConnection(myLocalDPEConnection);
                p.setSubject(receiver.getSubject());
                p.setText(localServiceName);
                p.setPayloadItems(al);

                try {
                    if(CShareDataRep.isInJvm(receiver.getName())){

                        // data is in shared memory
                        CShareDataRep.putInputData(receiver.getName(), localService.getName(), requestId, data);

                        // send recipient info that the data is in the shared memory
                        p.setType(receiver.getType());

                        // send the control message without a data. Note: usage of the local connection.
                        // This is because listener already has a connection to the local DPE server
                        send(p);
                    } else {
                        p.setType(receiver.getType());
                        p.setMessage(data.packEnvelope(al, new cMsgMessage()));
                        // send the message with the data
                        send(p);
                    }

                    // send data platform CServiceSpy service for communication logging
                    _logMsg(data);
                } catch (CException e){
                    lg.logger.severe(CUtil.stack2str(e));
                }
            }
        }
    }


    private boolean _configureService(String serviceName, cMsgMessage msg){
        boolean stat= false;
        CServiceInfo serviceInfo = myServices.get(serviceName);
        if (serviceInfo != null) {
            ICService srv = serviceInfo.getEngine();
            JioSerial jio = new JioSerial(msg);
            srv.configure(jio);
            stat = true;
        }
        return stat;
    }

    private boolean _un_subscribe(String serviceName, cMsgMessage msg){
        boolean stat = true;
        CServiceInfo serviceInfo = myServices.get(serviceName);
        if (serviceInfo != null) {
            String rName    = null;
            String rSubject = null;
            String rType    = null;
            try {
                if(msg.getPayloadItem(CSISConstants.REQUESTER_NAME)!=null){
                    rName = msg.getPayloadItem(CSISConstants.REQUESTER_NAME).getString();
                }
                if(msg.getPayloadItem(CSISConstants.REQUESTER_SUBJECT)!=null){
                    rSubject = msg.getPayloadItem(CSISConstants.REQUESTER_SUBJECT).getString();
                }
                if(msg.getPayloadItem(CSISConstants.REQUESTER_TYPE)!=null){
                    rType = msg.getPayloadItem(CSISConstants.REQUESTER_TYPE).getString();
                }
            } catch (cMsgException e) {
                lg.logger.severe(CUtil.stack2str(e));
                return false;
            }
            CServiceListener csl = new CServiceListener(rName, rSubject, rType);
            stat = serviceInfo.removeListener(csl);
            if (stat) {
                System.out.println(myName + " INFO: " + rName + " un-subscribed from the service: " +
                        serviceName );
            }
        }
        return stat;
    }

    private boolean _subscribe(String serviceName, cMsgMessage msg){
        boolean stat = true;
        CServiceInfo serviceInfo = myServices.get(serviceName);
        if (serviceInfo != null) {
            String rName    = null;
            String rSubject = null;
            String rType    = null;
            try {
                if(msg.getPayloadItem(CSISConstants.REQUESTER_NAME)!=null){
                    rName = msg.getPayloadItem(CSISConstants.REQUESTER_NAME).getString();
                }
                if(msg.getPayloadItem(CSISConstants.REQUESTER_SUBJECT)!=null){
                    rSubject = msg.getPayloadItem(CSISConstants.REQUESTER_SUBJECT).getString();
                }
                if(msg.getPayloadItem(CSISConstants.REQUESTER_TYPE)!=null){
                    rType = msg.getPayloadItem(CSISConstants.REQUESTER_TYPE).getString();
                }
            } catch (cMsgException e) {
                lg.logger.severe(CUtil.stack2str(e));
                return false;
            }
            CServiceListener csl = new CServiceListener(rName, rSubject, rType);
            stat = serviceInfo.addListener(csl);
            if (stat) {
                System.out.println(myName + " INFO: " + rName + " subscribed to the service: " +
                        serviceName);
            }
        }
        return stat;
    }

    private boolean _addService(String serviceName, cMsgMessage msg){
        boolean stat;
        ICService eng;
        try {

            // own class-loader
            URL[] urls;
            // Convert the file object to a URL
            File dir = new File(serviceEngineLocation +File.separator);
            URL url;
            url = dir.toURI().toURL();
            urls = new URL[]{url};
            // Create a new class loader with the directory
            CClassLoader cl = new CClassLoader(urls);

            cl.setClassesToLoad(new String[] {serviceName});

            // Load the class
            Class<?> cls = cl.loadClass(serviceName);

            // Create a new instance of the new class
            eng = (ICService)cls.newInstance();

            stat = addService(eng);

            if(msg.isGetRequest()){
                cMsgMessage mr;
                mr = msg.response();
                mr.setSubject(CConstants.udf);
                mr.setType(CConstants.udf);
                if(eng!=null){
                    mr.setText(eng.getName());
                } else mr.setText(CConstants.udf);
                myLocalDPEConnection.send(mr);
            }
        } catch (MalformedURLException e) {
            lg.logger.severe(CUtil.stack2str(e));
            stat = false;
        } catch (ClassNotFoundException e) {
            lg.logger.severe(CUtil.stack2str(e));
            stat = false;
        } catch (InstantiationException e) {
            lg.logger.severe(CUtil.stack2str(e));
            stat = false;
        } catch (cMsgException e) {
            lg.logger.severe(CUtil.stack2str(e));
            stat = false;
        } catch (IllegalAccessException e) {
            lg.logger.severe(CUtil.stack2str(e));
            stat = false;
        } catch (CException e) {
            lg.logger.severe(CUtil.stack2str(e));
            stat = false;
        }
        return stat;
    }


    /***************************************************************
     * Private inner class for responding to control messages addressed to this service container
     */
    private class ServiceControlCB extends cMsgCallbackAdapter {
        @Override
        public void callback(cMsgMessage msg, Object userObject){

            // remote service canonical name
            String remoteServiceName;

            // control through cMsg type
            String control = msg.getType();

            // local service canonical name
            String localServiceName = msg.getText();


            System.out.println(myName + " INFO: received message" +
                    "  type: " + control + "  text: " + localServiceName +
                    "  from: " + msg.getSender());

            try {
                if(control !=null && localServiceName !=null){

                    // increment request count
                    cMsgRequests++;

                    if(control.equals(CSISConstants.ServiceControlRequestStartService)){
                        if(msg.isGetRequest()){
                            serviceWorkerThreadPool.execute(new ServiceWorkerThread(localServiceName,msg,false,true));
//                            System.out.println("RMS number of active threads      = "+serviceWorkerThreadPool.getActiveCount());
//                            System.out.println("RMS number of threads in the pool = "+serviceWorkerThreadPool.getPoolSize());
                        } else {
                            serviceWorkerThreadPool.execute(new ServiceWorkerThread(localServiceName,msg,false,false));
//                            System.out.println("RM number of active threads      = "+serviceWorkerThreadPool.getActiveCount());
//                            System.out.println("RM number of threads in the pool = "+serviceWorkerThreadPool.getPoolSize());
                        }

                    } else if(control.equals(CSISConstants.ServiceControlRequestStartServiceFSHM)){
                        // start service using data from the shared memory
                        if(msg.isGetRequest()){
                            serviceWorkerThreadPool.execute(new ServiceWorkerThread(localServiceName,msg,true,true));
//                            System.out.println("SMS number of active threads      = "+serviceWorkerThreadPool.getActiveCount());
//                            System.out.println("SMS number of threads in the pool = "+serviceWorkerThreadPool.getPoolSize());
                        } else {
                            serviceWorkerThreadPool.execute(new ServiceWorkerThread(localServiceName,msg,true,false));
//                            System.out.println("SM number of active threads      = "+serviceWorkerThreadPool.getActiveCount());
//                            System.out.println("SM number of threads in the pool = "+serviceWorkerThreadPool.getPoolSize());
//                            System.out.println("SMS number of completed threads   = "+serviceWorkerThreadPool.getCompletedTaskCount());
                        }

                    } else if(control.equals(CSISConstants.ServiceControlRequestAddInput)){
                        if(msg.getPayloadItem(CSISConstants.LOCAL_SERVICE)!=null &&
                                msg.getPayloadItem(CSISConstants.REMOTE_CONTAINER)!=null &&
                                msg.getPayloadItem(CSISConstants.REMOTE_SERVICE)!=null){
                            localServiceName    = msg.getPayloadItem(CSISConstants.LOCAL_SERVICE).getString();
                            remoteServiceName   = msg.getPayloadItem(CSISConstants.REMOTE_SERVICE).getString();
                            addInput(localServiceName, remoteServiceName);
                        }

                    } else if(control.equals(CSISConstants.ServiceControlRequestRemoveInput)){
                        if(msg.getPayloadItem(CSISConstants.LOCAL_SERVICE)!=null &&
                                msg.getPayloadItem(CSISConstants.REMOTE_CONTAINER)!=null &&
                                msg.getPayloadItem(CSISConstants.REMOTE_SERVICE)!=null){
                            localServiceName    = msg.getPayloadItem(CSISConstants.LOCAL_SERVICE).getString();
                            remoteServiceName   = msg.getPayloadItem(CSISConstants.REMOTE_SERVICE).getString();
                            removeInput(localServiceName, remoteServiceName);
                        }

                    } else if(control.equals(CSISConstants.ServiceControlRequestLink)){
                        if(msg.getPayloadItem(CSISConstants.LOCAL_SERVICE)!=null &&
                                msg.getPayloadItem(CSISConstants.REMOTE_CONTAINER)!=null &&
                                msg.getPayloadItem(CSISConstants.REMOTE_SERVICE)!=null){
                            localServiceName    = msg.getPayloadItem(CSISConstants.LOCAL_SERVICE).getString();
                            remoteServiceName   = msg.getPayloadItem(CSISConstants.REMOTE_SERVICE).getString();
                            try {
                                _linkService(localServiceName, remoteServiceName);
                            } catch (CException e) {
                                lg.logger.severe(CUtil.stack2str(e));
                            }
                        }

                    } else if(control.equals(CSISConstants.ServiceControlRequestUnLink)){
                        if(msg.getPayloadItem(CSISConstants.LOCAL_SERVICE)!=null &&
                                msg.getPayloadItem(CSISConstants.REMOTE_CONTAINER)!=null &&
                                msg.getPayloadItem(CSISConstants.REMOTE_SERVICE)!=null){
                            localServiceName    = msg.getPayloadItem(CSISConstants.LOCAL_SERVICE).getString();
                            remoteServiceName   = msg.getPayloadItem(CSISConstants.REMOTE_SERVICE).getString();
                            _unLinkService(localServiceName, remoteServiceName);
                        }

                    } else if(control.equals(CSISConstants.ServiceControlReportLinks)){
                        if(msg.isGetRequest()){
                            _reportLinkedNames(localServiceName, msg);
                        }

                    } else if(control.equals(CSISConstants.ServiceControlRequestAddService)){
                        String serviceEngineClass = msg.getPayloadItem(CSISConstants.SERVICE_ENGINE_CLASSPATH).getString();
                        _addService(serviceEngineClass, msg);

                    } else if(control.equals(CSISConstants.ServiceControlRequestConfigure)){
                        serviceWorkerThreadPool.execute(new ServiceConfigureThread(localServiceName,msg));

                    } else if(control.equals(CSISConstants.ServiceControlRequestSubscribe)){
                        _subscribe(localServiceName, msg);

                    } else if(control.equals(CSISConstants.ServiceControlRequestUnSubscribe)){
                        _un_subscribe(localServiceName, msg);

                    } else if(control.equals(CSISConstants.ServiceControlRequestRemoveService)){
                        removeMyService(localServiceName);

                    } else if(control.equals(CSISConstants.ServiceControlRequestStop)){
                        scExit();
                    } else if(control.equals(CSISConstants.ServiceControlRequestVersion)){
                        if(msg.isGetRequest()){
                            _syncGetVersionService(localServiceName, msg);
                        }
                    } else if(control.equals(CSISConstants.ServiceControlRequestBroadcast)){
                        nextEventBroadcast =  localServiceName;
                    }
                } else if(control.equals(CSISConstants.ServiceControlSetLoadStatInterval)){
                    try{
                        loadReportingInterval = Integer.parseInt(msg.getText().trim());
                    }catch(NumberFormatException e){
                        lg.logger.severe(CUtil.stack2str(e));
                    }
                } else {
                    System.out.println(myName+ ":Error Malformed message (null type/text)");
                }
            } catch (cMsgException e) {
                lg.logger.severe(CUtil.stack2str(e));
            } catch (CException e) {
                lg.logger.severe(CUtil.stack2str(e));
            }
        }
    }

    /***************************************************************
     * Private inner class implements runnable to run callback in a separate thread.
     */
    private class ServiceWorkerThread implements Runnable {
        private cMsgMessage msg;
        private String      serviceName;
        private boolean     isSync;
        private boolean     inShared;

        public ServiceWorkerThread(String sName,cMsgMessage m, boolean inShared, boolean isSync){
            serviceName   = sName;
            msg           = m;
            this.isSync   = isSync;
            this.inShared = inShared;
        }

        @Override
        public void run(){
            if(isSync){
                _syncExecuteService(serviceName, msg, inShared);
            } else {
                _executeService(serviceName, msg, inShared);
            }
        }
    }

    /***************************************************************
     * Private inner class implements runnable to run configure method of the engine.
     */
    private class ServiceConfigureThread implements Runnable {
        private cMsgMessage msg;
        private String      serviceName;

        public ServiceConfigureThread(String sName,cMsgMessage m){
            serviceName   = sName;
            msg           = m;
        }

        @Override
        public void run(){
            _configureService(serviceName,msg);
        }
    }

    // Add a new thread to handle new service requests
    class RejectHandler implements RejectedExecutionHandler {
        @Override
        public void rejectedExecution(Runnable r, ThreadPoolExecutor executor) {
            // Just run a new thread
            Thread t = new Thread(r);
            t.setDaemon(true);
            t.start();
        }
    }


    /***************************************************************
     * Inner class for reporting to the Container admin the load, i.e. the number of cMsg requests to this agent.
     */
    private class ReportLoadThread extends Thread{
        public boolean isRunning;
        private int delay;
        private int delSec;

        /**
         * Constructor
         * @param delay period of the reporting
         */
        public ReportLoadThread(int delay){
            isRunning = true;
            this.delay = delay;
            delSec = this.delay/1000;
        }

        @Override
        public void run() {
            super.run();
            while(isRunning){
                CUtil.sleep(delay);
                myLoad = (cMsgRequests / delSec);
                myRegistrationInfo.setLoad(myLoad);
                CTrParameter p = new CTrParameter();
                p.setConnection(myPlatformConnection);
                p.setType(CSISConstants.PlatformRegistrationRequestAddServiceContainer);
                p.setData(myRegistrationInfo);

                try {
                    send(p);
                } catch (CException e) {
                    lg.logger.severe(CUtil.stack2str(e));
                }
                cMsgRequests = 0;

//                ArrayList<cMsgPayloadItem> al = new ArrayList<cMsgPayloadItem>();
//                try {
//                    al.add(new cMsgPayloadItem("container_load", myRegistrationInfo.getLoad()));
//                } catch (cMsgException e) {
//                    e.printStackTrace();
//                }
//
//                // create transport parameter object
//                CTrParameter p = new CTrParameter();
//                p.setConnection(_c.myLocalDPEConnection);
//                p.setSubject(_c.myName);
//                p.setText(CSISConstants.ServiceInfoRequestServices);
//                p.setPayloadItems(al);
//                p.setData(myRegistrationInfo.getServices());
//
//                // send a message
//                _c.send(p);
            }
        }
    }
}
