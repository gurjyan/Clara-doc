/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */


package org.jlab.clara.examples.service;

import org.jlab.clara.constants.CConstants;
import org.jlab.clara.data.JioSerial;
import org.jlab.clara.frontend.JService;
import org.jlab.clas12.tools.MimeType;
import org.jlab.clara.util.CUtil;

import java.math.BigInteger;

public class BigFactorialService extends JService {
    int factorial = 6000;
    String NAME = "BigFactorialService";

    protected BigFactorialService(String name) {
        super(name);
    }

    @Override
    public void configure(JioSerial data) {
        MimeType mimeType = data.getMimeType();
        switch (mimeType) {
        case STRING:
            String value = data.getStringObject();
            int tmp = CUtil.isNumber(value);
            if (tmp > 0) {
                factorial = tmp;
                System.out.println(NAME + " service: configuring factorial = " + factorial + "!");
            } else {
                System.err.println(NAME + " service: wrong configuration value = " + value);
            }
            break;
        case INT:
            factorial = data.getIntObject();
            System.out.println(NAME + " service: configuring factorial = " + factorial + "!");
            break;
        default:
            System.err.println(NAME + " service: wrong configuration mime-type = " + mimeType);
        }
    }

    @Override
    public JioSerial execute(JioSerial data) {
        BigInteger fact = BigInteger.valueOf(1);
        for (int i = 1; i <= factorial; i++) {
            fact = fact.multiply(BigInteger.valueOf(i));
        }
        JioSerial out = new JioSerial();
        out.setData(data.getDataAsByteBuffer(), MimeType.EVIO);
        out.setStatus(CConstants.info);
        out.setDataDescription("data");
        return out;
    }

    @Override
    public JioSerial execute(JioSerial[] data) {
        return null;
    }

    @Override
    public void destruct() {
        // nothing
    }

    @Override
    public String getName() {
        return NAME;
    }

    @Override
    public String getAuthor() {
        return "Sebastian Mancilla";
    }

    @Override
    public String getDescription() {
        return "Calculates a big factorial n! to simulate a real service with intensive CPU usage.";
    }

    @Override
    public String getVersion() {
        return "1.0";
    }

    @Override
    public String getLanguage() {
        return CConstants.LANG_JAVA;
    }

}
