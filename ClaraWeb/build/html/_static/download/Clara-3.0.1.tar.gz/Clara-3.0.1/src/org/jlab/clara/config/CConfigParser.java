package org.jlab.clara.config;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import org.jlab.clara.constants.CConstants;
import org.jlab.clara.util.CLogger;
import org.jlab.clara.util.CUtil;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;

/**
 * XML setup file parses.
 * This is the file that defines the platform, i.e. master DPE host and TCP/IP ports.
 * The full path of the Clara config file is: $CLARA_SERVICES/setup.xml
 * Note. This file is optional for Clara operations.
 * The following is an example of the setup.xml file content:
 *
 * <clara>
 *    <description>Clara Test Platform</description>
 *    <platformHost>claradm.jlab.org</platformHost>
 *    <tcpPort>45000</tcpPort>
 *    <udpPort>45001</udpPort>
 * </clara>
 *
 *
 * @author gurjyan
 * @version 3.x
 */
public class CConfigParser {

    private String platformDescription = CConstants.udf;
    private String platformHost        = CConstants.udf;
    private int    platformTcpPort;
    private int    platformUdpPort;
    // local instance of the logger object
    private CLogger lg = CLogger.getInstance();

    /**
     * Constructor does the parsing
     * @param fileName the name of the config file.
     */
    public CConfigParser(String fileName){
        NodeList nl;
        Element ne;
        try {
            // Create a builder factory
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            factory.setValidating(false);

            // Create the builder and parse the file
            Document doc = factory.newDocumentBuilder().parse(new File(fileName));
            doc.getDocumentElement().normalize();

            // get platformHost tag
            nl = doc.getElementsByTagName("platformHost");
            if(nl.item(0)!=null){
                ne = (Element)nl.item(0);
                nl = ne.getChildNodes();
                platformHost = nl.item(0).getNodeValue().trim();
            }

            // get description tag
            nl = doc.getElementsByTagName("description");
            if(nl.item(0)!=null){
                ne = (Element)nl.item(0);
                nl = ne.getChildNodes();
                platformDescription = nl.item(0).getNodeValue().trim();
            }

            // get tcpPort tag
            nl = doc.getElementsByTagName("tcpPort");
            if(nl.item(0)!=null){
                ne = (Element)nl.item(0);
                nl = ne.getChildNodes();
                try{
                    platformTcpPort = Integer.parseInt(nl.item(0).getNodeValue().trim());
                } catch (NumberFormatException e){
                    lg.logger.severe(CUtil.stack2str(e));
                }
            }

            // get udpPort tag
            nl = doc.getElementsByTagName("udpPort");
            if(nl.item(0)!=null){
                ne = (Element)nl.item(0);
                nl = ne.getChildNodes();
                try{
                    platformUdpPort = Integer.parseInt(nl.item(0).getNodeValue().trim());
                } catch (NumberFormatException e){
                    lg.logger.severe(CUtil.stack2str(e));
                }
            }

        } catch (SAXException e) {
            lg.logger.severe(CUtil.stack2str(e));
        } catch (ParserConfigurationException e) {
            lg.logger.severe(CUtil.stack2str(e));
        } catch (IOException e) {
            lg.logger.severe(CUtil.stack2str(e));
            System.exit(-1);
        }
    }

    /**
     * @return platform description
     */
    public String getPlatformDescription() {
        return platformDescription;
    }

    /**
     * @return platform host name
     */
    public String getPlatformHost() {
        return platformHost;
    }

    /**
     * @return platform TCP port
     */
    public int getPlatformTcpPort() {
        return platformTcpPort;
    }

    /**
     * @return platform UDP port
     */
    public int getPlatformUdpPort() {
        return platformUdpPort;
    }
}

