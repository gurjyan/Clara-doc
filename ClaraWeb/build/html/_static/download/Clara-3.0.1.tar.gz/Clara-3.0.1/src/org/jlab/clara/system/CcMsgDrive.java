package org.jlab.clara.system;

import org.jlab.coda.cMsg.cMsg;
import org.jlab.coda.cMsg.cMsgException;
import org.jlab.coda.cMsg.cMsgMessage;
import org.jlab.coda.cMsg.cMsgPayloadItem;
import org.jlab.clara.config.CConfig;
import org.jlab.clara.constants.CConstants;
import org.jlab.clara.pubsub.CTrParameter;
import org.jlab.clara.util.CUtil;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

/**
 * Class presents pub-sub communication functionality
 *
 * @author gurjyan
 * @version 3.x
 */
public class CcMsgDrive implements IClaraDataBus {

    // platform connection object
    private volatile Object plConnection;

    // DPE connection object
    private volatile Object dpeConnection;

    // Clara configuration information
    public CConfig myConfig = CConfig.getInstance();

    public cMsg getPlatformConnection(){
        if(plConnection !=null){
            return (cMsg) plConnection;
        } else {
            return null;
        }
    }

    public cMsg getLoaclDPEConnection(){
        if(dpeConnection !=null){
            return (cMsg) dpeConnection;
        } else {
            return null;
        }
    }

    /**
     * Connects to the cMsg pub-sub server
     * @param name client name
     * @param udl  udl of the server
     * @param description description
     * @return cMsg connection object
     * @throws CException
     */
    public Object connect(String name, String udl, String description) throws CException {
        cMsg connection;
        if(name != null && !name.equals(CConstants.udf)){
            try {
                connection = new cMsg(udl,name,description);
                connection.connect();
                connection.start();
            } catch (cMsgException e) {
                throw new CException(e.getMessage());
            }
        } else {
            throw new CException("Clara client name is null.");
        }
        return connection;
    }

    /**
     * Connects to a DPE pub-sub server
     * Note: platform is also a DPE (master DPE)
     * @param name client name, i.e. client name who is making a connection
     * @param host of the DPE
     * @return cMsg connection object
     * @throws CException
     */
    public Object connect2Dpe(String name, String host) throws CException {
        if((CUtil.getIPAddress(host).equals(CUtil.getIPAddress(myConfig.getPlatformHost())))){
            return connect2Platform(name);
        } else if((CUtil.getIPAddress(host).equals(CUtil.getIPAddress(myConfig.getLocalDpeHost())))){
            return connect2LocalDpe(name);
        } else {
            String udl = "cMsg://"+host+":"+ myConfig.getPlatformTcpPort() +"/cMsg/";
            return connect(name, udl, myConfig.getPlatformDescription());
        }
    }


    /**
     * Connects to the platform.
     * Note: platform udl is obtained from the config.CConfig singleton object.
     * @param name  client name
     * @return cMsg connection object
     * @throws CException
     */
    public Object connect2Platform(String name) throws CException {
        if(!isPlatformConnected()){
            plConnection =  connect(name,myConfig.getPlatformUdl(),myConfig.getPlatformDescription());
            if(CUtil.getIPAddress(myConfig.getLocalDpeHost()).equals(CUtil.getIPAddress(myConfig.getPlatformHost()))){
                dpeConnection = plConnection;
            }
            return plConnection;
        } else {
            return plConnection;
        }
    }

    /**
     * Connects to the local DPE.
     * Note: local DPE udl is obtained from the config.CConfig singleton object.
     * @param name  client name
     * @return cMsg connection object
     * @throws CException
     */
    public Object connect2LocalDpe(String name) throws CException {
        if(!isLocalDpeConnected()){
            dpeConnection =  (cMsg)connect(name,myConfig.getLocalDpeUdl(),myConfig.getPlatformDescription());
            if(CUtil.getIPAddress(myConfig.getLocalDpeHost()).equals(CUtil.getIPAddress(myConfig.getPlatformHost()))){
                plConnection = dpeConnection;
            }
            return dpeConnection;
        } else {
            return dpeConnection;
        }
    }


    /**
     * Closes a connection to a pub-sub server
     * @param connection cMsg connection object
     * @throws CException
     */
    public void disconnect(Object connection) throws CException{
        if(connection instanceof cMsg){
            cMsg con = (cMsg)connection;
            try {
                if(isConnected(con)){
                    con.disconnect();
                }
            } catch (cMsgException e) {
                throw new CException(e.getMessage());
            }
        }
    }

    /**
     * Disconnects from the platform pub-sub server
     * @throws CException
     */
    public void platformDisconnect() throws CException {
        disconnect(plConnection);
    }

    /**
     * Disconnects from the local DPE pub-sub server
     * @throws CException
     */
    public void localDpeDisconnect() throws CException {
        disconnect(dpeConnection);
    }

    /**
     * Checks if s connection to a pub-sub server is active
     * @param connection cMsg connection object
     * @return true or false
     */
    public boolean isConnected(Object connection){
        if(connection instanceof cMsg){
            cMsg con = (cMsg)connection;
            return (con !=null && con.isConnected());
        }
        return false;
    }

    /**
     * Check the platform pub-sub server connection
     * @return true or false
     */
    public boolean isPlatformConnected(){
        return isConnected(plConnection);
    }

    /**
     * Checks local DPE connection
     * @return true and false
     */
    public boolean isLocalDpeConnected(){
        return isConnected(dpeConnection);
    }

    /**
     * Sends a message using a connection object defined in the CTrParameter object.
     * In the case connection object is not defined (is null)
     * it will use its default, i.e. local DPE connection object to send a message.
     *
     * @param p {@link org.jlab.clara.pubsub.CTrParameter} object containing details to form a message for transport
     * @return  status of the operation
     */
    public boolean send(CTrParameter p) throws CException{
        boolean status = false;
        Object connection;

        // use the connection object defined in p
        if(p.getConnection()!=null) {
            connection = p.getConnection();
        } else {
            connection = dpeConnection;
        }

        if(connection instanceof cMsg){
            cMsg con = (cMsg)connection;
            // send the message defined in p
            if(!p.getSubject().equals(CConstants.udf) &&
                    !p.getType().equals(CConstants.udf) &&
                    isConnected(con)) {

                if(p.getMessage()!=null){

                    // add subject, type and text defined in the
                    // CtrParameter object to the cMsgMessage
                    p.getMessage().setSubject(p.getSubject());
                    p.getMessage().setType(p.getType());
                    p.getMessage().setText(p.getText());

                    // send the message
                    try {
                        con.send(p.getMessage());
                        status = true;
                    } catch (cMsgException e) {
                        throw new CException(e.getMessage());
                    }
                } else {

                    // message object is not defined in p
                    // create message based on the rest of the
                    // fields in p
                    cMsgMessage msg = new cMsgMessage();
                    msg.setSubject(p.getSubject());
                    msg.setType(p.getType());
                    msg.setText(p.getText());

                    // see if p defines payloadItems and add them to the msg
                    if(p.getPayloadItems()!=null)
                        for(cMsgPayloadItem item:p.getPayloadItems()){
                            msg.addPayloadItem(item);
                        }

                    try {
                        // see if p defines an object to be sent through msg byte array
                        if(p.getData()!=null){

                            // see if endiannes is defined for the data object
                            if(p.getEndian()>0){
                                msg.setByteArrayEndian(p.getEndian());
                            }

                            if(!(p.getData() instanceof byte[])){
                                // serialize the object into the byte array and add to the message
                                msg.setByteArray(CUtil.O2B(p.getData()));
                            }
                        }

                        // send the message
                        con.send(msg);
                        status = true;
                    } catch (cMsgException e) {
                        throw new CException(e.getMessage());
                    } catch (IOException e) {
                        throw new CException(e.getMessage());
                    }
                }
            }
        }
        return status;
    }

    /**
     * Sends a message synchronously using a connection object defined in the CTrParameter object.
     * In the case connection object is not defined (is null)
     * it will use its default, i.e. local DPE connection object to send a message.
     * Always returns a message that is never null.
     *
     * @param p {@link CTrParameter} object containing details to form a message for transport
     * @return  message containing information about the request
     */
    public cMsgMessage syncSend(CTrParameter p) throws CException{
        cMsgMessage out = null;
        Object connection;
        String result = "failed";

        // use the connection object defined in p
        if(p.getConnection()!=null) {
            connection = p.getConnection();
        } else {
            connection = dpeConnection;
        }

        if(connection instanceof cMsg){
            cMsg con = (cMsg)connection;
            // send the message defined in p
            if(!p.getSubject().equals(CConstants.udf) &&
                    !p.getType().equals(CConstants.udf) &&
                    isConnected(con)) {
                if(p.getMessage()!=null){

                    // add subject, type and text defined in
                    // the CtrParameter object to the cMsgMessage
                    p.getMessage().setSubject(p.getSubject());
                    p.getMessage().setType(p.getType());
                    p.getMessage().setText(p.getText());

                    // send the message
                    try {
                        out = con.sendAndGet(p.getMessage(), p.getTimeout());
                    } catch (cMsgException e) {
                        result = result+" "+e.getMessage();
                        throw new CException(result);
                    } catch (TimeoutException e) {
                        String errMsg = String.format("send timeout:  subject: %s  type: %s  (waited %d ms)%n",
                                p.getSubject(),
                                p.getType(),
                                p.getTimeout());
                        result = result+" "+errMsg;
                        throw new CException(result);
                    }
                } else {

                    // message object is not defined in p
                    // create message based on the rest of the
                    // fields in p
                    cMsgMessage msg = new cMsgMessage();
                    msg.setSubject(p.getSubject());
                    msg.setType(p.getType());
                    msg.setText(p.getText());

                    // see if p defines payloadItems and add them to the msg
                    if(p.getPayloadItems()!=null)
                        for(cMsgPayloadItem item:p.getPayloadItems()){
                            msg.addPayloadItem(item);
                        }

                    try {

                        // see if p defines an object to be sent through msg byte array
                        if(p.getData()!=null){

                            // see if endiannes is defined for the data object
                            if(p.getEndian()>0){
                                msg.setByteArrayEndian(p.getEndian());
                            }

                            if(!(p.getData() instanceof byte[])){
                                // serialize the object into the byte array and add to the message
                                msg.setByteArray(CUtil.O2B(p.getData()));
                            }
                        }

                        // send the message
                        out = con.sendAndGet(msg, p.getTimeout());
                    } catch (cMsgException e) {
                        result = result+" "+e.getMessage();
                        throw new CException(result);
                    } catch (IOException e) {
                        result = result+" "+e.getMessage();
                        throw new CException(result);
                    } catch (TimeoutException e) {
                        String errMsg = String.format("send timeout:  subject: %s  type: %s  (waited %d ms)%n",
                                p.getSubject(),
                                p.getType(),
                                p.getTimeout());
                        result = result+" "+errMsg;
                        throw new CException(result);
                    }
                }
            }
        }
        if(out==null){
            out = new cMsgMessage();
            out.setText(result);
        }
        return out;
    }

}
