/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */


package org.jlab.clara.examples.orchestrator.check;


import org.jlab.clara.constants.CConstants;
import org.jlab.clara.frontend.JOrchestrator;
import org.jlab.clara.system.CException;

/**
 *
 * Finds a service with a specific engine name.
 * Note: service engine name is a user specified name, given at the
 * interface <code>ICService</coda> implementation.
 * It returns a service that is local to this orchestrator or
 * the remote service that has the smallest load.
 *
 * @author gurjyan
 * @version 3.x
 */

public class ServiceByEngineName extends JOrchestrator {

    /**
     * Constructor
     * Connects to the Clara platform
     *
     */
    public ServiceByEngineName() throws CException {
        super();
    }

    public static void main(String[] args) {
        String engineName  = args[0];

        // an instance of this class
        ServiceByEngineName rso;
        try {
            rso = new ServiceByEngineName();

        // get registration information form the platform normative service
        rso.requestRegistrationData(1000);

        // get the service canonical name that has a required engine name.
        String serviceName = rso.getServiceNameByEngineName(engineName);
        if(!serviceName.equals(CConstants.udf)){

            // print service information
            System.out.println(rso.getServiceInformation(serviceName));
        } else {
            System.out.println("No service with the specified " +
                    "engine name = "+engineName+" was found.");
        }
            rso.exit();
        } catch (CException e) {
            System.out.println(e.getMessage());
        }
    }
}
