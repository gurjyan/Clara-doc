/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */


package org.jlab.clas12.services.system;

import org.jlab.clara.constants.CConstants;
import org.jlab.clara.data.JioSerial;
import org.jlab.clara.frontend.JService;
import org.jlab.clas12.tools.MimeType;
import org.jlab.clara.system.CException;
import org.jlab.clara.util.CUtil;
import org.jlab.clara.util.StdIO;

import java.io.File;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author gurjyan
 * @version 3.x
 */
public class TapeManager extends JService {

    private List<String> inputFiles;
    private String destinationDirectory;
    private String sourceDirectory;

    private final static String NAME = "TapeManager";

    private static final String CACHE_DISK_GROUP = "clas";
    private static final String PIN_MAX = "20";
    private static final String UNPIN   = "0";

    private final static int TIME_OUT = 1800;

    protected TapeManager(String name) {
        super(name);
    }

    /**
     * cache the file from the tape silo
     * @param tfn tape file full name
     */
    private void cashFromSilo(String tfn){
        try {
            List<String> jcachFile = Arrays.asList("jcache submit", CACHE_DISK_GROUP, tfn);
            StdIO result = CUtil.fork(jcachFile, true);

            if (result.getExitValue() == 0) {
                System.out.printf("Request data file '%s' from the tape. Destination =  '%s'%n", tfn, CACHE_DISK_GROUP);
            } else {
                String msg = String.format("Could not jcache input file%n%n%s", result.getStderr());
                System.out.println(msg);
            }
        } catch (CException e) {
            String msg = String.format("Could not jcache input file%n%n%s", CUtil.reportException(e));
            System.out.println(msg);
        }

    }

    /**
     * Pine (not allow deleting) a file for a certain days.
     * @param dfn file full name
     * @param pin number of days. 0 means scheduling file for deletion
     */
    private void pineFile(String dfn, String pin){

        try {
            List<String> jcachPinFile = Arrays.asList("jcache pin", CACHE_DISK_GROUP, pin, dfn);
            StdIO result = CUtil.fork(jcachPinFile, true);
            if (result.getExitValue() == 0) {
                System.out.printf("File '%s' is pinned for '%s' days %n",dfn,pin);
            } else {
                String msg = String.format("Could not pine a file%n%n%s", result.getStderr());
                System.out.println(msg);
            }
        } catch (CException e) {
            String msg = String.format("Could not pine a file%n%n%s", CUtil.reportException(e));
            System.out.println(msg);
        }
    }

    /**
     * @param timeout in seconds
     */
    private void tapeFileTransfer(int timeout){
        boolean done;
        if(inputFiles!=null && !inputFiles.isEmpty()) {
            for(String fn:inputFiles){
                String tfn = sourceDirectory+ File.separator+fn;
                String dfn = destinationDirectory +File.separator+fn;
                File f = new File(dfn);
                if(!f.exists()){
                    cashFromSilo(tfn);
                }
            }

            for(int i = 0;i<timeout;i++){
                done = true;
                for(String fn:inputFiles){
                    // check if file exists
                    String dfn = destinationDirectory +File.separator+fn;
                    File f = new File(dfn);
                    if(!f.exists()){
                        System.out.println("Transferring.... file = "+dfn);
                        done = false;
                        CUtil.sleep(1000);
                    } else {
                        pineFile(dfn,PIN_MAX);
                    }
                }
                if (done){
                    System.out.println("Done transferring files from the tape silo.");
                    return;
                } else {
                    System.out.println("Error-timeout: Faild to transfer files from silo. ");
                }
            }
        }
    }


    @Override
    public void configure(JioSerial data) {
        if((data.getMimeType().equals(MimeType.JOBJECT)) &&
                (data.getDataAsObject() instanceof TapeManagerConfig)){
            TapeManagerConfig cfg = (TapeManagerConfig)data.getDataAsObject();
            inputFiles = cfg.getDataFiles();
            sourceDirectory = cfg.getTapeLocation();
            destinationDirectory = cfg.getDestination();
        }
    }

    @Override
    public JioSerial execute(JioSerial data) {
        if(data.getMimeType().equals(MimeType.STRING)){
            String cmd = data.getStringObject();

            // start requesting files from the tape silo,
            if(cmd.equals(CConstants.COMMAND_START)){
                new TapeFileTransferThread(TIME_OUT).start();

                // mark for deletion cached files
            } else if(cmd.equals(CConstants.COMMAND_CLEAR)) {
                for(String fn:inputFiles){
                    // check if file exists
                    String ffp = destinationDirectory +File.separator+fn;
                    File f = new File(ffp);
                    if(!f.exists()){
                        pineFile(ffp,UNPIN);
                    }
                }
            }
        }
        return null;
    }

    @Override
    public JioSerial execute(JioSerial[] data) {
        return null;
    }

    @Override
    public void destruct() {
    }

    @Override
    public String getName() {
        return NAME;
    }

    @Override
    public String getAuthor() {
        return "V. Gyurjyan";
    }

    @Override
    public String getDescription() {
        return "Manages file transfer from and to tape silo";
    }

    @Override
    public String getVersion() {
        return "1.0";
    }

    @Override
    public String getLanguage() {
        return CConstants.LANG_JAVA;
    }

    private class TapeFileTransferThread extends Thread {
        private int timeOut;

        public TapeFileTransferThread(int to){
            timeOut = to;
        }

        @Override
        public void run() {
            tapeFileTransfer(timeOut);
        }
    }

}
