/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */
package org.jlab.clara.examples.orchestrator.check;


import org.jlab.clara.frontend.JOrchestrator;
import org.jlab.clara.system.CException;

import java.util.Collections;
import java.util.List;

/**
 * An example orchestrator that
 * prints the topology of the CLARA cloud.
 *
 * @author gurjyan
 * @version 3.x
 */
public class CloudTopology extends JOrchestrator {

    /**
     * Constructor.
     * Connects to the local DPE and to the platform.
     */
    public CloudTopology() throws CException {
        super();
    }


    public static void main(String[] args) {
        boolean printDot = false;
        if (args.length == 1 && args[0].equals("-dot")) {
            printDot = true;
        }

        CloudTopology orc = null;
        try {
            orc = new CloudTopology();
        if (orc.isPlatformConnected()) {
            if (printDot) {
                System.out.println(orc.dotFormat());
            } else {
                System.out.println(orc.topology());
            }
            orc.exit();
        }
        } catch (CException e) {
            System.out.println(e.getMessage());
        }
    }


    private String dotFormat() throws CException {
        try {
            requestRegistrationData(1000);
        } catch (CException e) {
            System.out.println(e.getMessage());
        }
        StringBuilder sb = new StringBuilder();
        sb.append("digraph CLARA {\n");
        sb.append("node [ fontcolor=blue, fontsize=8];\n");
        for (String con : getContainerNames()) {
            // service names
            for (String s : getServiceNames(con)) {
                sb.append("\"").append(s).append("\"");
                for (String l : getLinks(s, 1000)) {
                    sb.append(" -> ").append("\"").append(l).append("\"");
                }
                sb.append(";\n");
            }
        }
        sb.append("}\n");
        return sb.toString();
    }


    public String topology() throws CException {
        StringBuilder sb = new StringBuilder();
        // platform name
        sb.append("Platform = ").append(getPlatformName()).append("\n");
        requestRegistrationData(1000);

        // container names
        List<String> containers = getContainerNames();
        Collections.sort(containers);
        for (String con : containers) {
            sb.append("\nContainer = ").append(con).append("\n");
            // service names
            List<String> services = getServiceNames(con);
            Collections.sort(services);
            for (String s : services) {
                sb.append("  ").append(s).append("\n");
            }
        }
        return sb.toString();
    }
}
