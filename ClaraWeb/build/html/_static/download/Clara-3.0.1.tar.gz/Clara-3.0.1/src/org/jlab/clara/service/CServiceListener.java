/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */


package org.jlab.clara.service;

import org.jlab.clara.data.CShareDataRep;

/**
 * @author gurjyan
 * @author Sebastian Mancilla
 * @version 3.x
 */
public class CServiceListener
{
    private final String name;
    private final String subject;
    private final String type;
    private final boolean inJvm;

    public CServiceListener(String rName, String rSubject, String rType)
    {
        name = rName;
        subject = rSubject;
        type = rType;
        inJvm = CShareDataRep.isInJvm(name);
    }


    public String getName()
    {
        return name;
    }


    public String getSubject()
    {
        return subject;
    }


    public String getType()
    {
        return type;
    }


    public boolean isInJvm()
    {
        return inJvm;
    }


    @Override
    public int hashCode()
    {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((name == null) ? 0 : name.hashCode());
        result = prime * result + ((subject == null) ? 0 : subject.hashCode());
        result = prime * result + ((type == null) ? 0 : type.hashCode());
        return result;
    }


    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        CServiceListener other = (CServiceListener) obj;
        if (name == null) {
            if (other.name != null)
                return false;
        } else if (!name.equals(other.name))
            return false;
        if (subject == null) {
            if (other.subject != null)
                return false;
        } else if (!subject.equals(other.subject))
            return false;
        if (type == null) {
            if (other.type != null)
                return false;
        } else if (!type.equals(other.type))
            return false;
        return true;
    }
}
