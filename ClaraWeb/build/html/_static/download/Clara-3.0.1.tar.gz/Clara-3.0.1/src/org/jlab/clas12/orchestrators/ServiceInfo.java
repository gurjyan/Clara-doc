/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */
package org.jlab.clas12.orchestrators;

/**
 * Stores the general properties of a service.
 * <p>
 * Currently, these properties are:
 * <ul>
 * <li>name (ex: {@code ECReconstruction})
 * <li>the full classpath (ex: {@code org.jlab.examples.clas12.ec.services.ECReconstruction})
 * <li>the container where the service should be deployed (ex: {@code ec-cont})
 * </ul>
 * Note that this class doesn't represent a deployed service in a DPE, but a
 * template that keeps the name and container of the service. Orchestrators should
 * use the data of this class combined with the values in {@link DpeInfo} to
 * fully identify individual deployed services (i.e. the canonical name).
 */
class ServiceInfo {

    final String name;
    final String classpath;
    final String cont;


    public ServiceInfo(String classpath, String cont, String name) {
        this.classpath = classpath;
        this.cont = cont;
        this.name = name;
    }


    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result
                + ((classpath == null) ? 0 : classpath.hashCode());
        result = prime * result + ((cont == null) ? 0 : cont.hashCode());
        result = prime * result + ((name == null) ? 0 : name.hashCode());
        return result;
    }


    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof ServiceInfo)) {
            return false;
        }
        ServiceInfo other = (ServiceInfo) obj;
        if (classpath == null) {
            if (other.classpath != null) {
                return false;
            }
        } else if (!classpath.equals(other.classpath)) {
            return false;
        }
        if (cont == null) {
            if (other.cont != null) {
                return false;
            }
        } else if (!cont.equals(other.cont)) {
            return false;
        }
        if (name == null) {
            if (other.name != null) {
                return false;
            }
        } else if (!name.equals(other.name)) {
            return false;
        }
        return true;
    }
}
