/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */


package org.jlab.clara.service;


import org.jlab.clara.constants.CConstants;

import java.io.Serializable;

/**
 *
 * @author gurjyan
 * @version 3.x
 */

public class CServiceRegistration implements Serializable {
    private String registrationName = CConstants.udf;
    private String description      = CConstants.udf;
    private String author           = CConstants.udf;
    private String version          = CConstants.udf;
    private String language         = CConstants.udf;

    public String getRegistrationName() {
        return registrationName;
    }

    public void setRegistrationName(String registrationName) {
        this.registrationName = registrationName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String[] getAsArray(){
        String[] as = new String[6];
        as[0] = registrationName;
        as[1] = author;
        as[2] = version;
        as[3] = description;
        return as;
    }

    @Override
    public String toString() {
        return "Service:\n" +
                "  Name        = " + registrationName + "\n" +
                "  Description = " + description + "\n" +
                "  Author      = " + author + "\n" +
                "  Version     = " + version + "\n" +
                "  Language    = " + language + "\n\n";
    }
    public String toHtmlString() {
        return "<font color =\"blue\"> Clara Service </font><br> " +
                "<table border=\"1\" cellpadding=\"0\" cellspacing=\"0\">" +
                "<tr>" +
                "<td> Name </td> " +
                "<td>" + registrationName + "</td> " +
                "</tr>" +
                "<tr>" +
                "<td> Description </td>" +
                "<td>" + description + "</td>" +
                "</tr>" +
                "<tr>" +
                "<td< Author </td>" +
                "<td>" + author +  "</td>" +
                "</tr>" +
                "<tr>" +
                "<td> Version </td>" +
                "<td>" + version + "</td>" +
                "</tr>" +
                "<tr>" +
                "<td> Language </td>" +
                "<td>" + language + "</td>" +
                "</tr>" +
                "</table>";
    }
}
