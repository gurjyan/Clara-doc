/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */


package org.jlab.clara.examples.service;

import org.jlab.clara.constants.CConstants;
import org.jlab.clara.data.JioSerial;
import org.jlab.clara.frontend.JService;
import org.jlab.clas12.tools.MimeType;
import org.jlab.clara.util.CUtil;

public class DelayService extends JService {
    int delay = 20;
    String NAME = "DelayService";

    protected DelayService(String name) {
        super(name);
    }

    @Override
    public void configure(JioSerial data) {
        MimeType mimeType = data.getMimeType();
        switch (mimeType) {
        case STRING:
            delay = Integer.parseInt(data.getStringObject());
            break;
        case INT:
            delay = data.getIntObject();
            System.out.println(NAME + " service: configuring delay = " + delay + " ms");
            break;
        default:
            System.err.println(NAME + " service: wrong configuration mime-type = " + mimeType);
        }
    }

    @Override
    public JioSerial execute(JioSerial data) {
        CUtil.sleep(delay);
        JioSerial out = new JioSerial();
        out.setData(data.getDataAsByteBuffer(), MimeType.EVIO);
        out.setStatus(CConstants.info);
        out.setDataDescription("data");
        return out;
    }

    @Override
    public JioSerial execute(JioSerial[] data) {
        return null;
    }

    @Override
    public void destruct() {

    }

    @Override
    public String getName() {
        return NAME;
    }

    @Override
    public String getAuthor() {
        return "Sebouh Paul";
    }

    @Override
    public String getDescription() {
        return "Delays for a specified number of ms";
    }

    @Override
    public String getVersion() {
        return "1.0";
    }

    @Override
    public String getLanguage() {
        return CConstants.LANG_JAVA;
    }

}
