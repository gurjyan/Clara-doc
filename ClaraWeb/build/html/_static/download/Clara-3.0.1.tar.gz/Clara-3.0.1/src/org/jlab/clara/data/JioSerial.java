/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */


package org.jlab.clara.data;

import org.jlab.clas12.tools.MimeType;
import org.jlab.clas12.tools.property.JPropertyList;
import org.jlab.coda.cMsg.cMsgConstants;
import org.jlab.coda.cMsg.cMsgException;
import org.jlab.coda.cMsg.cMsgMessage;
import org.jlab.coda.cMsg.cMsgPayloadItem;
import org.jlab.clara.constants.CConstants;
import org.jlab.clara.constants.CSISConstants;
import org.jlab.clara.system.CException;
import org.jlab.clara.util.CLogger;
import org.jlab.clara.util.CUtil;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * @author gurjyan
 * @version 3.x
 */
public class JioSerial {

    // data fields
    private Object      data;
    private MimeType    mimeType             = MimeType.UNDEFINED;
    private ByteOrder   dataEndianness       = ByteOrder.nativeOrder();
    private String      dataDescription      = CConstants.udf;
    private String      dataUnit             = CConstants.udf;

    // status fields
    private int         requestID            = -1;
    private String      status               = CConstants.udf;
    private String      language             = CConstants.udf;
    private double      version              = 0;

    // framework control fields
    private String      engineControl        = CConstants.udf;

    private String      dataSource           = CConstants.udf;
    private String      dataDestination      = CConstants.udf;

    private String      doneBroadcast        = "false";
    private String      dataBroadcast        = "false";

    private String      exceptionSource      = CConstants.udf;
    private String      exceptionDestination = CConstants.udf;

    private String      logMessage           = CConstants.udf;

    // local instance of the logger object
    private CLogger lg = CLogger.getInstance();


    /**
     * Default constructor
     */
    public JioSerial(){}

    /**
     * Constructor
     * @param data            object of the transient data
     */
    public JioSerial(Object data){
        this.data = data;
        mimeType  = CUtil.defineMimeType(data);
    }

    /**
     * Constructor
     * @param data            object of the transient data
     * @param m               transient data mime-type
     */
    public JioSerial(Object data, MimeType m){
        this.data     = data;
        this.mimeType = m;
    }

    public JioSerial(ByteBuffer data, MimeType m) {
        this.data = CUtil.getByteArray(data);
        this.dataEndianness = data.order();
        this.mimeType = m;
    }

    /**
     * Constructor that takes a property list as an argument
     * @param pl {@link JPropertyList} object
     */
    public JioSerial(JPropertyList pl){
        data = pl.getStringRepresentation(true);
        mimeType = MimeType.PROPERTY_LIST;
    }

    /**
     * Constructor
     * @param data ByteBuffer representing data
     * @param startPosition starting position of the data section
     * @param endPosition  end position of the data section
     * @param m mime type of the data
     */
    @Deprecated
    public JioSerial(ByteBuffer data, int startPosition, int  endPosition, MimeType m){
        byte[] b = new byte[endPosition-startPosition];
        data.get(b,startPosition,endPosition);
        this.data = b;
        this.dataEndianness = data.order();
        this.mimeType = m;
    }

    /**
     * Constructor
     * @param msg  cMsgMessage object containing the the transient data
     */
    public JioSerial(cMsgMessage msg){
        unPackEnvelope(msg);
    }

    /**
     * Builds/fills the cMsgMessage for transfer through the wire
     * Mime types representing object (Object, evio, hdf5, cobject, jobjet,
     * will be packed in the cMsg byte array field.
     * The rest will be packed in the payload item.
     * @param   al ArrayList containing required cMsgPayloadItem objects
     * @param   msgOut <code>cMsgMessage</code> user object
     * @return  cMsgMessage containing transient data ready for transfer
     */
    public cMsgMessage packEnvelope(ArrayList<cMsgPayloadItem> al, cMsgMessage msgOut) throws CException {
        boolean isCpp = false;

        // check to see if this msg is going to be sent to c++ service.
        // Mote deprecated 1.7 c++ implementation support
        // in this implementation all data is sent through
        // cMsgMessage byte-array field
        try {
            if(msgOut.getPayloadItem(CSISConstants.SERVICE_LANGUAGE)!=null){
                language = msgOut.getPayloadItem(CSISConstants.SERVICE_LANGUAGE).getString();
                if(language.equals(CConstants.LANG_CPP)){
                    isCpp = true;
                }
            }
            switch(mimeType){
                case  OBJECT:
                case  EVIO:
                case  IG5:
                case  COBJECT:
                    msgOut.setByteArray((byte[]) data);
                    break;
                case  JOBJECT:
                    msgOut.setByteArray(CUtil.O2B(data));
                    msgOut.setByteArrayEndian(cMsgConstants.endianBig);
                    break;
                case  BYTE:
                    byte b= (Byte)data;
                    al.add(new cMsgPayloadItem(CSISConstants.SERVICE_DATA,b));
                    break;
                case  SHORT:
                    short s = (Short)data;
                    al.add(new cMsgPayloadItem(CSISConstants.SERVICE_DATA,s));
                    break;
                case  INT:
                    int i = (Integer)data;
                    al.add(new cMsgPayloadItem(CSISConstants.SERVICE_DATA,i));
                    break;
                case  FLOAT:
                    float f = (Float)data;
                    al.add(new cMsgPayloadItem(CSISConstants.SERVICE_DATA,f));
                    break;
                case  DOUBLE:
                    double d = (Double)data;
                    al.add(new cMsgPayloadItem(CSISConstants.SERVICE_DATA,d));
                    break;
                case  STRING:
                case  PROPERTY_LIST:
                    if(isCpp){
                        String ss = (String)data;
                        msgOut.setByteArray(ss.getBytes());
                    } else {
                        al.add(new cMsgPayloadItem(CSISConstants.SERVICE_DATA,(String)data));
                    }
                    break;
                case  BYTE_ARRAY:
                    al.add(new cMsgPayloadItem(CSISConstants.SERVICE_DATA,(byte[])data));
                    break;
                case  SHORT_ARRAY:
                    al.add(new cMsgPayloadItem(CSISConstants.SERVICE_DATA,(short[])data));
                    break;
                case  INT_ARRAY:
                    al.add(new cMsgPayloadItem(CSISConstants.SERVICE_DATA,(int[])data));
                    break;
                case  FLOAT_ARRAY:
                    al.add(new cMsgPayloadItem(CSISConstants.SERVICE_DATA,(float[])data));
                    break;
                case  DOUBLE_ARRAY:
                    al.add(new cMsgPayloadItem(CSISConstants.SERVICE_DATA,(double[])data));
                    break;
                case  STRING_ARRAY:
                    String[] x = (String[])data;
                    al.add(new cMsgPayloadItem(CSISConstants.SERVICE_DATA,x));
                    break;
            }

            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_DATA_MIME_TYPE, mimeType.type()));
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_DATA_ENDIANNESS, dataEndianness.toString()));
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_DATA_DESCRIPTION,dataDescription));
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_DATA_UNIT,dataUnit));
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_REQUEST_ID, requestID));
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_DATA_VERSION,version));
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_ENGINE_CONTROL,engineControl));
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_STATUS,status));
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_LOG_MESSAGE,logMessage));
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_LANGUAGE,language));
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_EXCEPTION_DESTINATION, exceptionDestination));
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_EXCEPTION_SOURCE,exceptionSource));
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_DATA_DESTINATION, dataDestination));

            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_DONE_BROADCAST, doneBroadcast));
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_DATA_BROADCAST, dataBroadcast));

            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_DATA_SOURCE,dataSource));

            for(cMsgPayloadItem i:al){
                msgOut.addPayloadItem(i);
            }

        } catch (cMsgException e) {
            throw new CException(e.getMessage());
        } catch (IOException e) {
            throw new CException(e.getMessage());
        }
        return msgOut;
    }

    public cMsgMessage packEnvelopeNoData(ArrayList<cMsgPayloadItem> al, cMsgMessage msgOut){

        try {
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_DATA_MIME_TYPE, mimeType.type()));
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_DATA_ENDIANNESS, dataEndianness.toString()));
        al.add(new cMsgPayloadItem(CSISConstants.SERVICE_DATA_DESCRIPTION,dataDescription));
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_DATA_UNIT,dataUnit));
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_DATA_VERSION,version));
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_ENGINE_CONTROL,engineControl));
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_STATUS,status));
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_LOG_MESSAGE,logMessage));
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_LANGUAGE,language));
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_EXCEPTION_DESTINATION, exceptionDestination));
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_EXCEPTION_SOURCE,exceptionSource));
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_DATA_DESTINATION, dataDestination));

            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_DONE_BROADCAST, doneBroadcast));
            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_DATA_BROADCAST, dataBroadcast));

            al.add(new cMsgPayloadItem(CSISConstants.SERVICE_DATA_SOURCE,dataSource));

            for(cMsgPayloadItem i:al){
                msgOut.addPayloadItem(i);
            }
        } catch (cMsgException e) {
            e.printStackTrace();
        }

        return msgOut;
    }

    /**
     * Unpacks the envelope from the message and furnishes JioSerial transient data object
     * Note that in 1.7 c++ property lists as well as all the other primitive types are
     * shipped through the msg byte array.
     * @param msg cMsgMessage object that contains payload structure for the meta-data
     * @return boolean describing the status of converting cMsgMessage into JioSerial
     */
    public boolean unPackEnvelope(cMsgMessage msg){
        boolean success = true;
        boolean isCpp   = false;

        // meta-data
        dataSource      = msg.getSender();
        dataDestination = msg.getReceiver();
        try {
            if(msg.getPayloadItem(CSISConstants.SERVICE_DATA_SOURCE)!=null){
                dataSource = msg.getPayloadItem(CSISConstants.SERVICE_DATA_SOURCE).getString();
            }
            if(msg.getPayloadItem(CSISConstants.SERVICE_DATA_DESTINATION)!=null){
                dataDestination = msg.getPayloadItem(CSISConstants.SERVICE_DATA_DESTINATION).getString();
            }

            if(msg.getPayloadItem(CSISConstants.SERVICE_DATA_BROADCAST)!=null){
                dataBroadcast = msg.getPayloadItem(CSISConstants.SERVICE_DATA_BROADCAST).getString();
            }
            if(msg.getPayloadItem(CSISConstants.SERVICE_DONE_BROADCAST)!=null){
                doneBroadcast = msg.getPayloadItem(CSISConstants.SERVICE_DONE_BROADCAST).getString();
            }

            if(msg.getPayloadItem(CSISConstants.SERVICE_DATA_MIME_TYPE)!=null){
                String mt = msg.getPayloadItem(CSISConstants.SERVICE_DATA_MIME_TYPE).getString();
                mimeType = MimeType.getMimeType(mt);
            }
            if(msg.getPayloadItem(CSISConstants.SERVICE_DATA_ENDIANNESS)!=null){
                String mt = msg.getPayloadItem(CSISConstants.SERVICE_DATA_ENDIANNESS).getString();
                if(mt.equals(ByteOrder.BIG_ENDIAN.toString())){
                    dataEndianness = ByteOrder.BIG_ENDIAN;
                } else {
                dataEndianness = ByteOrder.LITTLE_ENDIAN;
                }
            }
            if(msg.getPayloadItem(CSISConstants.SERVICE_DATA_DESCRIPTION)!=null)
                dataDescription = msg.getPayloadItem(CSISConstants.SERVICE_DATA_DESCRIPTION).getString();

            if(msg.getPayloadItem(CSISConstants.SERVICE_DATA_UNIT)!=null)
                dataUnit = msg.getPayloadItem(CSISConstants.SERVICE_DATA_UNIT).getString();

            if(msg.getPayloadItem(CSISConstants.SERVICE_REQUEST_ID)!=null)
                requestID = msg.getPayloadItem(CSISConstants.SERVICE_REQUEST_ID).getInt();

            if(msg.getPayloadItem(CSISConstants.SERVICE_ENGINE_CONTROL)!=null)
                engineControl = msg.getPayloadItem(CSISConstants.SERVICE_ENGINE_CONTROL).getString();

            if(msg.getPayloadItem(CSISConstants.SERVICE_STATUS)!=null)
                status = msg.getPayloadItem(CSISConstants.SERVICE_STATUS).getString();

            if(msg.getPayloadItem(CSISConstants.SERVICE_LOG_MESSAGE)!=null)
                logMessage = msg.getPayloadItem(CSISConstants.SERVICE_LOG_MESSAGE).getString();

            if(msg.getPayloadItem(CSISConstants.SERVICE_DATA_VERSION)!=null)
                version = msg.getPayloadItem(CSISConstants.SERVICE_DATA_VERSION).getDouble();

            if(msg.getPayloadItem(CSISConstants.SERVICE_EXCEPTION_DESTINATION)!=null)
                exceptionDestination = msg.getPayloadItem(CSISConstants.SERVICE_EXCEPTION_DESTINATION).getString();

            if(msg.getPayloadItem(CSISConstants.SERVICE_EXCEPTION_SOURCE)!=null)
                exceptionSource = msg.getPayloadItem(CSISConstants.SERVICE_EXCEPTION_SOURCE).getString();

            if(msg.getPayloadItem(CSISConstants.SERVICE_LANGUAGE)!=null){
                language = msg.getPayloadItem(CSISConstants.SERVICE_LANGUAGE).getString();
                if(language.equals(CConstants.LANG_CPP)){
                    isCpp = true;
                }
            }

            if(!mimeType.type().equals(CConstants.udf)){

                switch(mimeType){
                    case  OBJECT:
                    case  EVIO:
                    case  IG5:
                    case  COBJECT:
                        data = msg.getByteArray();
                        break;
                    case  JOBJECT:
                        data = CUtil.B2O(msg.getByteArray());
                        break;
                    case  BYTE:
                        data = msg.getPayloadItem(CSISConstants.SERVICE_DATA).getByte();
                        break;
                    case  SHORT:
                        data = msg.getPayloadItem(CSISConstants.SERVICE_DATA).getShort();
                        break;
                    case  INT:
                        data  = msg.getPayloadItem(CSISConstants.SERVICE_DATA).getInt();
                        break;
                    case  FLOAT:
                        data = msg.getPayloadItem(CSISConstants.SERVICE_DATA).getFloat();
                        break;
                    case  DOUBLE:
                        data  = msg.getPayloadItem(CSISConstants.SERVICE_DATA).getDouble();
                        break;
                    case  STRING:
                    case  PROPERTY_LIST:
                        if(isCpp){
                            data = new String(msg.getByteArray());
                        } else {
                            data = msg.getPayloadItem(CSISConstants.SERVICE_DATA).getString();
                        }
                        break;
                    case  BYTE_ARRAY:
                        data = msg.getPayloadItem(CSISConstants.SERVICE_DATA).getByteArray();
                        break;
                    case  SHORT_ARRAY:
                        data = msg.getPayloadItem(CSISConstants.SERVICE_DATA).getShortArray();
                        break;
                    case  INT_ARRAY:
                        data = msg.getPayloadItem(CSISConstants.SERVICE_DATA).getIntArray();
                        break;
                    case  FLOAT_ARRAY:
                        data = msg.getPayloadItem(CSISConstants.SERVICE_DATA).getFloatArray();
                        break;
                    case  DOUBLE_ARRAY:
                        data = msg.getPayloadItem(CSISConstants.SERVICE_DATA).getDoubleArray();
                        break;
                    case  STRING_ARRAY:
                        data = msg.getPayloadItem(CSISConstants.SERVICE_DATA).getStringArray();
                        break;
                }
            }
        } catch (cMsgException e) {
            lg.logger.severe(CUtil.stack2str(e));
            success = false;
        } catch (ClassNotFoundException e) {
            lg.logger.severe(CUtil.stack2str(e));
            success = false;
        } catch (IOException e) {
            lg.logger.severe(CUtil.stack2str(e));
            success = false;
        }

        return success;
    }


    public void setData(Object data) {
        this.data = data;
        mimeType  = CUtil.defineMimeType(data);
    }

    public void setData(Object data, MimeType mimeType) {
        this.data = data;
        this.mimeType = mimeType;
    }

    public void setData(ByteBuffer data, MimeType mimeType) {
        this.data = CUtil.getByteArray(data);
        this.dataEndianness = data.order();
        this.mimeType = mimeType;
    }

    public void setData(JPropertyList pl) {
        this.data = pl.getStringRepresentation(true);
        this.mimeType = MimeType.PROPERTY_LIST;
    }

    public void setDataDescription(String dataDescription) {
        this.dataDescription = dataDescription;
    }

    public void setDataUnit(String dataUnit) {
        this.dataUnit = dataUnit;
    }


    public void setStatus(String status) {
        this.status = status;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public void setVersion(double version) {
        this.version = version;
    }


    public void setEngineControl(String engineControl) {
        this.engineControl = engineControl;
    }

    public void setDataSource(String dataSource) {
        this.dataSource = dataSource;
    }

    public void setDataDestination(String dataDestination) {
        this.dataDestination = dataDestination;
    }

    public void setExceptionSource(String exceptionSource) {
        this.exceptionSource = exceptionSource;
    }

    public void setExceptionDestination(String exceptionDestination) {
        this.exceptionDestination = exceptionDestination;
    }


    public String getEngineControl() {
        return engineControl;
    }

    public String getDataSource() {
        return dataSource;
    }

    public String getDataDestination() {
        return dataDestination;
    }

    public String getExceptionSource() {
        return exceptionSource;
    }

    public String getExceptionDestination() {
        return exceptionDestination;
    }


    public MimeType getMimeType() {
        return mimeType;
    }

    public String getDataDescription() {
        return dataDescription;
    }

    public String getDataUnit() {
        return dataUnit;
    }

    public String getStatus() {
        return status;
    }

    public String getLanguage() {
        return language;
    }

    public double getVersion() {
        return version;
    }


    public String getStringObject() {
        return (String)data;
    }

    public short getShortObject() {
        return (Short)data;
    }

    public int getIntObject() {
        return (Integer)data;
    }

    public float getFloatObject() {
        return (Float)data;
    }

    public double getDoubleObject() {
        return (Double)data;
    }

    public String[] getStringArrObject() {
        return (String[])data;
    }

    public short[] getShortArrObject() {
        return (short[])data;
    }

    public int[] getIntArrObject() {
        return (int[])data;
    }

    public float[] getFloatArrObject() {
        return (float[])data;
    }

    public double[] getDoubleArrObject() {
        return (double[])data;
    }

    public JPropertyList getPropertyList(){
        return new JPropertyList((String)data);
    }

    public Object getDataAsObject() {
        return data;
    }

    public int getRequestID() {
        return requestID;
    }

    public void setRequestID(int requestID) {
        this.requestID = requestID;
    }

    public ByteOrder getDataEndianness() {
        return dataEndianness;
    }

    public void setDataEndianness(ByteOrder dataEndianness) {
        this.dataEndianness = dataEndianness;
    }

    public String getDoneBroadcast() {
        return doneBroadcast;
    }

    public void setDoneBroadcast(String doneBroadcast) {
        this.doneBroadcast = doneBroadcast;
    }

    public String getDataBroadcast() {
        return dataBroadcast;
    }

    public void setDataBroadcast(String dataBroadcast) {
        this.dataBroadcast = dataBroadcast;
    }

    public byte[] getDataAsByteArray()
    {
        ByteBuffer b;
        byte[] result = null;
        switch(mimeType){
            case  OBJECT:
            case  EVIO:
            case  IG5:
            case  COBJECT:
                result = (byte[]) data;
                break;
            case  JOBJECT:
                try {
                    result = CUtil.O2B(data);
                } catch (IOException e) {
                    lg.logger.severe(CUtil.stack2str(e));
                }
                break;
            case  STRING:
            case  PROPERTY_LIST:
                String s = (String)data;
                result = s.getBytes();
                break;
            case  BYTE:
                b = ByteBuffer.allocate(1);
                b.order(ByteOrder.BIG_ENDIAN);
                b.put((Byte)data);
                result = b.array();
                break;
            case  SHORT:
                b = ByteBuffer.allocate(2);
                b.order(ByteOrder.BIG_ENDIAN);
                b.putShort((Short)data);
                result = b.array();
                break;
            case  INT:
                b = ByteBuffer.allocate(4);
                b.order(ByteOrder.BIG_ENDIAN);
                b.putInt((Integer)data);
                result = b.array();
                break;
            case  FLOAT:
                b = ByteBuffer.allocate(4);
                b.order(ByteOrder.BIG_ENDIAN);
                b.putFloat((Float)data);
                result = b.array();
                break;
            case  DOUBLE:
                b = ByteBuffer.allocate(8);
                b.order(ByteOrder.BIG_ENDIAN);
                b.putDouble((Double)data);
                result = b.array();
                break;
            default:
                result = (byte[]) data;
        }
        return result;
    }


    public ByteBuffer getDataAsByteBuffer()
    {
        byte[] result = null;
        switch(mimeType) {
            case  OBJECT:
            case  EVIO:
            case  IG5:
            case  COBJECT:
                result = (byte[]) data;
                break;
            case  JOBJECT:
                try {
                    result = CUtil.O2B(data);
                } catch (IOException e) {
                    lg.logger.severe(CUtil.stack2str(e));
                }
                break;
        }
        if (result != null) {
            return ByteBuffer.wrap(result).order(dataEndianness);
        } else {
            return null;
        }
    }

    public String getLogMessage() {
        return logMessage;
    }

    public void setLogMessage(String logMessage) {
        this.logMessage = logMessage;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("date                 = ").append(CUtil.getCurrentTime()).append("\n");
        sb.append("dataSource           = ").append(dataSource).append("\n");
        sb.append("dataDestination      = ").append(dataDestination).append("\n");
        sb.append("dataBroadcast        = ").append(dataBroadcast).append("\n");
        sb.append("doneBroadcast        = ").append(doneBroadcast).append("\n");
        sb.append("dataDescription      = ").append(dataDescription).append("\n");
        sb.append("dataEndianness       = ").append(dataEndianness).append("\n");
        sb.append("status               = ").append(status).append("\n");
        sb.append("logMessage           = ").append(logMessage).append("\n");
        sb.append("mimeType             = ").append(mimeType).append("\n");
        sb.append("dataUnit             = ").append(dataUnit).append("\n");
        sb.append("language             = ").append(language).append("\n");
        sb.append("version              = ").append(version).append("\n");
        sb.append("control              = ").append(engineControl).append("\n");
        sb.append("exceptionSource      = ").append(exceptionSource).append("\n");
        sb.append("exceptionDestination = ").append(exceptionDestination).append("\n");
        sb.append("requestID            = ").append(requestID).append("\n");
        sb.append("data                 = ");
        switch(mimeType){
            case  BYTE_ARRAY:
                byte[] byte_array = (byte[]) data;
                sb.append(Arrays.toString(byte_array));
                break;
            case  SHORT_ARRAY:
                short[] short_array = (short[]) data;
                sb.append(Arrays.toString(short_array));
                break;
            case  INT_ARRAY:
                int[] int_array = (int[]) data;
                sb.append(Arrays.toString(int_array));
                break;
            case  FLOAT_ARRAY:
                float[] float_array = (float[]) data;
                sb.append(Arrays.toString(float_array));
                break;
            case  DOUBLE_ARRAY:
                double[] double_array = (double[]) data;
                sb.append(Arrays.toString(double_array));
                break;
            case  STRING_ARRAY:
                String[] string_array = (String[]) data;
                sb.append(Arrays.toString(string_array));
                break;
            default:
                sb.append(data);
                break;
        }
        sb.append("\n");
        return sb.toString();
    }
}
