package org.jlab.clara.system;

import org.jlab.clara.pubsub.CTrParameter;

/**
 * Class implementing Clara data bus using 0MQ
 *
 * @author gurjyan
 * @version Clara-3.0.1
 * @date 4/4/14
 */
public class C0mqDrive implements IClaraDataBus {

    @Override
    public Object connect(String name, String udl, String description) throws CException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public Object connect2Dpe(String name, String host) throws CException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public Object connect2Platform(String name) throws CException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public Object connect2LocalDpe(String name) throws CException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void disconnect(Object connection) throws CException {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void platformDisconnect() throws CException {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void localDpeDisconnect() throws CException {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public boolean isConnected(Object connection) {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public boolean isPlatformConnected() {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public boolean isLocalDpeConnected() {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public boolean send(CTrParameter p) throws CException {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public Object syncSend(CTrParameter p) throws CException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }
}
