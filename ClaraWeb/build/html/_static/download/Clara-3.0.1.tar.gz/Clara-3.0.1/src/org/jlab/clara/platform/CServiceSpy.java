/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */


package org.jlab.clara.platform;

import org.jlab.clara.system.CcMsgDrive;
import org.jlab.coda.cMsg.cMsgCallbackAdapter;
import org.jlab.coda.cMsg.cMsgException;
import org.jlab.coda.cMsg.cMsgMessage;
import org.jlab.clara.constants.CSISConstants;
import org.jlab.clara.system.CException;
import org.jlab.clara.util.CLogger;
import org.jlab.clara.util.CUtil;
import org.jlab.clara.util.DBConnection;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * @author gurjyan
 * @version 3.x
 */

public class CServiceSpy extends CcMsgDrive {

    // JDB connection to the Clara database.
    private static Connection con;

    private BufferedWriter fileOutput;
    private String myName;

    // local instance of the logger object
    private static CLogger lg = CLogger.getInstance();

    public CServiceSpy(){
        myName = myConfig.getPlatformName()+"_spy";

        // Connect to the platform pub-sub server
        try {
            connect2Platform(myName);
        } catch (CException e) {
            lg.logger.severe(CUtil.stack2str(e));
        }

        if(getPlatformConnection() !=null){

            // connect to the Clara database
            connect2DB();

            // subscribe PlatformRegistration messages from the platform agents
            try {
                getPlatformConnection().subscribe(myName, CSISConstants.LOG_TYPE, new ServiceCommunicationLogCB(), null);
            } catch (cMsgException e) {
                lg.logger.severe(CUtil.stack2str(e));
            }
        }
        System.out.println(myName+" logging service is started at "+ CUtil.getCurrentTime());
    }

    private void connect2DB(){
        String db_url, db_user;

        // database connection
        try {
            if(System.getenv("CLARA_DB_URL")!=null){
                db_url =System.getenv("CLARA_DB_URL");
            } else {
                db_url = CSISConstants.DB_URL;
            }
            if(System.getenv("CLARA_DB_USER")!=null){
                db_user =System.getenv("CLARA_DB_USER");
            } else {
                db_user = CSISConstants.DB_USER;
            }
            DBConnection.createConnection(db_url, CSISConstants.DB_DRIVER, db_user, CSISConstants.DB_PASSWORD);
            // Get a db connection
            con = DBConnection.getConnection();
        } catch (CException e) {
            lg.logger.severe(myName+": Problem connecting to the Clara database at: " +
                    CSISConstants.DB_URL+"\n"+CUtil.stack2str(e));
        }

        // opening a file in the $CLARA_SERVICES/log dir
        boolean ka;
        String logDir = myConfig.getClaraServices()+File.separator+
                "log";

        ka = (new File(logDir).exists());
        if(!ka){
            if (!new File(logDir).mkdirs()) {
                lg.logger.severe("Failed to create logging directory = "+logDir);
            }
        }

        try {
            File f = new File(logDir+File.separator+myConfig.getPlatformName()+".log");
            if(!f.exists()){
                f.createNewFile();
            }

            FileWriter fw = new FileWriter(f, true);
            fileOutput = new BufferedWriter(fw);
        } catch (IOException e) {
            lg.logger.severe(CUtil.stack2str(e));
        }

    }

    private void updateDB(String author, int severity, String messageText) {
        try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate("INSERT INTO service_log VALUES ( '"+
                    CUtil.getCurrentTimeInMs()+"','"+
                    author+"','"+
                    severity+"','"+
                    messageText+"')");
            stmt.close();
        }
        catch (SQLException ex) {
            lg.logger.severe(CUtil.stack2str(ex));
        }

    }

    private void updateFile (String author, int severity, String messageText){
        try {
            fileOutput.write(CUtil.getCurrentTimeInMs()+" "+author+" "+severity+" "+messageText);
            fileOutput.newLine();
        } catch (IOException e) {
            lg.logger.severe(CUtil.stack2str(e));
        }
    }

    public void exit(){
        try {
            fileOutput.close();
        } catch (IOException e) {
            lg.logger.severe(CUtil.stack2str(e));
        }
    }

    /************************************************************************
     * Private inner class for responding to messages from Clara service
     */
    private class ServiceCommunicationLogCB extends cMsgCallbackAdapter {
        public void callback(cMsgMessage msg, Object userObject){
            if(msg.getPayloadItem("author")!=null){
                try {
                    String author = msg.getPayloadItem("author").getString();
                    int severity = msg.getUserInt();
                    String messageTxt = msg.getText();
                    if(con!=null)updateDB(author,severity,messageTxt);
                    if(fileOutput!=null)updateFile(author, severity, messageTxt);
                } catch (cMsgException e) {
                    lg.logger.severe(CUtil.stack2str(e));
                }
            }
        }
    }
}
