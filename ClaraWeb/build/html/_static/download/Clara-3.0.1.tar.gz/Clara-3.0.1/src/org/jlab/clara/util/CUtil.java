/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */


package org.jlab.clara.util;


import org.jlab.clara.constants.CConstants;
import org.jlab.clara.constants.CSISConstants;
import org.jlab.clas12.tools.MimeType;
import org.jlab.clas12.tools.property.JPropertyList;
import org.jlab.clara.system.CException;

import javax.crypto.*;
import javax.crypto.spec.DESKeySpec;
import java.io.*;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Class contains static utility methods
 *
 * @author gurjyan
 * Date: 10/5/12
 */
public class CUtil {

    // local instance of the logger object
    private static CLogger lg = CLogger.getInstance();



    /**
     * Utility method to construct container canonical name
     * based on host IP name and container name
     *
     * @param host IP name (e.g. claradm.jlab.org)
     * @param container name
     * @return canonical name of the container = dotted IP of the host + container name
     */
    public static String getConCanName(String host, String container){
        // get textual representation of the host IP address
        String hostIP = CUtil.getIPAddress(host);

        // container canonical name
        return hostIP.trim()+"/"+container.trim();
    }


    /**
     * Build clara service canonical name
     * @param host host of the DPE
     * @param container container given name
     * @param engine engine given name
     * @return canonical name of the service
     */
    public static String getSerCanName(String host, String container, String engine){
        // get textual representation of the host IP address
        String hostIP = CUtil.getIPAddress(host);

        // container canonical name
        return hostIP.trim()+"/"+container.trim()+"/"+engine;
    }

    /**
     * Parses service canonical name string (having the proxyHost/containerName/serviceName construct)
     * to find the service proxy name.
     * @param serviceCanonicalName  service canonical name, as well as container name
     * @return service hosting DPE host name
     */
    public static String parse4DpeHostName(String serviceCanonicalName){
        String tmp = serviceCanonicalName.trim();
        return tmp.substring(0,tmp.indexOf("/"));
    }

    /**
     * Parses service canonical name string (having the proxyHost/containerName/serviceName construct)
     * to find the service container name.
     * @param serviceCanonicalName  service canonical name
     * @return service container name
     */
    public static String parse4ContainerName(String serviceCanonicalName){
        String tmp = serviceCanonicalName.trim();
        int n = tmp.split("/").length;
        if(n==3){
            return tmp.substring(tmp.indexOf("/")+1,tmp.lastIndexOf("/"));
        } else if(n==2){
            return tmp.substring(tmp.indexOf("/")+1);
        } else {
            return null;
        }
    }

    public static String parse4ContainerCanonicalName(String serviceCanonicalName){
        String tmp = serviceCanonicalName.trim();
        return tmp.substring(0,tmp.lastIndexOf("/"));
    }

    /**
     * Parses service canonical name string (having the dpHost/containerName/engineName construct)
     * to find the engine name.
     * @param serviceCanonicalName  service canonical name
     * @return service name
     */
    public static String parse4EngineName(String serviceCanonicalName){
        String tmp = serviceCanonicalName.trim();
        return tmp.substring(tmp.lastIndexOf("/")+1);
    }


    /**
     * Converts object into a byte array
     * @param object to be converted. Probably it must be serializable
     * @return byte array
     * @throws java.io.IOException in case there is an io problem.
     */
    public static byte[] O2B(Object object) throws IOException {
        if(object instanceof byte[]) {
            return (byte[])object;
        } else {
            ByteArrayOutputStream bs = new ByteArrayOutputStream();
            ObjectOutputStream out = new ObjectOutputStream (bs);
            out.writeObject(object);
            out.flush();
            out.close ();
            return bs.toByteArray();
        }
    }

    //Convert a byte array into a message object
    /**
     * Converts byte array into an Object, that can be cast into pre-known class object.
     * @param bytes byte array
     * @return Object
     * @throws java.io.IOException case will return null
     * @throws ClassNotFoundException case will return null
     */
    public static Object B2O(byte bytes[]) throws IOException, ClassNotFoundException{

        try{
            Object object;
            ObjectInputStream in;
            ByteArrayInputStream bs;
            bs = new ByteArrayInputStream (bytes);
            in = new ObjectInputStream(bs);
            object = in.readObject();
            in.close ();
            bs.close ();
            return object;
        }
        catch(StreamCorruptedException sce){
            lg.logger.severe(CUtil.stack2str(sce));
            return new Object();
        }
        catch(ClassCastException cce){
            lg.logger.severe(CUtil.stack2str(cce));
            return new Object();
        }
    }

    /**
     * Convenient method to force main thread to sleep.
     * @param msec sleep parameter is in msecods.
     */
    public static void sleep(int msec){
        try {
            Thread.sleep(msec);
        } catch (InterruptedException e) {
            lg.logger.severe(CUtil.stack2str(e));
        }
    }

    /**
     * Runs a shell command
     * @param command string
     * @return ShellProcess object
     */
    public static ShellProcess runShellCommand(String command){
        ShellProcess po = new ShellProcess();
        StringBuffer sb = new StringBuffer();
        String s;
        try {
            Process p = Runtime.getRuntime().exec(command);
            BufferedReader stdInput = new BufferedReader(new
                    InputStreamReader(p.getInputStream()));
            BufferedReader stdError = new BufferedReader(new
                    InputStreamReader(p.getErrorStream()));

            while ((s = stdInput.readLine()) != null) {
                sb.append(s);
            }
            po.setStdio(sb.toString());
            sb = new StringBuffer();
            while ((s = stdError.readLine()) != null) {
                sb.append(s);
            }
            po.setStderr(sb.toString());
            stdInput.close();
            stdError.close();
        }
        catch (IOException e) {
            lg.logger.severe(CUtil.stack2str(e));
        }
        return po;
    }

    /**
     * forks an external shell process
     * @param cmdL list containing command name, followed by number of parameters
     * @param isSync if true thread will wait until process is completed
     * @return {@link StdIO} object
     */
    public static StdIO fork (List<String> cmdL, boolean isSync) throws CException {
        StdIO po = new StdIO();
        StringBuffer sb;
        String s;
        BufferedReader stdInput;
        BufferedReader stdError;
        Process p;
        try {

            // sync execution
            if(isSync){
                p = new ProcessBuilder(cmdL).start();

                // stdInput
                if(p.getInputStream()!=null){
                    stdInput = new BufferedReader(new
                            InputStreamReader(p.getInputStream()));
                    sb = new StringBuffer();

                    while ((s = stdInput.readLine()) != null) {
                        sb.append(s).append("\n");
//                        sb.append(s).append(System.lineSeparator());
                    }
                    stdInput.close();
                    po.setStdio(sb.toString());
                }

                // stdError
                sb = new StringBuffer();
                stdError = new BufferedReader(new
                        InputStreamReader(p.getErrorStream()));
                if(stdError.ready()) {
                    while ((s = stdError.readLine()) != null) {
                        sb.append(s).append("\n");
//                        sb.append(s).append(System.lineSeparator());
                    }
                    po.setStderr(sb.toString());
                    stdError.close();
                }

                p.waitFor();

                // exit value
                po.setExitValue(p.exitValue());

                // aSync execution
            } else {
                p = new ProcessBuilder(cmdL).start();
                po.setExitValue(p.exitValue());
                if(p.exitValue()!=0){
                    // stdError
                    sb = new StringBuffer();
                    stdError = new BufferedReader(new
                            InputStreamReader(p.getErrorStream()));
                    if(stdError.ready()) {
                        while ((s = stdError.readLine()) != null) {
                            sb.append(s).append("\n");
//                            sb.append(s).append(System.lineSeparator());
                        }
                        po.setStderr(sb.toString());
                        stdError.close();
                    }
                }
            }
        } catch (IOException e) {
            throw new CException(e.getMessage());
        } catch (InterruptedException e) {
            throw new CException(e.getMessage());
        } catch (IllegalThreadStateException e) {
        }

        return po;
    }

    /**
     * Overloaded {@link #fork(java.util.List, boolean)} method that takes string as an input parameter
     * @param cmd command line string
     * @param isSync see {@link #fork(java.util.List, boolean)}
     * @return {@link StdIO} object
     */
    public static StdIO fork (String cmd, boolean isSync) throws CException {
        ArrayList<String> l = new ArrayList<String>();
        StringTokenizer st = new StringTokenizer(cmd.trim());
        while(st.hasMoreTokens()){
            l.add(st.nextToken());
        }
        return fork(l,isSync);
    }


    /**
     * This method is for unix os only.
     * Takes the name of the process. Runs a shell process to find the ID of the process with that name.
     * Then starts another unix process to kill the process whith that id.
     * @param name of the process
     */
    public static void removeUnixShellProcess(String name){
        ShellProcess sp = runShellCommand("ps -C "+name+" -o pid=");
        Scanner sc = new Scanner(sp.getStdio());
        while(sc.hasNext()){
            runShellCommand("kill -9 "+sc.next());
        }
        sc.close();
    }

    /**
     * Gets the current time and returns string representation of it.
     * N.B. package has one other geCurrentTime method defined in
     * @return string representing the current time.
     */
    public static String getCurrentTime(){
        Format formatter = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        return formatter.format(new Date());
    }

    /**
     * Gets the current time and returns string representation of it.
     * N.B. package has one other geCurrentTime method defined in
     * @return string representing the current time.
     */
    public static String getCurrentTime(String format){
        Format formatter = new SimpleDateFormat(format);
        return formatter.format(new Date());
    }

    /**
     * Current time in milli-seconds.
     * @return current time in ms.
     */
    public static long getCurrentTimeInMs(){
        return System.currentTimeMillis();
    }

    public static long getCurrentTimeInNs(){
        return System.nanoTime();
    }

    /**
     * returns IP address of the host
     * @param h host
     * @return textual representation of the IP address
     */
    public static String getIPAddress(final String h){
        String host = CConstants.udf;
        try {
            // resolve the host name for IP address
            if(h.equalsIgnoreCase("localhost")){
                InetAddress address = InetAddress.getLocalHost();

                // host will always be in the form of IP address
                host =address.getHostAddress();
            } else {

                // find the IP address based on the host name
                InetAddress address = InetAddress.getByName(h);
                host = address.getHostAddress();
            }
        } catch (UnknownHostException e) {
            lg.logger.severe(CUtil.stack2str(e));
        }
        return host;
    }

    public static String getHostName(final String h){
        String host = h;
        try {
            // resolve the host name for IP address
            if(h.equalsIgnoreCase("localhost")){
                InetAddress address = InetAddress.getLocalHost();

                // host will always be in the form of IP address
                host =address.getCanonicalHostName();
            } else {
                InetAddress address = InetAddress.getByName(h);
                host = address.getHostName();
            }
        } catch (UnknownHostException e) {
            lg.logger.severe(CUtil.stack2str(e));
        }
        return host;
    }

    public static boolean containsDigit(final String s){
        for (char c: s.toCharArray()){
            if(Character.isDigit(c)){
                return true;
            }
        }
        return false;
    }

    /**
     *  Based on the data object type defines the mimeType of the data
     * @param data Transient data data object
     * @return stat if not able to define
     */
    public static MimeType defineMimeType(Object data){

        MimeType mimeType = MimeType.UNDEFINED;
        if(data instanceof Byte) {
            mimeType = MimeType.BYTE;
        } else if (data instanceof Short) {
            mimeType = MimeType.SHORT ;
        } else if (data instanceof Integer) {
            mimeType = MimeType.INT;
        } else if (data instanceof Float) {
            mimeType = MimeType.FLOAT;
        } else if (data instanceof Double) {
            mimeType = MimeType.DOUBLE;
        } else if (data instanceof String) {
            mimeType = MimeType.STRING;
        } else if(data instanceof byte[]) {
            mimeType = MimeType.BYTE_ARRAY;
        } else if (data instanceof short[]) {
            mimeType = MimeType.SHORT_ARRAY;
        } else if (data instanceof int[]) {
            mimeType = MimeType.INT_ARRAY;
        } else if (data instanceof float[]) {
            mimeType = MimeType.FLOAT_ARRAY;
        } else if (data instanceof double[]) {
            mimeType = MimeType.DOUBLE_ARRAY;
        } else if (data instanceof String[]) {
            mimeType = MimeType.STRING_ARRAY;
        }  else if (data instanceof JPropertyList) {
            mimeType = MimeType.PROPERTY_LIST;
        }
        return mimeType;
    }

    /**
     * Generates a unique name (required for connection to the Clara cloud) for a Clara client
     * @return Auto-generated name of a client
     */
    public static String generateName(){
        return "ccl_" + new Random().nextInt(1000);
    }

    /**
     * Expands the <code>$CLARA_SERVICE</code> variable in <code>path</code>.
     * @param path the path to an input/output file
     * @return the full expanded path of the file
     */
    public static String getFileName(String path){
        return path.replace("$CLARA_SERVICES", System.getenv("CLARA_SERVICES")).replace("${CLARA_SERVICES}", System.getenv("CLARA_SERVICES"));
    }

    /**
     * Replace the expanded path with the string <code>"$CLARA_SERVICES"</code>.
     * @param fullPath a full expanded path to an input/output file
     * @return the path with the string "$CLARA_SERVICES" on it instead of its expanded value.
     */
    public static String setFileName(String fullPath){
        return fullPath.replace(System.getenv("CLARA_SERVICES"), "$CLARA_SERVICES");
    }

    /**
     * Returns the stack trace of a exception as a string
     * @param e an exception
     * @return a string with the stack trace of the exception
     */
    public static String reportException(Throwable e){
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        e.printStackTrace(pw);
        return sw.toString();
    }

    public static int isNumber(String s){
        int r;
        try {
            r = Integer.parseInt(s);
        } catch (NumberFormatException e) {
            lg.logger.severe(CUtil.stack2str(e));
            return -1;
        }
        return r;
    }

    public static byte[] getByteArray(ByteBuffer data){
        byte[] bytes;
        if(data.hasArray()){
            bytes = data.array();
        } else {
            bytes = new byte[data.capacity()];

            // transfer bytes from this buffer into the given destination array
            data.get(bytes, 0, bytes.length);
        }
        return bytes;
    }

    /**
     * Encrypts and saves the password and the secret key into binary files
     * located in a platform accessible directory
     * @param password Password
     */
    public static void encryptAndSave(String password){

        try {
            // generate secret encryption key
            KeyGenerator desGen = KeyGenerator.getInstance("DES");
            SecretKey desKey = desGen.generateKey();

            // convert secret key to a byte array to be able to transfer to a requester
            SecretKeyFactory desFactory = SecretKeyFactory.getInstance("DES");
            DESKeySpec desSpec = (DESKeySpec)desFactory.getKeySpec(desKey, DESKeySpec.class);
            byte[] secKey = desSpec.getKey();

            byte[] plainPassword = password.getBytes();

            // get object for encryption
            Cipher cipher = Cipher.getInstance("DES");
            cipher.init(Cipher.ENCRYPT_MODE, desKey);
            byte[] encryptedPassword = cipher.doFinal(plainPassword);

            DataOutputStream os = new DataOutputStream(new FileOutputStream(CSISConstants.pswDir+File.separator+".pswd"));
            os.write(encryptedPassword);
            os.close();
            os = new DataOutputStream(new FileOutputStream(CSISConstants.pswDir+File.separator+".key"));
            os.write(secKey);
            os.close();

        } catch (NoSuchAlgorithmException e) {
            lg.logger.severe(CUtil.stack2str(e));
        } catch (InvalidKeySpecException e) {
            lg.logger.severe(CUtil.stack2str(e));
        } catch (InvalidKeyException e) {
            lg.logger.severe(CUtil.stack2str(e));
        } catch (NoSuchPaddingException e) {
            lg.logger.severe(CUtil.stack2str(e));
        } catch (BadPaddingException e) {
            lg.logger.severe(CUtil.stack2str(e));
        } catch (IllegalBlockSizeException e) {
            lg.logger.severe(CUtil.stack2str(e));
        } catch (FileNotFoundException e) {
            lg.logger.severe(CUtil.stack2str(e));
        } catch (IOException e) {
            lg.logger.severe(CUtil.stack2str(e));
        }
    }

    /**
     * Reads the hidden secret key file and returns binary form of the password encryption secret key.
     * @return byte array representing the secret key
     */
    public static byte[] getSavedSecretKey(){
        byte[] keyBytes = null;
        File kf = new File(CSISConstants.pswDir+File.separator+".key");

        if(kf.exists()){
            try {
                DataInputStream kis = new DataInputStream(new FileInputStream(kf));
                keyBytes = new byte[(int)kf.length()];
                kis.readFully(keyBytes);
                kis.close();
            } catch (FileNotFoundException e) {
                lg.logger.severe(CUtil.stack2str(e));
            } catch (IOException e) {
                lg.logger.severe(CUtil.stack2str(e));
            }
        }
        return keyBytes;
    }

    /**
     * Reads the hidden password file and returns binary form of the encrypted password.
     * @return byte array representing the password
     */
    public static byte[] getSavedPassword(){
        byte[] passwordBytes = null;
        File pf = new File(CSISConstants.pswDir+File.separator+".pswd");

        if(pf.exists()){
            try {
                DataInputStream pis = new DataInputStream(new FileInputStream(pf));
                passwordBytes = new byte[(int)pf.length()];
                pis.readFully(passwordBytes);
                pis.close();
            } catch (FileNotFoundException e) {
                lg.logger.severe(CUtil.stack2str(e));
            } catch (IOException e) {
                lg.logger.severe(CUtil.stack2str(e));
            }
        }
        return passwordBytes;
    }

    /**
     * Checks to see if a file exists and is NOT used by any other process.
     * @param fileName  full path name of a file
     * @return true if file exists and not opened.
     */
    public static boolean fileExist(String fileName){
        boolean b = false;
        File f = new File(fileName);
        if(f.exists()){
            List<String> isInUse = Arrays.asList("/usr/sbin/lsof", fileName);
            try {
                StdIO result = CUtil.fork(isInUse, true);
                if(result.getStdio().equals("")){
                    b = true;
                }
            } catch (CException e) {
                lg.logger.severe(CUtil.stack2str(e));
            }
        }
        return b;
    }

    public static String stack2str(Exception e) {
        try {
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            e.printStackTrace(pw);
            return "------\r\n" + sw.toString() + "------\r\n";
        }
        catch(Exception e2) {
            return "bad stack";
        }
    }
}
