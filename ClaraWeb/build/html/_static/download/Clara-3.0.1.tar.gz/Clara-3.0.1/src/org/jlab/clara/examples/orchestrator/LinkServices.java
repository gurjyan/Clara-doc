/*
 * Copyright (c) 10/2013 JSA: TJNAF DAQ Group. All rights reserved.
 * This software was developed under the United States Government license.
 * Initiated by V. Gyurjyan
 */


package org.jlab.clara.examples.orchestrator;

import org.jlab.clara.frontend.JOrchestrator;
import org.jlab.clara.system.CException;

/**
 *
 * An example of an orchestrator that links two service together, i.e.
 * the output/result of the service1 will be sent to service2 as an input.
 *
 * @author gurjyan
 * @version 3.x
 */

public class LinkServices extends JOrchestrator
{
    /**
     * Constructor
     * Connects to the Clara platform
     *
     */
    public LinkServices() throws CException {
        super();
    }


    public static void main(String[] args) {
        String service1 = args[0];
        String service2 = args[1];

        // an instance of this class
        LinkServices lso;
        try {
            lso = new LinkServices();

        // get registration information form the platform normative service
        lso.requestRegistrationData(1000);

        // check if the service1 is registered
        if(!lso.isServiceDeployed(service1)){
            System.out.println("Error: Can not find the " +
                    "registration information for the service = "+service1);
            System.exit(1);
        }


        // check if the service2 is registered
        if(!lso.isServiceDeployed(service2)){
            System.out.println("Error: Can not find the " +
                    "registration information for the service = "+service2);
            System.exit(2);
        }

        // link service
        if(!lso.chainServices(service1, service2)){
            System.out.println("Error: linking service");
        }
            lso.exit();
        } catch (CException e) {
            System.out.println(e.getMessage());
        }
    }
}
