package org.jlab.clara.ui;

/**
 * Describe...
 *
 * @author gurjyan
 *         Date: 3/25/14 Time: 10:43 AM
 * @version 2
 */
public enum EClaraCmd {
    ls        (" ls:         list deployed services"),
    lsl       (" lsl:        list service links"),
    link      (" link:       link services"),
    rmlink    (" rmlink:     remove links of a service"),
    deploy    (" deploy:     deploy a service"),
    run       (" run:        run a service or a chain of services"),
    syncrun   (" syncrun:    sync run a service or a chain of services"),
    sinfo     (" sinfo:      print information about a service"),
    exit      (" exit:       exit"),
    help      (" help:       list of all available command");

    private String h;

    private EClaraCmd(String s) {
        h = s;
    }

    public String getHelp() {
        return h;
    }


}
