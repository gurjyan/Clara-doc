package org.jlab.coda.xmsg.excp;

/**
 *<p>
 *     xMsgPublishingException class
 *</p>
 * @author gurjyan
 *         Created on 10/6/14
 * @version %I%
 * @since 1.0
 */
public class xMsgPublishingException extends xMsgException {

    public xMsgPublishingException(String message) {
        super(message);
    }

}
