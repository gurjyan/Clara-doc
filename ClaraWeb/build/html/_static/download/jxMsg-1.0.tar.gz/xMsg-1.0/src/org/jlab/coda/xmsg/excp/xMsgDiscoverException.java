package org.jlab.coda.xmsg.excp;

/**
 *<p>
 *     xMsgDiscoverException class
 *</p>
 * @author gurjyan
 *         Created on 10/6/14
 * @version %I%
 * @since 1.0
 */
public class xMsgDiscoverException extends xMsgException {

    public xMsgDiscoverException(String message) {
        super(message);

    }
}
