package org.jlab.coda.xmsg.excp;

/**
 *<p>
 *     xMsgSubscribingException class
 *</p>
 * @author gurjyan
 *         Created on 10/6/14
 * @version %I%
 * @since 1.0
 */
public class xMsgSubscribingException extends xMsgException {

    public xMsgSubscribingException(String message) {
        super(message);
    }

}
