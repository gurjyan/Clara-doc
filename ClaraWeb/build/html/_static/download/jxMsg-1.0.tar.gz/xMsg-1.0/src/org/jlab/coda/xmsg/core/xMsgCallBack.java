package org.jlab.coda.xmsg.core;

/**
 * <p>
 *     xMsg callback interface
 * </p>
 *
 * @author gurjyan
 *         Created on 10/6/14
 * @version %I%
 * @since 1.0
 */
public interface xMsgCallBack {

    public Object callback(xMsgMessage msg);

}
