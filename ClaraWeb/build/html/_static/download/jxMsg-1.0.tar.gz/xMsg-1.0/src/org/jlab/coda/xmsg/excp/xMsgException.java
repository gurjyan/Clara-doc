package org.jlab.coda.xmsg.excp;

/**
 *<p>
 *     xMsg exception class
 *</p>
 * @author gurjyan
 *         Created on 10/6/14
 * @version %I%
 * @since 1.0
 */
public class xMsgException extends Exception {

    public xMsgException(String message) {
        super(message);
    }
}
