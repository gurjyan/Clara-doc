package org.jlab.clara.base;

/**
 * Simple exception class
 *
 * @author gurjyan
 * @version 1.x
 * @since 2/1/15
 */
public class CException extends Exception {
    public CException(String message) {
        super(message);
    }
}
