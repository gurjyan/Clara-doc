package org.jlab.clara.sys;

/**
 * Describe.....
 *
 * @author gurjyan
 * @version 1.x
 * @since 1/30/15
 */
public class Platform {
}
